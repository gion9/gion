"""Запускалка для CrimsonBlade.exe

Код игры (game.py, music.py, textures.py) лежит рядом с .exe обычными файлами,
поэтому обновлять игру можно простой заменой game.py — без пересборки .exe
"""
import os
import sys
import runpy
import traceback

# всё, что нужно game.py, импортируем здесь, чтобы сборщик положил это в .exe
import math, random, wave, zlib, struct, copy, colorsys, json, pathlib, time  # noqa: F401,E401
import numpy  # noqa: F401
import panda3d.core  # noqa: F401
import ursina  # noqa: F401
from ursina import *  # noqa: F401,F403
from ursina.shader import Shader  # noqa: F401
from ursina.shaders import lit_with_shadows_shader, unlit_shader  # noqa: F401

HERE = os.path.dirname(sys.executable if getattr(sys, 'frozen', False) else os.path.abspath(__file__))
sys.path.insert(0, HERE)
os.chdir(HERE)

try:
    runpy.run_path(os.path.join(HERE, 'game.py'), run_name='__main__')
except SystemExit:
    raise
except Exception:
    with open(os.path.join(HERE, 'crash.txt'), 'w', encoding='utf-8') as f:
        traceback.print_exc(file=f)
    raise
