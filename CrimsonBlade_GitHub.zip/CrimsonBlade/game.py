"""
Клинок Багровой Луны — 3D
Самурай с духовной силой спускается в подземелья и рубит демонов в покрове ночи

Управление:
  WASD — бег (камера всегда за спиной), мышь — поворот
  Пробел — прыжок, Shift — рывок
  ЛКМ — цепочка из 5 ударов, ПКМ — иай-выпад
  ЛКМ в прыжке — удар сверху, ЛКМ сразу после рывка — крестовой разрез
  ЛКМ ЛКМ ПКМ — «Вихрь сакуры», 4×ЛКМ + ПКМ — «Раскол луны»
  E — волна духа, Q — ульта «Багровое Полнолуние»
  Esc — пауза, F9 — простая графика, F11 — полный экран, F10 — выход
"""
import os
import sys
import math
import random
import traceback

# в собранном .exe файлы игры лежат рядом с самим .exe
FROZEN = getattr(sys, 'frozen', False)
HERE = os.path.dirname(sys.executable if FROZEN else os.path.abspath(__file__))


def _crash_log(exc_type, exc, tb):
    try:
        with open(os.path.join(HERE, 'crash.txt'), 'w', encoding='utf-8') as f:
            traceback.print_exception(exc_type, exc, tb, file=f)
    except Exception:
        pass
    sys.__excepthook__(exc_type, exc, tb)


sys.excepthook = _crash_log

from ursina import *
from ursina.shader import Shader
from ursina.shaders import lit_with_shadows_shader, unlit_shader

import music
import textures

try:
    import anime_models as ANIME     # аниме-модели героев: гладкие формы, cel-shading, контур
except Exception as _e:
    ANIME = None
    print('аниме-модели недоступны, будут обычные:', _e)

music.ensure(os.path.join(HERE, 'sounds'))
textures.ensure(os.path.join(HERE, 'textures'))
BEST_FILE = os.path.join(HERE, 'best.txt')
SAVE_FILE = os.path.join(HERE, 'save.json')


def dlog(*a):
    """Журнал запуска рядом с игрой: какая версия, какой экран, какие демоны появились"""
    try:
        with open(os.path.join(HERE, 'debug_log.txt'), 'a', encoding='utf-8') as f:
            f.write(' '.join(str(x) for x in a) + '\n')
    except Exception:
        pass


try:
    os.remove(os.path.join(HERE, 'debug_log.txt'))
except Exception:
    pass

# --- экран: Windows с масштабом 125–150% иначе растягивает окно больше монитора, и края с текстом уезжают
SCREEN = None
if sys.platform == 'win32':
    try:
        import ctypes
        try:
            ctypes.windll.shcore.SetProcessDpiAwareness(2)
        except Exception:
            ctypes.windll.user32.SetProcessDPIAware()
        SCREEN = (ctypes.windll.user32.GetSystemMetrics(0), ctypes.windll.user32.GetSystemMetrics(1))
    except Exception:
        SCREEN = None
try:
    from panda3d.core import loadPrcFileData as _prc
    _prc('', 'dpi-aware true')
except Exception:
    pass
try:
    app = Ursina(title='Бездна Проклятых', borderless=True, fullscreen=True, development_mode=False,
                 size=Vec2(*SCREEN) if SCREEN else None)
except TypeError:
    app = Ursina(title='Бездна Проклятых', borderless=True, fullscreen=True, development_mode=False)

# --- производительность: Ursina каждый кадр обходит в Python все объекты сцены.
# Нашей игре это не нужно (всё обновляем сами), поэтому объекты в этот обход не попадают,
# кроме кнопок, которым движок передаёт клики
_ursina_entity_init = Entity.__init__


def _fast_entity_init(self, *args, add_to_scene_entities=None, **kwargs):
    if add_to_scene_entities is None:
        add_to_scene_entities = isinstance(self, Button)
    _ursina_entity_init(self, *args, add_to_scene_entities=add_to_scene_entities, **kwargs)


Entity.__init__ = _fast_entity_init
try:
    Entity.default_shader = unlit_shader
except Exception:
    pass


def set_text(t, value):
    """Текст в Ursina пересобирается при каждой записи — пишем, только если он изменился"""
    if getattr(t, '_last', None) != value:
        t._last = value
        t.text = value

for _n in ('fps_counter', 'entity_counter', 'collider_counter', 'cog_button'):
    try:
        getattr(window, _n).enabled = False
    except Exception:
        pass
window.color = color.hex('#08020a')
camera.fov = 70
mouse.visible = True
mouse.locked = False


# =====================================================================
# палитра и утилиты
# =====================================================================
def C(h, a=1.0):
    c = color.hex(h)
    return Color(c[0], c[1], c[2], a)


INK = C('#0b0506')
BLOOD = C('#c3121e')
EMBER = C('#ff4a3d')
BONE = C('#f1e3dc')
GOLD = C('#e0b45a')
WHITE = C('#ffffff')


def lerp_angle(a, b, t):
    d = (b - a + 180) % 360 - 180
    return a + d * t


def flat(v):
    return Vec3(v[0], 0, v[2])


def dist2d(a, b):
    return math.hypot(a[0] - b[0], a[2] - b[2])


def heading_of(v):
    return math.degrees(math.atan2(v[0], v[2]))


def dir_of(heading):
    h = math.radians(heading)
    return Vec3(math.sin(h), 0, math.cos(h))


def smooth(k):
    k = max(0.0, min(1.0, k))
    return k * k * (3 - 2 * k)


# =====================================================================
# шейдер с факелами: 8 точечных огней, лунный свет, контровой свет, туман
# =====================================================================
VERT = '''#version 140
uniform mat4 p3d_ModelViewProjectionMatrix;
uniform mat4 p3d_ModelMatrix;
in vec4 p3d_Vertex;
in vec3 p3d_Normal;
in vec2 p3d_MultiTexCoord0;
in vec4 p3d_Color;
uniform vec2 texture_scale;
uniform vec2 texture_offset;
out vec2 uv;
out vec4 vcol;
out vec3 wpos;
out vec3 wnorm;
void main() {
    gl_Position = p3d_ModelViewProjectionMatrix * p3d_Vertex;
    uv = p3d_MultiTexCoord0 * texture_scale + texture_offset;
    vcol = p3d_Color;
    wpos = (p3d_ModelMatrix * p3d_Vertex).xyz;
    wnorm = mat3(p3d_ModelMatrix) * p3d_Normal;
}
'''

FRAG = '''#version 140
uniform sampler2D p3d_Texture0;
uniform vec4 p3d_ColorScale;
in vec2 uv;
in vec4 vcol;
in vec3 wpos;
in vec3 wnorm;
out vec4 frag;
uniform vec4 L0; uniform vec4 L1; uniform vec4 L2; uniform vec4 L3;
uniform vec4 L4; uniform vec4 L5; uniform vec4 L6; uniform vec4 L7;
uniform vec4 K0; uniform vec4 K1; uniform vec4 K2; uniform vec4 K3;
uniform vec4 K4; uniform vec4 K5; uniform vec4 K6; uniform vec4 K7;
uniform vec4 sky_dir;
uniform vec4 sky_col;
uniform vec4 amb_col;
uniform vec4 cam_pos;
uniform vec4 fog_col;
uniform vec4 fog_range;

vec3 pl(vec4 L, vec4 K, vec3 n) {
    if (L.w <= 0.0) return vec3(0.0);
    vec3 d = L.xyz - wpos;
    float dist = length(d);
    float att = clamp(1.0 - dist / L.w, 0.0, 1.0);
    att = att * att;
    float ndl = max(dot(n, d / max(dist, 0.001)) * 0.75 + 0.25, 0.0);
    return K.rgb * att * ndl;
}

void main() {
    vec4 base = texture(p3d_Texture0, uv) * p3d_ColorScale * vcol;
    vec3 n = wnorm;
    float nl = length(n);
    n = nl > 0.0001 ? n / nl : vec3(0.0, 1.0, 0.0);
    if (!gl_FrontFacing) n = -n;
    vec3 light = amb_col.rgb + sky_col.rgb * max(dot(n, -sky_dir.xyz), 0.0);
    light += pl(L0, K0, n) + pl(L1, K1, n) + pl(L2, K2, n) + pl(L3, K3, n);
    light += pl(L4, K4, n) + pl(L5, K5, n) + pl(L6, K6, n) + pl(L7, K7, n);
    vec3 v = normalize(cam_pos.xyz - wpos);
    float rim = pow(1.0 - max(dot(n, v), 0.0), 3.0);
    vec3 col = base.rgb * light + rim * (0.18 * base.rgb + vec3(0.10, 0.012, 0.016));
    float f = smoothstep(fog_range.x, fog_range.y, length(cam_pos.xyz - wpos));
    col = mix(col, fog_col.rgb, f);
    frag = vec4(col, base.a);
}
'''

TORCH = Shader(name='torch_shader', language=Shader.GLSL, vertex=VERT, fragment=FRAG,
               default_input={'texture_scale': Vec2(1, 1), 'texture_offset': Vec2(0, 0)})

# запасной режим (F9): штатный шейдер Ursina с одним источником
backup_sun = DirectionalLight(shadows=False, color=C('#ff7a6a'))
backup_sun.rotation = (54, -34, 0)
AmbientLight(color=C('#5a2a30'))

GFX = {'safe': False}
LIT_ENTS = []


def world_shader():
    return lit_with_shadows_shader if GFX['safe'] else TORCH


def part(parent=None, unlit=False, **kw):
    """Кусочек мира. Освещается факелами, с unlit=True — светится сам"""
    ts = kw.pop('texture_scale', None)
    e = Entity(parent=parent or scene, **kw)
    if unlit:
        e.unlit = True
    else:
        e.shader = world_shader()
        LIT_ENTS.append(e)
    if ts is not None:
        e.texture_scale = ts
        e._ts = ts
    return e


def set_graphics(safe):
    GFX['safe'] = safe
    alive = []
    for e in LIT_ENTS:
        try:
            if e.is_empty():
                continue
            e.shader = world_shader()
            if getattr(e, '_ts', None) is not None:
                e.texture_scale = e._ts
            alive.append(e)
        except Exception:
            pass
    LIT_ENTS[:] = alive
    if ANIME is not None:
        try:
            ANIME.set_safe(safe, lit_with_shadows_shader)
        except Exception:
            pass
    sh = world_shader()
    keep = []
    for h in BAKED:
        try:
            if h.is_empty():
                continue
            if not sh.compiled:
                sh.compile()
            h.setShader(sh._shader, 10)
            # запасной шейдер Ursina ждёт свои входы (камера, туман, тени) — без них движок падает
            for k, v in (getattr(sh, 'default_input', None) or {}).items():
                try:
                    h.setShaderInput(k, v, 10)
                except Exception:
                    try:
                        h.setShaderInput(k, Vec4(*v) if hasattr(v, '__len__') else float(v), 10)
                    except Exception:
                        pass
            keep.append(h)
        except Exception:
            pass
    BAKED[:] = keep


def glow_entity(e):
    e.unlit = True
    return e


BAKED = []


def _subtree(e, out):
    out.add(id(e))
    for c in getattr(e, '_children', []):
        _subtree(c, out)
    return out


def fix_proportions(hero, head_drop, sh_in, sh_down, collar, collar_y, collar_col):
    """Правка телосложения: короче шея (голова ниже, воротник) и плечи внутри корпуса, а не в воздухе"""
    hero.head.y -= head_drop
    for side, nm in ((-1, 'l'), (1, 'r')):
        sh = hero.arms[nm][0]
        sh.x -= side * sh_in
        sh.y -= sh_down
    try:
        c = Entity(parent=hero.torso, model='taper', y=collar_y, scale=collar, color=collar_col)
        c.shader = ANIME.TOON
        c.set_shader_input('toon_rim', Vec4(1, .3, .25, .5))
        ANIME.TOON_ENTS.append(c)
        # «дельты»: мягкие наплечные объёмы, чтобы рука росла из плеча, а не висела рядом
        for side, nm in ((-1, 'l'), (1, 'r')):
            sh = hero.arms[nm][0]
            d = Entity(parent=hero.torso, model='skull', position=(sh.x * .85, sh.y - .02, 0),
                       scale=(collar[0] * .9, collar[1] * 1.1, collar[2] * 1.0), color=collar_col)
            d.shader = ANIME.TOON
            d.set_shader_input('toon_rim', Vec4(1, .3, .25, .5))
            ANIME.TOON_ENTS.append(d)
    except Exception as e:
        print('воротник не добавлен:', e)


def build_anime(hero, fn_name):
    """Собирает героя аниме-моделью; при любой ошибке — тихий откат на обычную модель"""
    if ANIME is None:
        return False
    try:
        getattr(ANIME, fn_name)(hero)
        hero.eyes = getattr(hero, 'eyes', [])
        return True
    except Exception as e:
        print('аниме-модель не собралась, беру обычную:', e)
        for nm in ('body',):
            if getattr(hero, nm, None) is not None:
                try:
                    destroy(getattr(hero, nm))
                except Exception:
                    pass
        return False


def bake_static(root, keep=()):
    """Склеивает неподвижную геометрию зала в общие меши — в сотни раз меньше вызовов отрисовки"""
    if not hasattr(root, 'flattenStrong'):
        return
    keep_ids = set(id(k) for k in keep if k is not None)
    holder = Entity(parent=root)
    moved = set()
    for c in list(getattr(root, '_children', [])):
        if c is holder or id(c) in keep_ids:
            continue
        _subtree(c, moved)
        c.reparentTo(holder)
        root._children.remove(c)
    holder._children = []
    LIT_ENTS[:] = [e for e in LIT_ENTS if id(e) not in moved]
    holder.flattenStrong()
    BAKED.append(holder)


def bake_rig(node, lit_ids=None, moved=None):
    """Склеивает детали на каждом суставе персонажа, суставы при этом продолжают двигаться"""
    if not hasattr(node, 'flattenStrong'):
        return
    top = lit_ids is None
    if top:
        lit_ids = set(id(e) for e in LIT_ENTS)
        moved = set()
    kids = list(getattr(node, '_children', []))
    leaves = [c for c in kids if id(c) in lit_ids and not getattr(c, '_children', [])]
    if len(leaves) >= 2:
        h = Entity(parent=node)
        for c in leaves:
            c.reparentTo(h)
            node._children.remove(c)
            moved.add(id(c))
        h._children = []
        h.flattenStrong()
        BAKED.append(h)
    for c in kids:
        if c not in leaves and getattr(c, '_children', []):
            bake_rig(c, lit_ids, moved)
    if top and moved:
        LIT_ENTS[:] = [e for e in LIT_ENTS if id(e) not in moved]


# =====================================================================
# свет в сцене: факелы, аура клинка, вспышки
# =====================================================================
class Lights:
    torches = []          # [pos, color, radius, seed]
    flashes = []          # [pos, color, radius, life, max]
    aura = 0.0
    sky_dir = Vec3(.3, -1, .5).normalized()
    sky_col = Vec3(.3, .1, .12)
    aura_col = (1.0, .15, .1)
    amb = Vec3(.10, .045, .06)
    fog = Vec3(.05, .012, .025)
    fog_range = (14, 46)


LT = Lights()


def add_flash(pos, col=(1.0, .35, .2), radius=8.0, life=.35):
    LT.flashes.append([Vec3(pos), col, radius, life, life])


def update_lights(dt):
    if GFX['safe']:
        try:
            scene.set_shader_input('camera_world_position', camera.world_position)
        except Exception:
            pass
    slots = []
    # аура клинка самурая
    if player is not None and player.enabled and LT.aura > .01:
        slots.append((player.position + Vec3(0, 1.4, 0), tuple(c * LT.aura * 2 for c in LT.aura_col), 6))
    for f in LT.flashes[:]:
        f[3] -= dt
        if f[3] <= 0:
            LT.flashes.remove(f)
            continue
        k = f[3] / f[4]
        slots.append((f[0], tuple(c * 2.5 * k for c in f[1]), f[2]))
    slots = slots[:3]
    # ближайшие факелы
    ref = player.position if (player is not None and player.enabled) else camera.position
    near = sorted(LT.torches, key=lambda t: dist2d(t[0], ref))[:8 - len(slots)]
    for t in near:
        fl = .82 + .18 * math.sin(game.clock * 9 + t[3]) * math.sin(game.clock * 13.7 + t[3] * 2)
        slots.append((t[0], tuple(c * fl for c in t[1]), t[2]))
    for i in range(8):
        if i < len(slots):
            p, c, r = slots[i]
            scene.set_shader_input(f'L{i}', Vec4(p[0], p[1], p[2], r))
            scene.set_shader_input(f'K{i}', Vec4(c[0], c[1], c[2], 1))
        else:
            scene.set_shader_input(f'L{i}', Vec4(0, 0, 0, 0))
            scene.set_shader_input(f'K{i}', Vec4(0, 0, 0, 0))
    cp = camera.world_position
    scene.set_shader_input('cam_pos', Vec4(cp[0], cp[1], cp[2], 1))
    scene.set_shader_input('sky_dir', Vec4(LT.sky_dir[0], LT.sky_dir[1], LT.sky_dir[2], 0))
    scene.set_shader_input('sky_col', Vec4(LT.sky_col[0], LT.sky_col[1], LT.sky_col[2], 1))
    scene.set_shader_input('amb_col', Vec4(LT.amb[0] * 1.8 + .02, LT.amb[1] * 1.8 + .015, LT.amb[2] * 1.8 + .02, 1))
    scene.set_shader_input('fog_col', Vec4(LT.fog[0], LT.fog[1], LT.fog[2], 1))
    scene.set_shader_input('fog_range', Vec4(LT.fog_range[0], LT.fog_range[1], 0, 0))


# =====================================================================
# звук
# =====================================================================
BGM_VOL = .5
music_tracks = {'bgm': Audio('bgm', loop=True, autoplay=True, volume=BGM_VOL, group='music'),
                'boss': Audio('boss', loop=True, autoplay=False, volume=0, group='music')}
current_track = ['bgm']


def play_track(name):
    if current_track[0] == name:
        return
    for k, a in music_tracks.items():
        if k == name:
            a.volume = BGM_VOL
            a.play()
        else:
            a.stop()
    current_track[0] = name


def duck(vol):
    music_tracks[current_track[0]].volume = vol


def sfx(name, vol=.6, pitch=None):
    try:
        Audio(name, volume=vol, pitch=pitch or random.uniform(.92, 1.08), auto_destroy=True)
    except Exception:
        pass


# =====================================================================
# меши: серпы ударов, крылья, кольца
# =====================================================================
def arc_mesh(r, width, a0=-75, a1=75, segs=26, full=False):
    verts, tris, uvs = [], [], []
    for i in range(segs + 1):
        k = i / segs
        a = math.radians(a0 + (a1 - a0) * k)
        w = width if full else width * math.sin(math.pi * k) ** 0.8
        verts += [Vec3(math.sin(a) * r, 0, math.cos(a) * r), Vec3(math.sin(a) * (r + w), 0, math.cos(a) * (r + w))]
        uvs += [Vec2(k, 0), Vec2(k, 1)]
    for i in range(segs):
        b = i * 2
        tris += [(b, b + 1, b + 2), (b + 1, b + 3, b + 2)]
    return Mesh(vertices=verts, triangles=tris, uvs=uvs, mode='triangle')


def wing_mesh():
    """Перепонка крыла: веер от плеча с рваным краем, в плоскости XY"""
    pts = [(0, 0), (1.1, .55), (2.5, 1.25), (2.0, .55), (2.75, .2), (2.1, -.2), (2.35, -.75), (1.6, -.6),
           (1.5, -1.25), (.9, -.75), (.25, -1.0), (0, -.55)]
    verts = [Vec3(x, y, 0) for x, y in pts]
    tris = [(0, i, i + 1) for i in range(1, len(pts) - 1)]
    uvs = [Vec2(x / 2.8, (y + 1.3) / 2.6) for x, y in pts]
    normals = [Vec3(0, 0, 1)] * len(pts)
    return Mesh(vertices=verts, triangles=tris, uvs=uvs, normals=normals, mode='triangle')


# ---------- гладкие формы для тел: вместо кубов и шаров ----------
def loft_mesh(prof, e=2.0, nu=18, nv=14, cap=(6, 6)):
    """Тело вращения с поперечником-суперэллипсом. prof(t) -> (rx, rz), t снизу вверх 0..1.
    Вписано в куб -0.5..0.5, как штатный 'cube', поэтому масштабируется так же"""
    def P(i, j):
        t = j / nv
        n = cap[0] if t < .5 else cap[1]
        k = max(0.0, 1 - abs(2 * t - 1) ** n) ** (1 / n)
        rx, rz = prof(t)
        a = math.tau * (i % nu) / nu
        c, sn = math.cos(a), math.sin(a)
        x = rx * k * math.copysign(abs(c) ** (2 / e), c)
        z = rz * k * math.copysign(abs(sn) ** (2 / e), sn)
        return Vec3(x, -.5 + t, z)
    grid = [[P(i, j) for i in range(nu + 1)] for j in range(nv + 1)]
    verts, norms, uvs, idx = [], [], [], {}
    for j in range(nv + 1):
        for i in range(nu + 1):
            p = grid[j][i]
            du = grid[j][(i + 1) % nu] - grid[j][(i - 1) % nu]
            dv = grid[min(nv, j + 1)][i] - grid[max(0, j - 1)][i]
            n = Vec3(du[1] * dv[2] - du[2] * dv[1], du[2] * dv[0] - du[0] * dv[2], du[0] * dv[1] - du[1] * dv[0])
            ln = math.sqrt(n[0] ** 2 + n[1] ** 2 + n[2] ** 2)
            if ln < 1e-6 or j in (0, nv):
                n = Vec3(0, -1 if j < nv / 2 else 1, 0)
            else:
                n = n / ln
                if n[0] * p[0] + n[2] * p[2] < 0:
                    n = -n
            idx[(j, i)] = len(verts)
            verts.append(p)
            norms.append(n)
            uvs.append(Vec2(i / nu, j / nv))
    tris = []
    for j in range(nv):
        for i in range(nu):
            a, b, c, d = idx[(j, i)], idx[(j, i + 1)], idx[(j + 1, i)], idx[(j + 1, i + 1)]
            for t3 in ((a, c, b), (b, c, d)):
                p0, p1, p2 = verts[t3[0]], verts[t3[1]], verts[t3[2]]
                u, w = p1 - p0, p2 - p0
                cr = Vec3(u[1] * w[2] - u[2] * w[1], u[2] * w[0] - u[0] * w[2], u[0] * w[1] - u[1] * w[0])
                if abs(cr[0]) + abs(cr[1]) + abs(cr[2]) < 1e-9:
                    continue
                nm = norms[t3[0]] + norms[t3[1]] + norms[t3[2]]
                # в Ursina лицевая сторона — когда векторное произведение смотрит внутрь
                if cr[0] * nm[0] + cr[1] * nm[1] + cr[2] * nm[2] > 0:
                    t3 = (t3[0], t3[2], t3[1])
                tris.append(t3)
    return Mesh(vertices=verts, triangles=tris, normals=norms, uvs=uvs, mode='triangle')


def _taper(t):
    r = .5 * (.64 + .36 * t) + .05 * math.sin(math.pi * t)
    return r, r * .96


def _torso(t):
    rx = .5 * (.7 + .3 * smooth(min(1, t / .75)))
    rz = .5 * (.8 + .2 * math.sin(math.pi * min(1, t * 1.1)))
    return rx, rz


def _skull(t):
    r = .5 * (.78 + .22 * smooth(t))
    return r, r * 1.02


SHAPES = {
    'taper': lambda: loft_mesh(_taper, e=2.0, cap=(5, 5)),
    'rbox': lambda: loft_mesh(lambda t: (.5, .5), e=7.0, nu=24, nv=12, cap=(9, 9)),
    'torso': lambda: loft_mesh(_torso, e=3.0, nu=22, nv=16, cap=(9, 3)),
    'skull': lambda: loft_mesh(_skull, e=2.0, cap=(2.2, 2)),
    # свой шар вместо штатного 'sphere': штатный в игре выходил чёрным
    'orb': lambda: loft_mesh(lambda t: (.5, .5), e=2.0, nu=24, nv=16, cap=(2, 2)),
}
try:
    from ursina.mesh_importer import imported_meshes
    for _k, _f in SHAPES.items():
        imported_meshes[_k] = _f()
except Exception as _e:
    print('не удалось зарегистрировать формы:', _e)


def _cached_mesh(name, fn):
    """Меш строится один раз и дальше берётся из кэша движка по имени — как штатный 'cube'"""
    try:
        from ursina.mesh_importer import imported_meshes as _im
        _im[name] = fn()
        return lambda: name
    except Exception:
        return fn


SLASH = _cached_mesh('fx_slash', lambda: arc_mesh(1.3, .6))
SLASH_IN = _cached_mesh('fx_slash_in', lambda: arc_mesh(1.4, .22))
BIG_ARC = _cached_mesh('fx_big_arc', lambda: arc_mesh(3.2, .9, -80, 80))
WAVE_MESH = _cached_mesh('fx_wave', lambda: arc_mesh(1.1, .75, -65, 65))
RING = _cached_mesh('fx_ring', lambda: arc_mesh(.92, .08, 0, 360, 64, full=True))
SPIN_ARC = _cached_mesh('fx_spin', lambda: arc_mesh(2.6, .7, 0, 340, 48))
WING = _cached_mesh('fx_wing', wing_mesh)


def feather_mesh(w=.17):
    """Перо: лист от основания (0,0) к острию (0,-1) в плоскости XY"""
    outline = [(0, 0), (w * .55, -.12), (w, -.38), (w * .85, -.72), (w * .35, -.93), (0, -1),
               (-w * .3, -.92), (-w * .7, -.72), (-w * .8, -.38), (-w * .45, -.12)]
    verts = [Vec3(0, -.45, 0)] + [Vec3(x, y, 0) for x, y in outline]
    uvs = [Vec2(.5, .55)] + [Vec2(.5 + x / (2 * w), 1 + y) for x, y in outline]
    n = len(outline)
    tris = [(0, 1 + i, 1 + (i + 1) % n) for i in range(n)]
    return Mesh(vertices=verts, triangles=tris, uvs=uvs, normals=[Vec3(0, 0, 1)] * len(verts), mode='triangle')


FEATHER = _cached_mesh('fx_feather', feather_mesh)


def feather_wing(parent, col, shade):
    """Белое перьевое крыло (для правой стороны; левое — зеркалом по X).
    Кость: плечо → локоть → кисть → кончик, перья веером вниз-наружу, сверху кроющие"""
    pts = [(0, 0), (.5, .42), (1.05, .58), (1.7, .5)]

    def along(t):
        if t < .45:
            u, a, b = t / .45, pts[0], pts[1]
        elif t < .8:
            u, a, b = (t - .45) / .35, pts[1], pts[2]
        else:
            u, a, b = (t - .8) / .2, pts[2], pts[3]
        return a[0] + (b[0] - a[0]) * u, a[1] + (b[1] - a[1]) * u
    # маховые: длинные, к кончику разворачиваются наружу
    n = 12
    for i in range(n):
        k = i / (n - 1)
        x, y = along(.2 + .8 * k)
        part(parent, model=FEATHER(), position=(x, y, -.03), rotation_z=-(8 + 80 * k ** 1.1),
             scale=(1, .62 + .62 * k ** .8, 1), color=shade, double_sided=True)
    # второстепенные
    for i in range(10):
        k = i / 9
        x, y = along(.1 + .7 * k)
        part(parent, model=FEATHER(), position=(x, y, -.015), rotation_z=-(4 + 62 * k),
             scale=(.95, .42 + .3 * k, 1), color=col, double_sided=True)
    # кроющие: два ряда коротких перьев вдоль кости
    for row, (ln, dy) in enumerate(((.26, -.02), (.16, .02))):
        for i in range(11):
            k = i / 10
            x, y = along(.04 + .9 * k)
            part(parent, model=FEATHER(), position=(x, y + dy, .005 * (row + 1)), rotation_z=-(15 + 45 * k),
                 scale=(.85, ln + .06 * k, 1), color=col, double_sided=True)
    # сама кость крыла
    for a, b in zip(pts, pts[1:]):
        L = math.hypot(b[0] - a[0], b[1] - a[1])
        part(parent, model='rbox', position=((a[0] + b[0]) / 2, (a[1] + b[1]) / 2, .012),
             rotation_z=-math.degrees(math.atan2(b[1] - a[1], b[0] - a[0])), scale=(L + .04, .055, .05), color=col)


def cap_mesh(r=1.0, th0=0.0, th1=75.0, segs=18, rings=6):
    """Сферический пояс от полярного угла th0 до th1 (от +Y) — веко глаза"""
    verts, uvs, norms, tris = [], [], [], []
    for i in range(rings + 1):
        th = math.radians(th0 + (th1 - th0) * i / rings)
        for j in range(segs + 1):
            ph = j / segs * math.tau
            n = Vec3(math.sin(th) * math.sin(ph), math.cos(th), math.sin(th) * math.cos(ph))
            verts.append(n * r)
            norms.append(n)
            uvs.append(Vec2(j / segs, i / rings))
    w = segs + 1
    for i in range(rings):
        for j in range(segs):
            a, b, c, d = i * w + j, i * w + j + 1, (i + 1) * w + j, (i + 1) * w + j + 1
            tris += [(a, c, b), (b, c, d)]
    return Mesh(vertices=verts, triangles=tris, uvs=uvs, normals=norms, mode='triangle')



# =====================================================================
# частицы и эффекты
# =====================================================================
particles = []
# пул: частицы создаются один раз и переиспользуются — без постоянного создания и удаления объектов
POOL = {'glow': [], 'cube': []}
for _i in range(320):
    _q = Entity(model='quad', texture='glow', billboard=True, enabled=False)
    _q.unlit = True
    POOL['glow'].append(_q)
for _i in range(220):
    _c = Entity(model='cube', enabled=False)
    _c.unlit = True
    POOL['cube'].append(_c)


def burst(pos, n, col, speed=6.0, size=.13, life=.7, grav=12.0, glow=False):
    pool = POOL['glow' if glow else 'cube']
    for _ in range(n):
        if not pool:
            return
        e = pool.pop()
        e.position = pos
        e.color = col
        if glow:
            e.scale = size * random.uniform(1.5, 3)
        else:
            e.scale = size * random.uniform(.6, 1.4)
            e.rotation = (random.uniform(0, 360), random.uniform(0, 360), 0)
        e.enabled = True
        v = Vec3(random.uniform(-1, 1), random.uniform(-.2, 1), random.uniform(-1, 1)).normalized()
        particles.append([e, v * random.uniform(.3, 1) * speed + Vec3(0, speed * .3, 0), life, life, grav, pool])


def ghost(pos, rot_y, col):
    pool = POOL['cube']
    if not pool:
        return
    e = pool.pop()
    e.position = pos
    e.rotation = (0, rot_y, 0)
    e.scale = (.6, 1.9, .35)
    e.color = col
    e.enabled = True
    particles.append([e, Vec3(0, 0, 0), .22, .22, 0, pool])


def update_particles(dt):
    alive = []
    k = 1 - dt * 1.8
    for p in particles:
        e, v, life, mx, g, pool = p
        if g:
            v = Vec3(v[0], v[1] - g * dt, v[2])
            p[1] = v
        if v[0] or v[1] or v[2]:
            e.position += v * dt
        p[2] -= dt
        e.scale *= k
        if g > 0 and e.y < .02:
            e.y = .02
            p[1] = Vec3(v[0] * .5, -v[1] * .3, v[2] * .5)
        if p[2] <= 0:
            e.enabled = False
            pool.append(e)
        else:
            alive.append(p)
    particles[:] = alive
    update_popups(dt)


def flash_fx(mesh_fn, pos, rot, col, s0=.8, s1=1.2, dur=.22, delay=0):
    def go():
        e = Entity(model=mesh_fn(), position=pos, rotation=rot, color=col, scale=s0, double_sided=True)
        e.unlit = True
        e.animate_scale(s1, duration=dur, curve=curve.out_expo)
        e.fade_out(duration=dur)
        destroy(e, delay=dur + .05)
    if delay:
        invoke(go, delay=delay)
    else:
        go()


def decal(pos, radius, col=None, dur=.6, grow=True, life=None):
    e = Entity(model='quad', texture='decal_ring', rotation_x=90, position=Vec3(pos[0], .04, pos[2]),
               scale=.01 if grow else radius * 2, color=col or C('#ff2a2a', .75), double_sided=True)
    e.unlit = True
    if grow:
        e.animate_scale(radius * 2, duration=dur, curve=curve.linear)
    destroy(e, delay=life if life else dur + .05)
    return e


def shockring(pos, radius, col=None, dur=.5):
    e = Entity(model=RING(), position=Vec3(pos[0], .08, pos[2]), scale=.5, double_sided=True,
               color=col or C('#ff4a3d', .9))
    e.unlit = True
    e.animate_scale(radius, duration=dur, curve=curve.out_expo)
    e.fade_out(duration=dur)
    destroy(e, delay=dur + .05)


def ground_crack(pos, heading, length=3.0):
    for i in range(5):
        p = Vec3(pos) + dir_of(heading + random.uniform(-35, 35)) * random.uniform(.4, length)
        burst(Vec3(p[0], .1, p[2]), 3, C('#3a2a2c'), 4, .18, .7)
    burst(Vec3(pos[0], .2, pos[2]), 8, EMBER, 5, .1, .4, glow=True)


def eruption(pos, delay=0):
    def go():
        sp = Entity(model='diamond', position=Vec3(pos[0], -1.2, pos[2]), scale=(.6, 2.8, .6), color=C('#ff2a2a', .9),
                    rotation_y=random.uniform(0, 90))
        sp.unlit = True
        sp.animate_y(.6, duration=.12, curve=curve.out_expo)
        sp.fade_out(duration=.35, delay=.15)
        destroy(sp, delay=.55)
        burst(Vec3(pos[0], .3, pos[2]), 6, C('#2a1a1c'), 6, .2, .7)
        burst(Vec3(pos[0], .5, pos[2]), 4, EMBER, 4, .1, .4, glow=True)
        add_flash(Vec3(pos[0], 1, pos[2]), (1, .2, .1), 5, .25)
    invoke(go, delay=delay)


POPUPS = []
_popup_i = [0]
_probe = Entity()


def update_popups(dt):
    for p in POPUPS:
        t = p[0]
        if p[1] > 0:
            p[1] -= dt
            t.y += dt * .1
            if p[1] < .35:
                t.alpha = max(0, p[1] / .35)
            if p[1] <= 0:
                t.enabled = False


def popup_number(world_pos, txt, col=BONE, big=False):
    if not POPUPS:
        for _i in range(24):
            POPUPS.append([Text(parent=camera.ui, text='', origin=(0, 0), z=-.02, enabled=False), 0])
    _probe.position = world_pos
    sp = _probe.screen_position
    if abs(sp[0]) > 1 or abs(sp[1]) > .6:
        return
    p = POPUPS[_popup_i[0] % len(POPUPS)]
    _popup_i[0] += 1
    t = p[0]
    set_text(t, txt)
    t.position = (sp[0] + random.uniform(-.02, .02), sp[1])
    t.scale = 2.3 if big else 1.4
    t.color = col
    t.enabled = True
    p[1] = .8


def blob_shadow(parent, size=1.0):
    s = Entity(parent=parent, model='quad', texture='shadow', rotation_x=90, y=.03, scale=size, color=C('#000000', .8))
    s.unlit = True
    return s


# =====================================================================
# UI — в духе Genshin: мини-карта слева сверху, навыки справа снизу, здоровье по центру
# =====================================================================
def ui_quad(**kw):
    kw.setdefault('parent', camera.ui)
    kw.setdefault('model', 'quad')
    return Entity(**kw)


AR = window.aspect_ratio
if SCREEN and SCREEN[1]:
    AR = SCREEN[0] / SCREEN[1]     # точное соотношение сторон монитора, например 1920×1200 = 16:10
EDGE = AR / 2 - .035          # край экрана при любом соотношении сторон
PANEL = C('#12060a', .78)
UI_BG = C('#0c0e13', .86)
UI_HEAD = C('#1b1f29', .94)
BRONZE = C('#8a6d45')
BRONZE_HI = C('#d9b47c')
GOLD_T = C('#ecd7aa')
TXT = C('#d8d0c4')
MUTED = C('#8f877b')
BTN = C('#222935', .95)
BTN_HI = C('#344052')
BTN_PRESS = C('#4a5a70')
BTN_RED = C('#5c1219', .96)
BTN_RED_HI = C('#80202a')
LINE = C('#f1e3dc', .18)

vignette = ui_quad(texture='vignette', scale=(AR * 1.02, 1.02), z=.5, color=C('#000000', 1))


def pie_mesh(frac, segs=40):
    """Сектор круга для откатов: от 12 часов по часовой стрелке"""
    verts, tris = [Vec3(0, 0, 0)], []
    n = max(1, int(segs * frac))
    for i in range(n + 1):
        a = math.tau * frac * i / n
        verts.append(Vec3(math.sin(a) * .5, math.cos(a) * .5, 0))
    for i in range(n):
        tris.append((0, i + 2, i + 1))
    return Mesh(vertices=verts, triangles=tris, mode='triangle')


class Pie(Entity):
    def __init__(self, **kw):
        super().__init__(**kw)
        self.frac = -1
        self.set(0)

    def set(self, frac):
        frac = max(0.0, min(1.0, frac))
        step = round(frac * 40) / 40
        if step == self.frac:
            return
        self.frac = step
        if step <= 0:
            self.visible = False
            return
        self.visible = True
        self.model = pie_mesh(step)


class SkillButton:
    def __init__(self, x, y, size, key, ring_col=None):
        self.root = Entity(parent=hud, position=(x, y))
        self.size = size
        ui_quad(parent=self.root, model='circle', scale=size * 1.12, color=Color(BRONZE[0], BRONZE[1], BRONZE[2], .8),
                z=.02)
        self.bg = ui_quad(parent=self.root, model='circle', scale=size, color=C('#14070b', .85), z=.01)
        self.fill = Pie(parent=self.root, scale=size * .98, color=ring_col or BLOOD, z=.005)
        self.inner = ui_quad(parent=self.root, model='circle', scale=size * .84, color=C('#14070b', .92), z=0)
        self.icon = ui_quad(parent=self.root, scale=size * .58, color=BONE, z=-.01)
        self.cd = Pie(parent=self.root, scale=size * .84, color=C('#000000', .62), z=-.02)
        self.cd_text = Text(parent=self.root, text='', origin=(0, 0), scale=1.1 * size / .09, color=WHITE, z=-.03)
        self.key = Text(parent=self.root, text=key, origin=(0, 0), position=(size * .36, -size * .36), z=-.03,
                        scale=.7, color=C('#d8c0c0'))

    def set_icon(self, tex):
        self.icon.texture = tex

    def update(self, cd, cd_max, ready_frac=None, glow=False):
        if cd > 0:
            self.cd.set(cd / max(.01, cd_max))
            set_text(self.cd_text, f'{cd:.1f}' if cd < 10 else str(int(cd)))
            self.icon.alpha = .45
        else:
            self.cd.set(0)
            set_text(self.cd_text, '')
            self.icon.alpha = 1
        if ready_frac is not None:
            self.fill.set(ready_frac)
        k = 1 + (.07 * math.sin(game.clock * 7) if glow else 0)
        self.bg.scale = self.size * k


hud = Entity(parent=camera.ui)

# --- мини-карта
class Minimap:
    R = .115

    def __init__(self):
        self.root = Entity(parent=hud, position=(-EDGE + self.R + .015, .5 - self.R - .03))
        ui_quad(parent=self.root, model='circle', scale=self.R * 2 + .012, color=BRONZE, z=.03)
        ui_quad(parent=self.root, model='circle', scale=self.R * 2, color=C('#0e0508', .82), z=.02)
        self.room = ui_quad(parent=self.root, color=C('#3a1a20', .9), z=.01)
        self.gate = ui_quad(parent=self.root, color=GOLD, z=0)
        self.pillars = []
        self.dots = [ui_quad(parent=self.root, model='circle', scale=.012, color=C('#ff3030'), z=-.01) for _ in range(48)]
        self.me = ui_quad(parent=self.root, model='diamond' if False else 'quad', scale=(.012, .022), color=WHITE, z=-.02)
        self.view = ui_quad(parent=self.root, scale=(.003, .05), origin=(0, -.5), color=C('#ffffff', .35), z=-.015)
        Text(parent=self.root, text='С', origin=(0, 0), y=self.R + .012, scale=.75, color=GOLD, z=-.03)
        self.key = None

    def k(self):
        return (self.R * 1.6) / max(dungeon.w, dungeon.d)

    def rebuild(self):
        k = self.k()
        self.room.scale = (dungeon.w * k, dungeon.d * k)
        self.gate.scale = (4 * k, .006)
        self.gate.y = dungeon.d / 2 * k
        for p in self.pillars:
            destroy(p)
        self.pillars = [ui_quad(parent=self.root, model='circle', scale=pr * 2 * k, position=(px * k, pz * k),
                                color=C('#7a5a60', .9), z=.005) for px, pz, pr in dungeon.pillars]
        self.key = (dungeon.level, dungeon.room, id(dungeon.root))

    def update(self):
        if self.key != (dungeon.level, dungeon.room, id(dungeon.root)):
            self.rebuild()
        k = self.k()
        self.gate.color = GOLD if dungeon.cleared else C('#ff2030')
        for i, d in enumerate(self.dots):
            if i < len(enemies):
                e = enemies[i]
                d.enabled = True
                d.position = (e.x * k, e.z * k)
                d.scale = .03 if e.boss else (.017 if e.elite else .012)
                d.color = C('#ffb020') if e.elite else C('#ff3030')
            else:
                d.enabled = False
        self.me.position = (player.x * k, player.z * k)
        self.me.rotation_z = player.rotation_y
        self.view.position = self.me.position
        self.view.rotation_z = cam.yaw


minimap = Minimap()
room_text = Text(parent=hud, text='', origin=(-.5, .5), position=(-EDGE, minimap.root.y - Minimap.R - .03),
                 scale=.85, color=C('#e8d0d0'))
wave_text = Text(parent=hud, text='', origin=(-.5, .5), position=(-EDGE, minimap.root.y - Minimap.R - .058),
                 scale=.75, color=C('#b09090'))

# --- справа сверху: счёт и комбо
kills_text = Text(parent=hud, text='0', position=(EDGE, .47), origin=(.5, .5), scale=1.9, color=BONE)
kills_lbl = Text(parent=hud, text='изгнано демонов', position=(EDGE, .415), origin=(.5, .5), scale=.75,
                 color=C('#b09090'))
diff_lbl = Text(parent=hud, text='', position=(EDGE, .315), origin=(.5, .5), scale=.7, color=C('#ff8a80'))
rank_text = Text(parent=hud, text='', position=(EDGE - .02, .22), origin=(.5, 0), scale=3.2, color=EMBER)
combo_text = Text(parent=hud, text='', position=(EDGE - .02, .15), origin=(.5, 0), scale=1.2, color=BONE)
name_pop = Text(parent=camera.ui, text='', position=(0, .3), origin=(0, 0), scale=2.4, color=EMBER, z=-.05)

# --- здоровье по центру снизу
HPW = .46
hp_name = Text(parent=hud, text='', position=(-HPW / 2, -.405), origin=(-.5, 0), scale=.95, color=BONE)
hp_text = Text(parent=hud, text='', position=(HPW / 2, -.405), origin=(.5, 0), scale=.8, color=C('#d8c0c0'))
ui_quad(parent=hud, scale=(HPW + .008, .02), position=(0, -.43), color=BRONZE)
ui_quad(parent=hud, scale=(HPW, .013), position=(0, -.43), color=C('#1a0609', .95), z=-.005)
hp_lag = ui_quad(parent=hud, scale=(HPW, .013), position=(-HPW / 2, -.43), origin=(-.5, 0), color=C('#ffd0c0'), z=-.008)
hp_fill = ui_quad(parent=hud, scale=(HPW, .013), position=(-HPW / 2, -.43), origin=(-.5, 0), color=C('#d7263a'), z=-.01)
energy_fill = ui_quad(parent=hud, scale=(HPW, .004), position=(-HPW / 2, -.444), origin=(-.5, 0), color=EMBER, z=-.01)

# --- навыки справа снизу
btn_attack = SkillButton(EDGE - .085, -.385, .12, 'ЛКМ')
btn_heavy = SkillButton(EDGE - .215, -.425, .075, 'ПКМ')
btn_skill = SkillButton(EDGE - .205, -.31, .09, 'E')
btn_ult = SkillButton(EDGE - .085, -.235, .105, 'Q')
btn_dash = SkillButton(EDGE - .315, -.385, .065, 'Shift')
btn_dash.set_icon('icon_dash')
btn_heal = SkillButton(EDGE - .32, -.28, .07, 'H', ring_col=C('#8affb0'))
btn_range = SkillButton(EDGE - .2, -.2, .068, 'R', ring_col=C('#5fe8c8', .85))
btn_range.set_icon('icon_cross')
btn_heal.set_icon('icon_heal')
heal_cost = Text(parent=hud, text='', origin=(0, 0), position=(EDGE - .32, -.228), scale=.7, color=C('#c8a0ff'))
souls_text = Text(parent=hud, text='', position=(EDGE, .355), origin=(.5, .5), scale=1.1, color=C('#c8a0ff'))

boss_root = Entity(parent=camera.ui, enabled=False)
boss_name = Text(parent=boss_root, text='', position=(0, .44), origin=(0, 0), scale=1.15, color=BONE)
ui_quad(parent=boss_root, scale=(.9, .022), position=(0, .405), color=BRONZE)
ui_quad(parent=boss_root, scale=(.88, .013), position=(0, .405), color=C('#1a0609', .95), z=-.005)
boss_fill = ui_quad(parent=boss_root, scale=(.88, .013), position=(-.44, .405), origin=(-.5, 0), color=BLOOD, z=-.01)

hurt_overlay = ui_quad(scale=(4, 2), color=C('#c3121e', 0), z=-.05)
tint = ui_quad(scale=(4, 2), color=C('#2a0004', 0), z=-.1)
bar_top = ui_quad(scale=(4, .2), y=.62, color=color.black, z=-.12)
bar_bot = ui_quad(scale=(4, .2), y=-.62, color=color.black, z=-.12)
white = ui_quad(scale=(4, 2), color=C('#fff4ef', 0), z=-.3)
fader = ui_quad(scale=(4, 2), color=C('#000000', 0), z=-.4)

# =====================================================================
# СТИЛЬ ИНТЕРФЕЙСА: тёмные полупрозрачные панели, тонкая бронзовая рамка, ромбы по углам,
# заголовок на полосе, светлое золото для заголовков — в духе тёмного фэнтези-MMO
# =====================================================================
LINE_H = Text.size * 1.25 if hasattr(Text, 'size') else .031     # высота строки текста при scale=1


def ui_frame(parent, pos, size, z=.05, bg=UI_BG, border=BRONZE, corners=True, thick=.0022):
    """Панель: фон, тонкая рамка и ромбики по углам. pos — центр"""
    root = Entity(parent=parent, position=(pos[0], pos[1]))
    w, h = size
    root.bg = ui_quad(parent=root, scale=(w, h), color=bg, z=z)
    root.borders = []
    for (x, y, sx, sy) in ((0, h / 2, w, thick), (0, -h / 2, w, thick), (-w / 2, 0, thick, h), (w / 2, 0, thick, h)):
        root.borders.append(ui_quad(parent=root, position=(x, y), scale=(sx, sy), color=border, z=z - .002))
    if corners:
        for x, y in ((-w / 2, h / 2), (w / 2, h / 2), (-w / 2, -h / 2), (w / 2, -h / 2)):
            root.borders.append(ui_quad(parent=root, position=(x, y), scale=.011, rotation_z=45, color=BRONZE_HI,
                                        z=z - .004))
    return root


def ui_set_border(frame, col):
    for b in frame.borders[:4]:
        b.color = col


def ui_panel(parent, pos, size, title='', z=.05):
    """Панель с заголовком на полосе сверху. Возвращает рамку; левый верхний угол содержимого — frame.ix, frame.iy"""
    f = ui_frame(parent, pos, size, z=z)
    w, h = size
    if title:
        ui_quad(parent=f, position=(0, h / 2 - .024), scale=(w - .006, .044), color=UI_HEAD, z=z - .001)
        ui_quad(parent=f, position=(0, h / 2 - .047), scale=(w - .02, .0016), color=Color(BRONZE_HI[0], BRONZE_HI[1],
                                                                                         BRONZE_HI[2], .55), z=z - .003)
        f.title = Text(parent=f, text=title, origin=(-.5, 0), position=(-w / 2 + .018, h / 2 - .024), scale=.95,
                       color=GOLD_T, z=z - .01)
    f.ix = -w / 2 + .02
    f.iy = h / 2 - (.064 if title else .02)
    f.w, f.h = w, h
    return f


def wrap_text(txt, width=46):
    """Перенос строк по числу букв (запасной вариант)"""
    lines, cur = [], ''
    for w in txt.split():
        if cur and len(cur) + 1 + len(w) > width:
            lines.append(cur)
            cur = w
        else:
            cur = (cur + ' ' + w).strip()
    if cur:
        lines.append(cur)
    return '\n'.join(lines)


_measure = None


def text_w(txt, scale):
    """Ширина строки на экране; если движок не умеет мерить — оценка по числу букв"""
    global _measure
    try:
        if _measure is None:
            _measure = Text(text='', enabled=False)
        _measure.text = txt
        w = _measure.width
        if isinstance(w, (int, float)) and w > 0:
            return w * scale
    except Exception:
        pass
    return len(txt) * .0142 * scale


def fit_text(txt, max_w, scale):
    """Перенос по реальной ширине строки: текст не вылезает за рамку"""
    out = []
    for para in txt.split('\n'):
        cur = ''
        for word in para.split():
            cand = (cur + ' ' + word).strip()
            if cur and text_w(cand, scale) > max_w:
                out.append(cur)
                cur = word
            else:
                cur = cand
        out.append(cur)
    return '\n'.join(out)


def text_h(txt, scale):
    return (txt.count('\n') + 1) * LINE_H * scale


def ui_button(parent, txt, pos, size, on_click, primary=False, scale=.95, name=None):
    col, hi = (BTN_RED, BTN_RED_HI) if primary else (BTN, BTN_HI)
    b = Button(parent=parent, position=pos, scale=size, color=col, highlight_color=hi, pressed_color=BTN_PRESS,
               on_click=on_click)
    fr = ui_frame(parent, pos, size, z=-.001, bg=C('#000000', 0), border=BRONZE_HI if primary else BRONZE,
                  corners=primary)
    t = Text(parent=parent, text=txt, position=pos, origin=(0, 0), scale=scale, color=GOLD_T if primary else TXT,
             z=-.02)
    if name:
        ui_buttons[name] = (b, t, fr)
    return b


ui_buttons = {}

# --- заставка: врата подземелья (сама сцена строится в 3D ниже)
title_root = Entity(parent=camera.ui)
ui_quad(parent=title_root, scale=(1.3, .0018), y=.262, color=Color(BRONZE_HI[0], BRONZE_HI[1], BRONZE_HI[2], .7))
ui_quad(parent=title_root, scale=(1.3, .0018), y=.168, color=Color(BRONZE_HI[0], BRONZE_HI[1], BRONZE_HI[2], .7))
ui_quad(parent=title_root, scale=.014, rotation_z=45, position=(-.65, .262), color=BRONZE_HI)
ui_quad(parent=title_root, scale=.014, rotation_z=45, position=(.65, .262), color=BRONZE_HI)
ui_quad(parent=title_root, scale=.014, rotation_z=45, position=(-.65, .168), color=BRONZE_HI)
ui_quad(parent=title_root, scale=.014, rotation_z=45, position=(.65, .168), color=BRONZE_HI)
title_logo = Text(parent=title_root, text='БЕЗДНА ПРОКЛЯТЫХ', origin=(0, 0), y=.215, scale=3.4, color=C('#e8c79a'))
Text(parent=title_root, text='под Японией есть печать  ·  она слабеет', origin=(0, 0), y=.135, scale=1.05, color=TXT)
title_hint = Text(parent=title_root, text='ЛКМ или Enter — открыть врата', origin=(0, 0), y=-.36, scale=1.25,
                  color=GOLD_T)
title_best = Text(parent=title_root, text='', origin=(0, 0), y=-.41, scale=.85, color=MUTED)
GAME_VERSION = 'v28'
dlog('version', GAME_VERSION, 'screen', SCREEN, 'window', tuple(getattr(window, 'size', (0, 0))), 'AR', round(AR, 3))
Text(parent=title_root, text='версия ' + GAME_VERSION, origin=(.5, -.5), position=(EDGE, -.485), scale=.75,
     color=MUTED)
Text(parent=title_root, text='F9 — простая графика, если всё чёрное   ·   F11 — полный экран   ·   F10 — выход',
     origin=(-.5, -.5), position=(-EDGE, -.485), scale=.75, color=MUTED)

# --- выбор героя: герои стоят в зале, карточки снизу, сведения о герое в панели слева
DIFFS = [('ОБЫЧНО', dict(hp=1.0, dmg=1.0, tempo=1.0, extra=0, elite=0.0)),
         ('СЛОЖНО', dict(hp=1.5, dmg=1.5, tempo=1.12, extra=2, elite=.06)),
         ('КОШМАР', dict(hp=2.2, dmg=2.1, tempo=1.25, extra=4, elite=.14))]

select_root = Entity(parent=camera.ui, enabled=False)
SEL_W, SEL_H = .62, .68
sel_panel = ui_panel(select_root, (-EDGE + SEL_W / 2, .47 - SEL_H / 2), (SEL_W, SEL_H), 'ГЕРОЙ')
SEL_X = sel_panel.x + sel_panel.ix
SEL_TOP = sel_panel.y + sel_panel.iy
SEL_TW = SEL_W - .04            # ширина текста внутри панели
sel_name = Text(parent=select_root, text='', position=(SEL_X, SEL_TOP), origin=(-.5, .5), scale=2.4, color=BLOOD)
sel_title = Text(parent=select_root, text='', position=(SEL_X, SEL_TOP - .07), origin=(-.5, .5), scale=.95,
                 color=GOLD_T)
sel_desc = Text(parent=select_root, text='', position=(SEL_X, SEL_TOP - .11), origin=(-.5, .5), scale=.78, color=TXT)
sel_bars = []
for i in range(4):
    lbl = Text(parent=select_root, text='', position=(SEL_X, 0), origin=(-.5, 0), scale=.75, color=MUTED)
    bg = ui_quad(parent=select_root, scale=(.34, .009), position=(SEL_X + .2, 0), origin=(-.5, 0), color=C('#262a33'))
    f = ui_quad(parent=select_root, scale=(.34, .009), position=(SEL_X + .2, 0), origin=(-.5, 0), color=BLOOD, z=-.01)
    sel_bars.append((lbl, f, bg))
sel_moves_head = Text(parent=select_root, text='ПРИЁМЫ', position=(SEL_X, 0), origin=(-.5, .5), scale=.8,
                      color=GOLD_T)
sel_moves = Text(parent=select_root, text='', position=(SEL_X, 0), origin=(-.5, .5), scale=.72, color=TXT)

# подсказки справа сверху
hint_panel = ui_panel(select_root, (EDGE - .17, .47 - .085), (.34, .17), 'УПРАВЛЕНИЕ')
sel_hint = Text(parent=select_root, text='A / D — сменить героя\n1  2  3 — сложность\nEnter — новая игра\nC — продолжить с чекпоинта',
                position=(hint_panel.x + hint_panel.ix, hint_panel.y + hint_panel.iy), origin=(-.5, .5), scale=.75,
                color=TXT)

# карточки героев снизу по центру
CARD_W, CARD_H, CARD_Y = .34, .09, -.305
CARD_X0 = -EDGE + SEL_W + .03 + CARD_W / 2     # карточки правее панели героя
hero_cards = []


def make_hero_cards():
    n = len(HEROES)
    for i, H in enumerate(HEROES):
        x = CARD_X0 + i * (CARD_W + .025)
        b = Button(parent=select_root, position=(x, CARD_Y), scale=(CARD_W, CARD_H), color=C('#0c0e13', .86),
                   highlight_color=C('#1c2230', .9), pressed_color=C('#2a3344'),
                   on_click=lambda i=i: game.pick_hero(i - game.hero_i))
        fr = ui_frame(select_root, (x, CARD_Y), (CARD_W, CARD_H), z=-.001, bg=C('#000000', 0))
        ui_quad(parent=select_root, position=(x - CARD_W / 2 + .05, CARD_Y), scale=(.07, .07), color=C('#1d2230'),
                z=-.01)
        ic = ui_quad(parent=select_root, position=(x - CARD_W / 2 + .05, CARD_Y), scale=(.055, .055),
                     texture=H.ICONS[0], color=GOLD_T, z=-.02)
        nm = Text(parent=select_root, text=H.NAME, origin=(-.5, 0), position=(x - CARD_W / 2 + .1, CARD_Y + .016),
                  scale=1.0, color=GOLD_T, z=-.02)
        rs = .68
        while rs > .45 and text_w(H.ROLE, rs) > CARD_W - .14:
            rs -= .02
        role = Text(parent=select_root, text=H.ROLE, origin=(-.5, 0), position=(x - CARD_W / 2 + .1, CARD_Y - .02),
                    scale=rs, color=MUTED, z=-.02)
        mark = ui_quad(parent=select_root, position=(x + CARD_W / 2 - .022, CARD_Y + CARD_H / 2 - .022), scale=.016,
                       rotation_z=45, color=C('#6fe08a'), z=-.02)
        hero_cards.append((b, fr, ic, nm, mark))


# сложность и «в бой» под карточками
for i, (dn, _) in enumerate(DIFFS):
    ui_button(select_root, dn, (CARD_X0 - CARD_W / 2 + .0625 + i * .135, -.43), (.125, .045),
              lambda i=i: game.set_diff(i), scale=.8, name=f'diff{i}')
ui_button(select_root, 'НОВАЯ ИГРА', (CARD_X0 - CARD_W / 2 + .405 + .03 + .13, -.43), (.26, .055),
          lambda: game.new_game(), primary=True, scale=1.05, name='go')
GO_X = CARD_X0 - CARD_W / 2 + .405 + .03 + .13
cont_root = Entity(parent=select_root)
ui_button(cont_root, 'ПРОДОЛЖИТЬ', (GO_X + .13 + .015 + .09, -.43), (.18, .055), lambda: game.continue_save(),
          scale=.8, name='cont')
cont_info = Text(parent=cont_root, text='', origin=(.5, .5), position=(EDGE, -.462), scale=.6, color=MUTED)
Text(parent=select_root, text='СЛОЖНОСТЬ', origin=(-.5, 0), position=(CARD_X0 - CARD_W / 2, -.378), scale=.7,
     color=MUTED)

# кнопки справа снизу: графика, экран, выход
for k, (lbl, key, fn) in enumerate((('Графика', 'F9', lambda: input('f9')), ('Экран', 'F11', lambda: input('f11')),
                                    ('Выход', 'F10', lambda: application.quit()))):
    x = EDGE - .045 - (2 - k) * .095
    ui_button(select_root, key, (x, .245), (.07, .05), fn, scale=.85)
    Text(parent=select_root, text=lbl, origin=(0, .5), position=(x, .213), scale=.62, color=MUTED)

# --- поражение / победа / пауза
over_root = Entity(parent=camera.ui, enabled=False, z=-.15)
ui_quad(parent=over_root, scale=(4, 2), color=C('#050608', .55), z=.1)
ui_frame(over_root, (0, .0), (1.15, .4), z=.06)
over_title = Text(parent=over_root, text='', origin=(0, 0), y=.1, scale=3.2, color=BLOOD)
over_info = Text(parent=over_root, text='', origin=(0, 0), y=-.01, scale=1.0, color=TXT)
over_hint = Text(parent=over_root, text='', origin=(0, 0), y=-.12, scale=1.0, color=GOLD_T)

pause_root = Entity(parent=camera.ui, enabled=False, z=-.15)
ui_quad(parent=pause_root, scale=(4, 2), color=C('#050608', .6), z=.1)
pause_panel = ui_panel(pause_root, (0, .05), (1.2, .5), 'ПАУЗА')
pause_help = Text(parent=pause_root, text='', origin=(-.5, .5), position=(pause_panel.x + pause_panel.ix, pause_panel.y + pause_panel.iy - .005),
                  scale=.82, color=TXT)
Text(parent=pause_root, text='Esc — продолжить   ·   N — новая игра   ·   M — меню героев   ·   F10 — выйти',
     origin=(0, 0), y=-.17, scale=.8, color=GOLD_T)


def banner(txt, col=BONE, sub='', z=-.02):
    t = Text(parent=camera.ui, text=txt, origin=(0, 0), y=.24, scale=3.4, color=col, z=z)
    t.scale *= 1.4
    t.animate_scale(t.scale / 1.4, duration=.35, curve=curve.out_back)
    t.fade_out(duration=.6, delay=1.6)
    destroy(t, delay=2.3)
    if sub:
        s = Text(parent=camera.ui, text=sub, origin=(0, 0), y=.175, scale=1.2, color=BONE, z=z)
        s.fade_out(duration=.6, delay=1.6)
        destroy(s, delay=2.3)


def show_move_name(txt):
    name_pop.text = txt
    name_pop.color = player.FX_GLOW if player else EMBER
    name_pop.scale = 3.0
    name_pop.animate_scale(2.2, duration=.25, curve=curve.out_back)
    name_pop.fade_out(duration=.4, delay=.8)
    sfx('combo', .5, 1)


player = None


# =====================================================================
# САМУРАЙ: риг из суставов и позы для анимаций
# =====================================================================
ALONG = (88, 0, 0)    # запястье: клинок продолжает руку

BASE = {
    'torso': (5, 0, 0), 'head': (0, 0, 0),
    'sh_r': (-35, 15, -8), 'el_r': -45, 'wr_r': (60, 0, 0),
    'sh_l': (-40, -30, 12), 'el_l': -50,
    'hip_l': -12, 'knee_l': 18, 'hip_r': 14, 'knee_r': 12,
    'crouch': -.06, 'spin': 0, 'wr_l': (0, 0, 0),
    # таз и разворот ног: стойка, перенос веса, носки врозь
    'pel': (0, 0, 0), 'ly_l': 0, 'lz_l': 0, 'ly_r': 0, 'lz_r': 0, 'bx': 0, 'bz': 0,
}


def rot3(v, r):
    """Поворот точки как у Ursina: крен (z), тангаж (x), рыскание (y)"""
    x, y, z = v
    rx, ry, rz = r
    if rz:
        a = math.radians(rz)
        c, s_ = math.cos(a), math.sin(a)
        x, y = x * c + y * s_, -x * s_ + y * c
    if rx:
        a = math.radians(rx)
        c, s_ = math.cos(a), math.sin(a)
        y, z = y * c - z * s_, y * s_ + z * c
    if ry:
        a = math.radians(ry)
        c, s_ = math.cos(a), math.sin(a)
        x, z = x * c + z * s_, -x * s_ + z * c
    return x, y, z


def P(**kw):
    p = dict(BASE)
    p.update(kw)
    return p


def PI(base, **kw):
    p = dict(base)
    p.update(kw)
    return p


def lerp_v(a, b, k):
    if isinstance(a, tuple):
        return tuple(a[i] + (b[i] - a[i]) * k for i in range(len(a)))
    return a + (b - a) * k


def blend(a, b, k):
    return {key: lerp_v(a[key], b[key], k) for key in a}


def _herm(a, b, ma, mb, h00, h10, h01, h11):
    if isinstance(a, tuple):
        return tuple(a[i] * h00 + ma[i] * h10 + b[i] * h01 + mb[i] * h11 for i in range(len(a)))
    return a * h00 + ma * h10 + b * h01 + mb * h11


def _tan(pa, pb, ta, tb, seg):
    """Касательная сплайна Катмулла-Рома для неравномерных ключей"""
    k = seg / max(1e-6, tb - ta)
    out = {}
    for key, va in pa.items():
        vb = pb[key]
        if isinstance(va, tuple):
            out[key] = tuple((vb[i] - va[i]) * k for i in range(len(va)))
        else:
            out[key] = (vb - va) * k
    return out


_ZERO_TAN = {}


def sample(keys, t):
    """Плавная анимация: сплайн через ключи, скорость не обрывается на каждом ключе"""
    if t <= keys[0][0]:
        return keys[0][1]
    n = len(keys)
    for i in range(n - 1):
        t0, p0 = keys[i][0], keys[i][1]
        t1, p1 = keys[i + 1][0], keys[i + 1][1]
        if t <= t1:
            seg = t1 - t0
            u = (t - t0) / max(1e-6, seg)
            # первый и последний отрезки мягко трогаются и останавливаются
            if i > 0:
                m0 = _tan(keys[i - 1][1], p1, keys[i - 1][0], t1, seg)
            else:
                m0 = None
            if i + 2 < n:
                m1 = _tan(p0, keys[i + 2][1], t0, keys[i + 2][0], seg)
            else:
                m1 = None
            u2, u3 = u * u, u * u * u
            h00, h10, h01, h11 = 2 * u3 - 3 * u2 + 1, u3 - 2 * u2 + u, -2 * u3 + 3 * u2, u3 - u2
            out = {}
            for key, a in p0.items():
                b = p1[key]
                if isinstance(a, tuple):
                    ma = m0[key] if m0 else (0,) * len(a)
                    mb = m1[key] if m1 else (0,) * len(a)
                else:
                    ma = m0[key] if m0 else 0
                    mb = m1[key] if m1 else 0
                out[key] = _herm(a, b, ma, mb, h00, h10, h01, h11)
            return out
    return keys[-1][1]


# --- таблица приёмов ---
# hits: (t, тип, параметры), fx: (t, эффект, параметры), move: (t0, t1, дистанция)
ACTIONS = {
    'L1': dict(dur=.36, cancel=.5, keys=[
        (0, P(torso=(5, 45, 0), sh_r=(-80, 75, 0), el_r=-15, wr_r=ALONG, sh_l=(-70, 40, 0), el_l=-30, crouch=-.1)),
        (.45, P(torso=(5, -10, 0), sh_r=(-85, -10, 0), el_r=-5, wr_r=ALONG, sh_l=(-80, -20, 0), el_l=-20)),
        (.7, P(torso=(5, -40, 0), sh_r=(-80, -75, 0), el_r=-10, wr_r=ALONG, sh_l=(-70, -60, 0), el_l=-25)),
        (1, P())],
        hits=[(.38, 'arc', dict(reach=3.0, cone=.2, dmg=20, kb=4))],
        fx=[(.25, 'slash', dict(roll=8))], move=[(.1, .45, .55)], snd=1.1),
    'L2': dict(dur=.36, cancel=.5, keys=[
        (0, P(torso=(5, -45, 0), sh_r=(-70, -80, 0), el_r=-10, wr_r=ALONG, sh_l=(-60, -90, 0), el_l=-20, crouch=-.1)),
        (.45, P(torso=(5, 10, 0), sh_r=(-80, 10, 0), el_r=-5, wr_r=ALONG, sh_l=(-75, -10, 0))),
        (.7, P(torso=(5, 45, 0), sh_r=(-75, 80, 0), el_r=-10, wr_r=ALONG, sh_l=(-70, 50, 0))),
        (1, P())],
        hits=[(.38, 'arc', dict(reach=3.0, cone=.2, dmg=22, kb=4))],
        fx=[(.25, 'slash', dict(roll=-8, flip=True))], move=[(.1, .45, .55)], snd=1.0),
    'L3': dict(dur=.42, cancel=.55, keys=[
        (0, P(torso=(22, -25, 0), sh_r=(-15, -40, 10), el_r=-10, wr_r=ALONG, sh_l=(-20, -50, 10), crouch=-.28,
              hip_l=-35, knee_l=50)),
        (.5, P(torso=(-12, 18, 0), sh_r=(-172, 25, 0), el_r=-5, wr_r=ALONG, sh_l=(-150, 10, 0), el_l=-20, crouch=.06,
               head=(-15, 0, 0))),
        (1, P())],
        hits=[(.42, 'arc', dict(reach=3.2, cone=.15, dmg=26, kb=3, height=4.4))],
        fx=[(.3, 'slash', dict(roll=72))], move=[(.1, .45, .4)], snd=.95),
    'L4': dict(dur=.5, cancel=.62, keys=[
        (0, P(torso=(0, 30, 0), sh_r=(-85, 70, 0), el_r=0, wr_r=ALONG, sh_l=(-60, 40, 20), crouch=-.15, spin=0)),
        (.12, P(torso=(0, 30, 0), sh_r=(-85, 75, 0), el_r=0, wr_r=ALONG, sh_l=(-60, 40, 20), crouch=-.18, spin=0)),
        (.75, P(torso=(0, 20, 0), sh_r=(-85, 75, 0), el_r=0, wr_r=ALONG, sh_l=(-60, 40, 20), crouch=-.12, spin=-360)),
        (1, P(spin=-360))],
        hits=[(.35, 'circle', dict(radius=3.4, dmg=16, kb=3)), (.62, 'circle', dict(radius=3.4, dmg=16, kb=5))],
        fx=[(.3, 'spin', {}), (.55, 'spin', {})], move=[(.1, .7, .6)], snd=.9),
    'L5': dict(dur=.58, cancel=.75, keys=[
        (0, P(torso=(-15, 0, 0), sh_r=(-190, 0, 0), el_r=-20, wr_r=ALONG, sh_l=(-185, 0, 0), el_l=-20, crouch=.05,
              head=(-10, 0, 0))),
        (.38, P(torso=(-18, 0, 0), sh_r=(-195, 0, 0), el_r=-25, wr_r=ALONG, sh_l=(-190, 0, 0), el_l=-25, crouch=.08)),
        (.55, P(torso=(26, 0, 0), sh_r=(-62, 0, 0), el_r=0, wr_r=ALONG, sh_l=(-66, 0, 0), el_l=0, crouch=-.3,
                hip_l=-45, knee_l=55, hip_r=30, knee_r=40)),
        (1, P())],
        hits=[(.55, 'arc', dict(reach=4.0, cone=0, dmg=48, kb=7, hitstop=.1, shake=.35))],
        fx=[(.5, 'slash', dict(roll=90, big=True)), (.56, 'crack', {})], move=[(.3, .55, .8)], snd=.8),
    'heavy': dict(dur=.52, cancel=.8, keys=[
        (0, P(torso=(10, -60, 0), sh_r=(-20, -70, 15), el_r=-60, wr_r=(40, 0, 0), sh_l=(-30, -60, 10), crouch=-.32,
              hip_l=-40, knee_l=55, hip_r=30, knee_r=45)),
        (.25, P(torso=(12, -62, 0), sh_r=(-22, -72, 15), el_r=-62, wr_r=(40, 0, 0), sh_l=(-30, -62, 10),
                crouch=-.34, hip_l=-42, knee_l=58, hip_r=32, knee_r=46)),
        (.45, P(torso=(22, 40, 0), sh_r=(-90, 65, 0), el_r=0, wr_r=ALONG, sh_l=(-40, -40, 30), crouch=-.2,
                hip_l=-50, knee_l=40, hip_r=40, knee_r=20)),
        (1, P())],
        hits=[(.46, 'line', dict(width=1.6, dmg=65, kb=5, hitstop=.12, shake=.3))],
        fx=[(.45, 'iai', {})], move=[(.25, .48, 6.5)], inv=(.2, .55), snd=.75, name='ИАЙ: ЛУННЫЙ ВЫПАД'),
    'cross': dict(dur=.5, cancel=.7, keys=[
        (0, P(sh_r=(-170, -40, 0), el_r=-10, wr_r=ALONG, sh_l=(-160, -30, 0), torso=(-5, -15, 0))),
        (.3, P(sh_r=(-30, 40, 0), el_r=0, wr_r=ALONG, sh_l=(-40, 30, 0), torso=(20, 20, 0), crouch=-.2)),
        (.55, P(sh_r=(-170, 40, 0), el_r=-10, wr_r=ALONG, sh_l=(-160, 30, 0), torso=(-5, 15, 0))),
        (.85, P(sh_r=(-30, -40, 0), el_r=0, wr_r=ALONG, sh_l=(-40, -30, 0), torso=(20, -20, 0), crouch=-.2)),
        (1, P())],
        hits=[(.3, 'arc', dict(reach=3.3, cone=.1, dmg=26, kb=3)), (.85, 'arc', dict(reach=3.3, cone=.1, dmg=30, kb=6))],
        fx=[(.22, 'slash', dict(roll=55)), (.78, 'slash', dict(roll=-55, flip=True))], move=[(0, .4, 1.2)],
        snd=1.05, name='КРЕСТ ТЕНИ'),
    'plunge': dict(dur=.5, cancel=.85, keys=[
        (0, P(torso=(-10, 0, 0), sh_r=(-188, 0, 0), el_r=-15, wr_r=ALONG, sh_l=(-185, 0, 0), el_l=-15,
              hip_l=-50, knee_l=80, hip_r=-20, knee_r=60)),
        (.2, P(torso=(-10, 0, 0), sh_r=(-188, 0, 0), el_r=-15, wr_r=ALONG, sh_l=(-185, 0, 0), el_l=-15,
               hip_l=-50, knee_l=80, hip_r=-20, knee_r=60)),
        (.35, P(torso=(40, 0, 0), sh_r=(-15, 0, 0), el_r=0, wr_r=ALONG, sh_l=(-20, 0, 0), el_l=0, crouch=-.45,
                hip_l=-60, knee_l=90, hip_r=40, knee_r=70)),
        (1, P())],
        hits=[(.35, 'circle', dict(radius=3.8, dmg=55, kb=7, hitstop=.1, shake=.45))],
        fx=[(.35, 'quake', {})], snd=.8, air=True),
    'tornado': dict(dur=1.1, cancel=.92, keys=[
        (0, P(sh_r=(-85, 80, 0), el_r=0, wr_r=ALONG, sh_l=(-85, -80, 0), el_l=0, crouch=-.12, spin=0, torso=(-5, 0, 0))),
        (.05, P(sh_r=(-85, 80, 0), el_r=0, wr_r=ALONG, sh_l=(-85, -80, 0), el_l=0, crouch=-.12, spin=0)),
        (.9, P(sh_r=(-85, 80, 0), el_r=0, wr_r=ALONG, sh_l=(-85, -80, 0), el_l=0, crouch=-.12, spin=-1080)),
        (1, P(spin=-1080))],
        hits=[(t, 'circle', dict(radius=3.6, dmg=15, kb=-2, pull=True)) for t in (.15, .32, .49, .66, .83)] +
             [(.9, 'circle', dict(radius=3.8, dmg=30, kb=8, shake=.3))],
        fx=[(t, 'spin', dict(petals=True)) for t in (.12, .3, .48, .66, .84)], move=[(.05, .9, 2.0)],
        snd=1.2, name='ВИХРЬ САКУРЫ'),
    'moon': dict(dur=1.0, cancel=.9, keys=[
        (0, P(crouch=-.38, torso=(25, 0, 0), sh_r=(-30, 0, -20), wr_r=ALONG, hip_l=-50, knee_l=80, hip_r=40, knee_r=70)),
        (.3, P(crouch=0, torso=(-20, 0, 0), sh_r=(-195, 0, 0), sh_l=(-190, 0, 0), el_r=-20, el_l=-20, wr_r=ALONG,
               hip_l=-60, knee_l=90, hip_r=-30, knee_r=80)),
        (.58, P(crouch=0, torso=(-22, 0, 0), sh_r=(-198, 0, 0), sh_l=(-192, 0, 0), el_r=-25, el_l=-25, wr_r=ALONG,
                hip_l=-60, knee_l=90, hip_r=-30, knee_r=80)),
        (.66, P(crouch=-.42, torso=(40, 0, 0), sh_r=(-25, 0, 0), sh_l=(-30, 0, 0), el_r=0, el_l=0, wr_r=ALONG,
                hip_l=-60, knee_l=70, hip_r=50, knee_r=60)),
        (1, P())],
        hits=[(.66, 'eruption', dict(length=13, width=2.4, dmg=90, kb=6, hitstop=.14, shake=.6))],
        fx=[(.62, 'slash', dict(roll=90, big=True))], leap=(.15, .62, 3.2), snd=.7, name='РАСКОЛ ЛУНЫ'),
    'skill': dict(dur=.45, cancel=.7, keys=[
        (0, P(torso=(-12, 0, 0), sh_r=(-188, 0, 0), sh_l=(-185, 0, 0), el_r=-15, el_l=-15, wr_r=ALONG)),
        (.4, P(torso=(30, 0, 0), sh_r=(-45, 0, 0), sh_l=(-50, 0, 0), el_r=0, el_l=0, wr_r=ALONG, crouch=-.3,
               hip_l=-40, knee_l=50, hip_r=30, knee_r=30)),
        (1, P())],
        hits=[], fx=[(.4, 'wave', {})], snd=None),
}

# --- стойка самурая: лёгкая, полубоком, клинок опущен вниз-вперёд, вес на задней ноге ---
SAM_IDLE = P(pel=(0, 18, 0), torso=(6, -8, -1), head=(0, -10, 2),
             hip_l=-16, knee_l=16, ly_l=-14, lz_l=5, hip_r=10, knee_r=24, ly_r=20, lz_r=-7,
             sh_r=(-18, 8, -14), el_r=-28, wr_r=(70, 0, 0),
             sh_l=(-14, 0, 9), el_l=-38, wr_l=(0, 0, 0), crouch=-.06)

HEAL_COST = 100
REVIVE_COST = 150
HEAL_CD = 8.0

ULT_POSE = P(torso=(-10, 0, 0), head=(-20, 0, 0), sh_r=(-178, 5, 0), sh_l=(-176, -5, 0), el_r=0, el_l=0,
             wr_r=ALONG, crouch=0)
DASH_POSE = P(torso=(35, 0, 0), sh_r=(30, 0, -30), el_r=-20, wr_r=(80, 0, 0), sh_l=(20, 0, 30), el_l=-40,
              crouch=-.22, hip_l=-45, knee_l=65, hip_r=35, knee_r=45)
AIR_POSE = P(hip_l=-45, knee_l=75, hip_r=-10, knee_r=55, crouch=0, torso=(-5, 0, 0))
HURT_POSE = P(torso=(-25, 0, 0), head=(-20, 0, 0), crouch=-.15, sh_r=(-10, 20, -20), el_r=-60)


class Hero(Entity):
    """Общий скелет героя: суставы, позы, приёмы. Внешность и приёмы задают наследники"""
    KIND = 'hero'
    NAME = ''
    MAX_HP = 150
    SPEED = 7.2
    DMG = 1.0
    AIR_JUMPS = 0
    SKILL_CD = 4.0
    ULT_NAME = ''
    ACT = {}
    ULT_POSE = None
    FX1 = C('#ff3b2f', .9)
    FX2 = C('#fff2ec', .95)
    FX_GLOW = C('#ff4a3d')
    AURA = (1.0, .15, .1)
    IDLE = BASE
    PETAL = C('#ff6a8a')
    SOLE = ((0, -.48, -.02), (0, -.48, .19))   # пятка и носок в системе колена
    DASH = None
    AIR = None
    HURT = None
    RUN_RATE = 11.0

    def __init__(self):
        super().__init__()
        self.build()
        bake_rig(self)
        self.shadow = blob_shadow(self, 1.3)
        # размеры ног — чтобы ставить ступни на землю при любой позе
        self.rig_h = self.hips.y
        self.rig_hip = {n: tuple(self.legs[n][0].position) for n in ('l', 'r')}
        self.rig_thigh = {n: -self.legs[n][1].y for n in ('l', 'r')}
        self.gw = 1.0
        self.cur = dict(self.IDLE)
        self.reset()

    # ------------------------------------------------------------
    def reset(self):
        self.position = Vec3(0, 0, 0)
        self.rotation_y = 0
        self.vy = 0
        self.on_ground = True
        self.max_hp = self.MAX_HP
        self.hp = self.MAX_HP
        self.slow_t = 0
        self.heal_cd = 0
        self.vel = Vec3(0, 0, 0)
        self.air_jumps = self.AIR_JUMPS
        self.energy = 0
        self.action = None
        self.act_t = 0
        self.act_from = None
        self.act_done = set()
        self.queued = None
        self.chain = 0
        self.chain_clock = 0
        self.skill_cd = 0
        self.range_cd = 0
        self.heavy_cd = 0
        self.dash_t = 0
        self.dash_cd = 0
        self.dash_end_clock = 9
        self.dash_dir = Vec3(0, 0, 1)
        self.inv = 0
        self.hurt_t = 0
        self.run = 0
        self.move_amt = 0
        self.pose_override = None
        self.combo = 0
        self.combo_clock = 0
        self.leap_base = 0
        self.cur = dict(self.IDLE)
        self.idle_t = 0
        self.gw = 1.0

    # ------------------------------------------------------------ ввод
    def press_light(self):
        if self.dash_t > 0:
            return
        if self.action:
            self.queued = 'L'
            return
        self.decide('L')

    def press_heavy(self):
        if self.dash_t > 0:
            return
        if self.action:
            self.queued = 'R'
            return
        self.decide('R')

    def decide(self, key):
        last = self.chain if self.chain_clock > 0 else 0
        if key == 'L':
            if not self.on_ground:
                self.start('plunge')
            elif self.dash_end_clock < .35:
                self.start('cross')
            else:
                nxt = last + 1 if last < 5 else 1
                self.start(f'L{nxt}')
                self.chain = nxt
        else:
            if last == 2:
                self.start('tornado')
            elif last >= 4:
                self.start('moon')
            elif self.heavy_cd <= 0:
                self.start('heavy')
                self.heavy_cd = 1.0
            self.chain = 0

    def start(self, name, quiet=False):
        a = self.ACT[name]
        self.action = name
        self.act_t = 0
        self.act_from = dict(self.cur)
        self.act_done = set()
        self.queued = None
        self.aim_assist()
        if a.get('name') and not quiet:
            show_move_name(a['name'])
        if a.get('snd'):
            sfx('slash', .55, a['snd'])
        if name == 'plunge':
            self.vy = -4
        if a.get('leap'):
            self.leap_base = self.y

    def aim_assist(self):
        best, bd = None, 8.0
        for d in enemies:
            dd = dist2d(d.position, self.position)
            if dd < bd:
                best, bd = d, dd
        if best:
            self.target_heading = heading_of(flat(best.position) - flat(self.position))
        else:
            mv = move_input()
            self.target_heading = heading_of(mv) if mv.length() > .1 else self.rotation_y

    def skill(self):
        if self.skill_cd > 0 or self.dash_t > 0 or self.action:
            return
        self.skill_cd = self.SKILL_CD
        self.start('skill')

    RANGED_CD = 0

    def ranged(self):
        """Дальний приём (R): только у тех, у кого он есть"""
        if not self.RANGED_CD or self.range_cd > 0 or self.dash_t > 0 or self.action:
            return
        self.range_cd = self.RANGED_CD
        self.start('volley')
        # цель — ближайший демон в пределах дальности, включая летающих
        best, bd = None, 24.0
        for d in enemies:
            dd = dist2d(d.position, self.position)
            if dd < bd:
                best, bd = d, dd
        if best:
            self.target_heading = heading_of(flat(best.position) - flat(self.position))

    def dash(self):
        if self.dash_cd > 0:
            return
        mv = move_input()
        self.dash_dir = mv if mv.length() > .1 else dir_of(self.rotation_y)
        self.dash_t = .22
        self.dash_cd = .65
        self.inv = max(self.inv, .32)
        self.action = None
        self.queued = None
        sfx('dash', .5)

    def jump(self):
        if self.action:
            return
        if self.on_ground:
            self.vy = 9
            self.on_ground = False
            self.air_jumps = self.AIR_JUMPS
            burst(self.position + Vec3(0, .1, 0), 6, C('#5a2a2e'), 2.5, .1, .4)
        elif self.air_jumps > 0:
            self.air_jumps -= 1
            self.vy = 8.5
            shockring(self.position, 1.6, self.FX1, .3)
            burst(self.position + Vec3(0, .3, 0), 10, self.FX2, 3, .1, .4, grav=2, glow=True)
            sfx('dash', .45, 1.3)

    def hurt(self, dmg, src_pos):
        if self.inv > 0 or game.state != 'play' or ult.active or not self.enabled:
            return
        self.hp -= dmg
        self.inv = .75
        self.hurt_t = .25
        push = flat(self.position - Vec3(src_pos))
        if push.length() > .01:
            self.position += push.normalized() * 1.0
        if self.action not in ('tornado', 'moon', 'heavy'):
            self.action = None
        burst(self.position + Vec3(0, 1.2, 0), 18, BLOOD, 6, .12)
        popup_number(self.position + Vec3(0, 2.3, 0), f'-{dmg}', EMBER)
        sfx('hurt', .7)
        game.shake = max(game.shake, .45)
        hurt_overlay.color = C('#c3121e', .35)
        hurt_overlay.animate_color(C('#c3121e', 0), duration=.5)
        self.combo = 0
        if self.hp <= 0:
            self.hp = 0
            if party_rescue():
                return
            game.game_over()

    # ------------------------------------------------------------ удары
    def do_hit(self, kind, prm):
        fwd = dir_of(self.rotation_y)
        dmg_base = prm['dmg']
        hit_any = False
        targets = []
        if kind == 'arc':
            for d in enemies:
                v = flat(d.position) - flat(self.position)
                dist = v.length()
                if dist - d.radius > prm['reach'] or abs(d.y - self.y) > prm.get('height', 2.8):
                    continue
                if dist > .6 and v.normalized().dot(fwd) < prm['cone']:
                    continue
                targets.append((d, fwd))
            reflect_fireballs(self.position, fwd, prm['reach'] + .5, prm['cone'])
        elif kind == 'circle':
            for d in enemies:
                v = flat(d.position) - flat(self.position)
                if v.length() - d.radius <= prm['radius'] and abs(d.y - self.y) < 3.0:
                    push = v.normalized() if v.length() > .01 else fwd
                    targets.append((d, push))
            reflect_fireballs(self.position, fwd, prm['radius'], -1)
        elif kind == 'line':
            a = self.act_line_start
            b = flat(self.position)
            for d in enemies:
                if seg_dist(flat(d.position), a, b) < prm['width'] + d.radius and abs(d.y - self.y) < 3.0:
                    targets.append((d, fwd))
        elif kind == 'eruption':
            start = flat(self.position) + fwd * 1.2
            for i in range(9):
                eruption(start + fwd * (i * prm['length'] / 9), delay=i * .045)
            end = start + fwd * prm['length']
            for d in enemies:
                if seg_dist(flat(d.position), start, end) < prm['width'] + d.radius:
                    targets.append((d, fwd))
        for d, push in targets:
            if gone(d):
                continue
            crit = random.random() < .18
            dmg = int(dmg_base * self.DMG * (2 if crit else 1) * random.uniform(.9, 1.1))
            kb = prm.get('kb', 4)
            if prm.get('pull'):
                to_me = flat(self.position) - flat(d.position)
                push = to_me.normalized() if to_me.length() > .01 else push
                kb = 3
            d.take(dmg, crit, push * kb)
            hit_any = True
        if hit_any:
            game.hitstop = max(game.hitstop, prm.get('hitstop', .05))
            game.shake = max(game.shake, prm.get('shake', .12))
        elif prm.get('shake'):
            game.shake = max(game.shake, prm['shake'] * .6)

    def do_fx(self, kind, prm):
        pos = self.position + Vec3(0, 1.15, 0)
        h = self.rotation_y
        if kind == 'slash':
            roll = prm.get('roll', 0)
            big = prm.get('big', False)
            rot = (0, h + (180 if prm.get('flip') else 0) * 0, roll)
            sc = prm.get('scale', 1.0)
            flash_fx(SLASH, pos, rot, self.FX1, .7 * sc, (1.5 if big else 1.15) * sc, .22)
            flash_fx(SLASH_IN, pos, rot, self.FX2, .7 * sc, (1.42 if big else 1.08) * sc, .16)
            burst(pos + dir_of(h) * 1.2, 4, self.FX_GLOW, 3, .08, .3, grav=0, glow=True)
            if prm.get('feathers'):
                burst(pos + dir_of(h) * 1.4, 5, self.FX2, 4, .09, .6, grav=1, glow=True)
        elif kind == 'spin':
            flash_fx(SPIN_ARC, pos + Vec3(0, -.1, 0), (0, h + random.uniform(0, 360), random.uniform(-8, 8)),
                     self.FX1, .9 * prm.get('scale', 1), 1.25 * prm.get('scale', 1), .25)
            if prm.get('petals'):
                burst(pos, 8, self.PETAL, 6, .09, .7, grav=1, glow=True)
        elif kind == 'crack':
            ground_crack(self.position + dir_of(h) * 2.2, h)
            shockring(self.position + dir_of(h) * 2.2, 4, dur=.4)
            add_flash(self.position + dir_of(h) * 2 + Vec3(0, 1, 0), (1, .3, .15), 7, .3)
        elif kind == 'quake':
            shockring(self.position, 7.5)
            shockring(self.position, 5, C('#fff2ec', .8), .4)
            ground_crack(self.position, h, 3.5)
            add_flash(self.position + Vec3(0, 1, 0), (1, .3, .15), 9, .35)
        elif kind == 'iai':
            a = self.act_line_start
            b = flat(self.position) + dir_of(h) * 2.5
            mid = (a + b) * .5
            ln = (b - a).length()
            for col, w, d in ((C('#ffffff', .95), .05, .22), (C('#ff2a2a', .7), .16, .35)):
                e = Entity(model='cube', position=mid + Vec3(0, 1.15, 0), rotation_y=h, scale=(w, w * .4, ln), color=col)
                e.unlit = True
                e.fade_out(duration=d)
                destroy(e, delay=d + .05)
        elif kind == 'wave':
            waves.append(SpiritWave(self.position + Vec3(0, 1.15, 0) + dir_of(h) * .8, h))
            sfx('wave', .7)
            game.shake = max(game.shake, .2)
        else:
            self.extra_fx(kind, prm, pos, h)

    def extra_fx(self, kind, prm, pos, h):
        pass

    def apply_slow(self, t):
        if self.slow_t <= 0:
            burst(self.position + Vec3(0, 1, 0), 10, C('#c0e8ff'), 3, .08, .5, glow=True)
        self.slow_t = max(self.slow_t, t)

    def heal(self):
        if self.heal_cd > 0 or game.state != 'play':
            return
        cost = game.heal_cost()
        if game.souls < cost:
            popup_number(self.position + Vec3(0, 2.4, 0), f'нужно {cost} душ', C('#c8a0ff'))
            return
        if self.hp >= self.max_hp:
            popup_number(self.position + Vec3(0, 2.4, 0), 'здоровье полное', BONE)
            return
        game.souls -= cost
        game.heals_here += 1
        amount = int(self.max_hp * .4)
        self.hp = min(self.max_hp, self.hp + amount)
        self.heal_cd = HEAL_CD
        popup_number(self.position + Vec3(0, 2.4, 0), f'+{amount}', C('#8affb0'), big=True)
        burst(self.position + Vec3(0, 1, 0), 26, C('#8affb0'), 4, .1, .9, grav=-3, glow=True)
        shockring(self.position, 3, C('#8affb0', .8), .5)
        sfx('orb', .8, .8)

    def register_hit(self):
        self.energy = min(100, self.energy + 1.1)
        self.combo += 1
        self.combo_clock = 2.6

    # ------------------------------------------------------------ кадр
    def tick(self, dt):
        self.skill_cd = max(0, self.skill_cd - dt)
        self.range_cd = max(0, self.range_cd - dt)
        self.heavy_cd = max(0, self.heavy_cd - dt)
        self.heal_cd = max(0, self.heal_cd - dt)
        self.slow_t -= dt
        if self.slow_t > 0 and random.random() < .3:
            burst(self.position + Vec3(random.uniform(-.4, .4), .3, random.uniform(-.4, .4)), 1, C('#c0e8ff'), 1, .07,
                  .4, grav=-1, glow=True)
        self.dash_cd = max(0, self.dash_cd - dt)
        self.inv -= dt
        self.hurt_t -= dt
        self.chain_clock -= dt
        self.dash_end_clock += dt
        self.combo_clock -= dt
        if self.combo_clock <= 0:
            self.combo = 0

        mv = move_input()
        if self.dash_t > 0:
            self.dash_t -= dt
            self.position += self.dash_dir * 28 * dt
            if random.random() < .5:
                ghost(self.position + Vec3(0, 1.1, 0), self.rotation_y, Color(self.FX1[0], self.FX1[1], self.FX1[2], .3))
            if self.dash_t <= 0:
                self.dash_end_clock = 0
        elif not self.action:
            # плавный разгон: скорость догоняет ввод, а не включается рывком
            want = mv * self.SPEED * (.55 if self.slow_t > 0 else 1)
            self.vel = lerp(getattr(self, 'vel', Vec3(0, 0, 0)), want, min(1, dt * 9))
            self.position += self.vel * dt
            if mv.length() > .1:
                self.rotation_y = lerp_angle(self.rotation_y, heading_of(mv), min(1, dt * 9))
        if self.action or self.dash_t > 0:
            self.vel = Vec3(0, 0, 0)
        self.move_amt = lerp(self.move_amt, mv.length() if (not self.action and self.dash_t <= 0) else 0, min(1, dt * 5))
        self.run += self.move_amt * dt * self.RUN_RATE
        self.idle_t += dt

        # физика прыжка
        a = self.ACT.get(self.action) if self.action else None
        if a and a.get('leap'):
            pass
        else:
            g = 60 if self.action == 'plunge' else 26
            self.vy -= g * dt
            self.y += self.vy * dt
            if self.y <= 0:
                self.y = 0
                self.vy = 0
                self.on_ground = True
            else:
                self.on_ground = False

        dungeon.collide(self, .45)

        if self.action:
            self.tick_action(dt)
        self.animate_body(dt)

    def tick_action(self, dt):
        a = self.ACT[self.action]
        dur = a['dur']
        prev = self.act_t / dur
        # удар сверху ждёт приземления
        if self.action == 'plunge' and not self.on_ground and prev >= .2:
            self.act_t = .2 * dur
        else:
            self.act_t += dt
        k = self.act_t / dur
        # доворот к цели
        self.rotation_y = lerp_angle(self.rotation_y, getattr(self, 'target_heading', self.rotation_y),
                                     min(1, dt * 22) if k < .45 else 0)
        for t0, t1, d in a.get('move', []):
            if t0 <= k and prev < t1:
                seg = (min(k, t1) - max(prev, t0)) / (t1 - t0)
                if 'line' in [h[1] for h in a['hits']] and prev <= t0:
                    self.act_line_start = flat(self.position)
                self.position += dir_of(self.rotation_y) * d * seg
        if self.action == 'heavy' and not hasattr(self, 'act_line_start'):
            self.act_line_start = flat(self.position)
        if a.get('leap'):
            t0, t1, hgt = a['leap']
            if t0 <= k <= t1:
                u = (k - t0) / (t1 - t0)
                self.y = self.leap_base + math.sin(u * math.pi * .5) * hgt if u < .8 else hgt * (1 - (u - .8) / .2)
            elif k > t1:
                self.y = 0
        for i, (t, kind, prm) in enumerate(a['hits']):
            if k >= t and ('h', i) not in self.act_done:
                self.act_done.add(('h', i))
                self.do_hit(kind, prm)
        for i, (t, kind, prm) in enumerate(a['fx']):
            if k >= t and ('f', i) not in self.act_done:
                self.act_done.add(('f', i))
                self.do_fx(kind, prm)
        if a.get('inv'):
            if a['inv'][0] <= k <= a['inv'][1]:
                self.inv = max(self.inv, .05)
        if self.queued and k >= a['cancel']:
            q = self.queued
            self.finish_action()
            self.decide(q)
            return
        if k >= 1:
            self.finish_action()

    def finish_action(self):
        name = self.action
        self.action = None
        self.chain_clock = .5 if name and name.startswith('L') else 0
        if hasattr(self, 'act_line_start'):
            del self.act_line_start
        s = self.cur['spin'] % 360
        self.cur['spin'] = s - 360 if s > 180 else s

    def animate_body(self, dt):
        try:
            self.face_tick(dt)
        except Exception:
            pass
        LT.aura = 1.0 if (self.energy >= 100 or self.pose_override == 'ult') else 0.0
        LT.aura_col = self.AURA
        self.aura.enabled = LT.aura > 0
        if self.pose_override == 'ult':
            target, rate = self.ULT_POSE, 5
        elif self.action:
            a = self.ACT[self.action]
            k = self.act_t / a['dur']
            target = sample(a['keys'], k)
            if k < .12 and self.act_from:
                target = blend(self.act_from, target, k / .12)
            self.apply(target)
            self.cur = target
            self.shadow.y = .03 - self.y
            return
        elif self.dash_t > 0:
            target, rate = self.DASH, 20
        elif self.hurt_t > 0:
            target, rate = self.HURT, 18
        elif not self.on_ground:
            target, rate = self.AIR, 10
        else:
            m = smooth(self.move_amt)
            idle = self.idle_pose(self.idle_t)
            if m > .01:
                target = blend(idle, self.run_pose(self.run), m)
            else:
                target = idle
            rate = 10
        self.cur = blend(self.cur, target, min(1, dt * rate))
        self.apply(self.cur)
        self.shadow.y = .03 - self.y

    # ------------------------------------------------------------ мимика
    SPEAKER = ''

    def face_tick(self, dt):
        """Живое лицо: моргание, брови, рот — по тому, что делает герой"""
        f = getattr(self, 'face', None)
        if not f or dt <= 0:
            return
        st = f.setdefault('st', dict(lid=f.get('lid_base', .1), brow_y=0.0, brow_r=0.0, mouth=0.0, blink=2.5,
                                     talk=0.0))
        st['blink'] -= dt
        if st['blink'] < -.14:
            st['blink'] = random.uniform(2.2, 5.0)
        blink = 1.0 if -.14 < st['blink'] < 0 else 0.0
        mood = 'neutral'
        k_hit = 0.0
        if self.pose_override == 'ult':
            mood = 'shout'
        elif self.hurt_t > 0:
            mood = 'hurt'
        elif self.action:
            mood = 'fight'
            a = self.ACT.get(self.action, {})
            kk = self.act_t / max(.01, a.get('dur', 1))
            for t, _, _ in a.get('hits', []):
                k_hit = max(k_hit, 1 - abs(kk - t) * 7)
            for t, _, _ in a.get('fx', []):
                k_hit = max(k_hit, .8 - abs(kk - t) * 7)
        elif self.dash_t > 0:
            mood = 'fight'
        elif game.state == 'select' and self in previews and previews.index(self) == game.hero_i:
            mood = 'smile'
        talking = (story.cur is not None and story.cur[0] == self.SPEAKER and story.cur[2] > .35
                   and self.enabled)
        base = f.get('lid_base', .1)
        lid = {'neutral': base, 'smile': base + .12, 'fight': base + .14, 'shout': .05, 'hurt': .55}[mood]
        by, br = {'neutral': (0, 0), 'smile': (.002, 4), 'fight': (-.003, -13), 'shout': (-.002, -16),
                  'hurt': (.002, 12)}[mood]
        mouth = {'neutral': 0, 'smile': 0, 'fight': .12 + .8 * max(0.0, k_hit), 'shout': .95, 'hurt': .55}[mood]
        if talking:
            st['talk'] += dt * 15
            mouth = max(mouth, abs(math.sin(st['talk'])) * .55 + .08 * math.sin(st['talk'] * 2.3))
        if blink:
            lid = 1.0
        r = min(1.0, dt * 22)
        st['lid'] += (lid - st['lid']) * (1.0 if blink else r)
        st['brow_y'] += (by - st['brow_y']) * r
        st['brow_r'] += (br - st['brow_r']) * r
        st['mouth'] += (mouth - st['mouth']) * r
        for e in f['lids']:
            e.scale_y = max(.02, st['lid'])
        for e, side in f['brows']:
            e.y = e.base_y + st['brow_y']
            e.rotation_z = st['brow_r'] * side
        m = max(0.0, st['mouth'])
        f['mouth_open'].scale_y = max(.02, m)
        f['mouth_open'].enabled = m > .04
        f['lower_lip'].y = f['lower_lip'].base_y - m * f['open_h']
        smile = mood == 'smile' and m < .1
        f['mouth_smile'].enabled = smile
        f['mouth_line'].enabled = not smile

    # ------------------------------------------------------------ стойка и бег
    def idle_pose(self, t):
        """Боевая стойка с дыханием: грудь поднимается, клинок чуть гуляет"""
        p = dict(self.IDLE)
        b = math.sin(t * 1.9)
        b2 = math.sin(t * .7 + 1)
        tx, ty, tz = p['torso']
        p['torso'] = (tx + b * 1.6, ty + b2 * 2, tz)
        hx, hy, hz = p['head']
        p['head'] = (hx - b * 1.2, hy - b2 * 3, hz)
        for a in ('sh_r', 'sh_l'):
            x, y, z = p[a]
            p[a] = (x - b * 2.5, y, z + b * (1.5 if a == 'sh_l' else -1.5))
        return p

    def run_legs(self, ph, p, stride=36, sway=4, lean=14, twist=9):
        """Ноги, таз и корпус для бега; фаза ph: левая нога впереди при sin>0"""
        for n, off in (('l', 0), ('r', math.pi)):
            f = ph + off
            sn, cs = math.sin(f), math.cos(f)
            p['hip_' + n] = -stride * sn - 8
            p['knee_' + n] = 10 + 92 * max(0.0, math.cos(f + .45)) ** 1.5 + 16 * max(0.0, -cs)
        sn, cs = math.sin(ph), math.cos(ph)
        p['ly_l'], p['ly_r'], p['lz_l'], p['lz_r'] = -4, 4, 2, -2
        p['pel'] = (0, twist * sn, -sway * cs)
        p['torso'] = (lean, -(twist + 5) * sn, sway * .5 * cs)
        p['head'] = (-lean * .6, 4 * sn, 0)
        p['spin'] = 0
        p['bx'] = p['bz'] = 0
        return p

    def run_pose(self, ph):
        p = dict(self.IDLE)
        self.run_legs(ph, p)
        sn = math.sin(ph)
        p['sh_l'] = (-15 + 42 * sn, 0, -8)
        p['el_l'] = -70 - 15 * max(0, -sn)
        p['sh_r'] = (-15 - 42 * sn, 0, 8)
        p['el_r'] = -70 - 15 * max(0, sn)
        return p

    def ground_y(self, p):
        """Высота тела, при которой нижняя точка ступней стоит на полу"""
        low = 9.0
        pel = p['pel']
        for n in ('l', 'r'):
            hx, hy, hz = self.rig_hip[n]
            L = self.rig_thigh[n]
            hr = (p['hip_' + n], p['ly_' + n], p['lz_' + n])
            kr = (p['knee_' + n], 0, 0)
            for q in self.SOLE:
                v = rot3(q, kr)
                v = rot3((v[0], v[1] - L, v[2]), hr)
                v = rot3((v[0] + hx, v[1] + hy, v[2] + hz), pel)
                y = v[1] + self.rig_h
                if y < low:
                    low = y
        return -low


    def apply_extra(self, p):
        pass

    def apply(self, p):
        self.apply_extra(p)
        # плащ: корень гасит наклон корпуса и свисает, на бегу развевается
        lift = self.move_amt * 30 + (30 if self.dash_t > 0 else 0)
        for i, s in enumerate(self.scarf):
            if i == 0:
                s.rotation_x = -p['torso'][0] - 28 + lift * .6
            else:
                s.rotation_x = -6 + math.sin(game.clock * 7 + i * .8) * (3 + i * 1.5) + lift * .08
        # ступни на полу: на земле высоту тела считаем по ногам, в воздухе — по позе
        want_g = 1.0 if (self.y < .05 and self.on_ground and getattr(self, 'action', None) not in ('plunge',)) else 0.0
        self.gw += (want_g - self.gw) * min(1.0, time.dt * 14) if time.dt < .2 else (want_g - self.gw)
        gy = self.ground_y(p) if self.gw > .001 else 0
        self.body.y = p['crouch'] * (1 - self.gw) + gy * self.gw
        self.body.x = p['bx']
        self.body.z = p['bz']
        self.body.rotation_y = p['spin']
        self.hips.rotation = p['pel']
        self.torso.rotation = p['torso']
        self.head.rotation = p['head']
        sh, el, wr = self.arms['r']
        sh.rotation = p['sh_r']
        el.rotation_x = p['el_r']
        wr.rotation = p['wr_r']
        sh, el, wr = self.arms['l']
        sh.rotation = p['sh_l']
        el.rotation_x = p['el_l']
        wr.rotation = p['wr_l']
        self.legs['l'][0].rotation = (p['hip_l'], p['ly_l'], p['lz_l'])
        self.legs['l'][1].rotation_x = p['knee_l']
        self.legs['r'][0].rotation = (p['hip_r'], p['ly_r'], p['lz_r'])
        self.legs['r'][1].rotation_x = p['knee_r']


# =====================================================================
# САМУРАЙ: лёгкий, текучий стиль клинка — широкие дуги, развороты корпуса, шаг в каждый удар
# =====================================================================
def S(**kw):
    return PI(SAM_IDLE, **kw)


LG_SET = dict(hip_l=-16, knee_l=16, ly_l=-14, lz_l=5, hip_r=10, knee_r=24, ly_r=20, lz_r=-7)
LG_LUNGE = dict(hip_l=-42, knee_l=46, ly_l=-6, lz_l=4, hip_r=26, knee_r=12, ly_r=24, lz_r=-6)
LG_WIDE = dict(hip_l=-20, knee_l=42, ly_l=-14, lz_l=14, hip_r=16, knee_r=40, ly_r=24, lz_r=-14)
LG_LOW = dict(hip_l=-52, knee_l=84, ly_l=-8, lz_l=8, hip_r=30, knee_r=72, ly_r=20, lz_r=-8)
LG_AIR = dict(hip_l=-62, knee_l=98, ly_l=0, lz_l=6, hip_r=-24, knee_r=86, ly_r=0, lz_r=-6)
LG_KNEEL = dict(hip_l=-70, knee_l=108, ly_l=-4, lz_l=10, hip_r=36, knee_r=96, ly_r=10, lz_r=-10)

SAM_KEYS = {
    # диагональ сверху-справа вниз-влево с выпадом
    'L1': [(0, S(pel=(0, 30, 0), torso=(4, 24, -6), head=(0, -40, 0), sh_r=(-150, 35, -25), el_r=-50, wr_r=ALONG,
                 sh_l=(-40, 10, 15), el_l=-60, **LG_SET)),
           (.4, S(pel=(0, -5, 0), torso=(14, -30, 6), head=(0, 28, 0), sh_r=(-72, -45, 10), el_r=-10, wr_r=ALONG,
                  sh_l=(-10, 0, 22), el_l=-30, **LG_LUNGE)),
           (.66, S(pel=(0, -10, 0), torso=(12, -40, 6), head=(0, 36, 0), sh_r=(-42, -70, 15), el_r=-15,
                   wr_r=(72, 0, 0), sh_l=(5, 0, 26), el_l=-25, **LG_LUNGE)),
           (1, S())],
    # обратный восходящий удар с полуразворотом
    'L2': [(0, S(pel=(0, -15, 0), torso=(10, -35, 4), head=(0, 40, 0), sh_r=(-35, -65, 15), el_r=-20, wr_r=ALONG,
                 sh_l=(-20, 0, 20), el_l=-40, **LG_LUNGE)),
           (.4, S(pel=(0, 15, 0), torso=(-4, 30, -8), head=(-8, -35, 0), sh_r=(-140, 55, -10), el_r=-5, wr_r=ALONG,
                  sh_l=(-55, -15, 30), el_l=-50, spin=-25, **LG_SET)),
           (.66, S(pel=(0, 20, 0), torso=(-2, 38, -8), head=(-5, -45, 0), sh_r=(-160, 70, -15), el_r=-15, wr_r=ALONG,
                   sh_l=(-30, 0, 25), el_l=-40, spin=-25, **LG_SET)),
           (1, S())],
    # восходящий полумесяц снизу вверх
    'L3': [(0, S(pel=(0, 10, 0), torso=(22, -10, 0), head=(-15, 0, 0), sh_r=(-10, -30, 10), el_r=-30, wr_r=ALONG,
                 sh_l=(-30, 0, 20), el_l=-50, **LG_LOW)),
           (.42, S(pel=(0, 5, 0), torso=(-14, 10, 0), head=(-14, -10, 0), sh_r=(-175, 15, 0), el_r=-5, wr_r=ALONG,
                   sh_l=(-40, -10, 35), el_l=-30, hip_l=-28, knee_l=18, ly_l=-8, lz_l=3, hip_r=18, knee_r=10,
                   ly_r=20, lz_r=-4)),
           (.7, S(pel=(0, 5, 0), torso=(-16, 15, 0), head=(-12, -12, 0), sh_r=(-188, 20, 0), el_r=-12, wr_r=ALONG,
                  sh_l=(-35, -10, 35), el_l=-35, hip_l=-28, knee_l=18, ly_l=-8, lz_l=3, hip_r=18, knee_r=10,
                  ly_r=20, lz_r=-4)),
           (1, S())],
    # двойной пируэт с вытянутым клинком
    'L4': [(0, S(pel=(0, 20, 0), torso=(8, 20, -6), sh_r=(-85, 70, 0), el_r=-5, wr_r=ALONG, sh_l=(-60, -60, 30),
                 el_l=-20, spin=0, **LG_WIDE)),
           (.12, S(pel=(0, 20, 0), torso=(8, 20, -8), sh_r=(-85, 75, 0), el_r=-5, wr_r=ALONG, sh_l=(-60, -60, 30),
                   el_l=-20, spin=-30, **LG_WIDE)),
           (.75, S(pel=(0, 15, 0), torso=(10, 15, -8), sh_r=(-85, 78, 0), el_r=0, wr_r=ALONG, sh_l=(-60, -60, 30),
                   el_l=-20, spin=-360, **LG_WIDE)),
           (1, S(spin=-360))],
    # финал: клинок двумя руками над головой и рубящий удар в землю
    'L5': [(0, S(pel=(0, 0, 0), torso=(-12, 0, 0), head=(-12, 0, 0), sh_r=(-185, -5, 0), el_r=-25, wr_r=ALONG,
                 sh_l=(-180, 8, 0), el_l=-25, **LG_SET)),
           (.36, S(pel=(0, 0, 0), torso=(-18, 0, 0), head=(-10, 0, 0), sh_r=(-200, -5, 0), el_r=-30, wr_r=ALONG,
                   sh_l=(-195, 8, 0), el_l=-30, hip_l=-20, knee_l=8, ly_l=-8, lz_l=3, hip_r=10, knee_r=6, ly_r=15,
                   lz_r=-4)),
           (.55, S(pel=(0, 0, 0), torso=(30, 0, 0), head=(-22, 0, 0), sh_r=(-84, -8, 0), el_r=0, wr_r=(70, 0, 0),
                   sh_l=(-86, 10, 0), el_l=0, hip_l=-55, knee_l=72, ly_l=-5, lz_l=6, hip_r=40, knee_r=46, ly_r=20,
                   lz_r=-8)),
           (.78, S(pel=(0, 0, 0), torso=(28, 0, 0), head=(-20, 0, 0), sh_r=(-80, -8, 0), el_r=0, wr_r=(70, 0, 0),
                   sh_l=(-82, 10, 0), el_l=0, hip_l=-55, knee_l=72, ly_l=-5, lz_l=6, hip_r=40, knee_r=46, ly_r=20,
                   lz_r=-8)),
           (1, S())],
    # иай: рука на рукояти у левого бедра, рывок и клинок уходит вправо
    'heavy': [(0, S(pel=(0, -30, 0), torso=(14, -25, 0), head=(0, 45, 0), sh_r=(-25, -75, 20), el_r=-70,
                    wr_r=(30, 0, 0), sh_l=(-15, -30, 15), el_l=-70, **LG_LOW)),
              (.25, S(pel=(0, -32, 0), torso=(16, -27, 0), head=(0, 47, 0), sh_r=(-26, -77, 20), el_r=-72,
                      wr_r=(30, 0, 0), sh_l=(-15, -32, 15), el_l=-72, **LG_LOW)),
              (.46, S(pel=(0, 10, 0), torso=(20, 35, 0), head=(-5, -35, 0), sh_r=(-95, 85, -10), el_r=0, wr_r=ALONG,
                      sh_l=(-10, -20, 30), el_l=-20, hip_l=-58, knee_l=55, ly_l=-6, lz_l=4, hip_r=42, knee_r=20,
                      ly_r=20, lz_r=-6)),
              (.72, S(pel=(0, 12, 0), torso=(16, 38, 0), head=(-5, -38, 0), sh_r=(-90, 88, -10), el_r=-5,
                      wr_r=ALONG, sh_l=(-10, -20, 30), el_l=-20, hip_l=-58, knee_l=55, ly_l=-6, lz_l=4, hip_r=42,
                      knee_r=20, ly_r=20, lz_r=-6)),
              (1, S())],
    # крест после рывка
    'cross': [(0, S(pel=(0, 15, 0), torso=(0, 25, 0), sh_r=(-160, 40, -20), el_r=-30, wr_r=ALONG,
                    sh_l=(-40, 0, 20), el_l=-50, **LG_SET)),
              (.3, S(pel=(0, -5, 0), torso=(16, -30, 0), sh_r=(-40, -55, 10), el_r=-5, wr_r=ALONG,
                     sh_l=(-10, 0, 25), el_l=-30, **LG_LUNGE)),
              (.55, S(pel=(0, -10, 0), torso=(0, -25, 0), sh_r=(-160, -50, 15), el_r=-30, wr_r=ALONG,
                      sh_l=(-40, 0, 20), el_l=-40, **LG_LUNGE)),
              (.85, S(pel=(0, 10, 0), torso=(16, 35, 0), sh_r=(-45, 60, -10), el_r=-5, wr_r=ALONG,
                      sh_l=(-10, 0, 25), el_l=-30, **LG_LUNGE)),
              (1, S())],
    # удар сверху: клинок вниз, приземление на колено
    'plunge': [(0, S(torso=(-10, 0, 0), sh_r=(-190, 0, 0), el_r=-20, wr_r=ALONG, sh_l=(-185, 0, 0), el_l=-20,
                     **LG_AIR)),
               (.2, S(torso=(-10, 0, 0), sh_r=(-190, 0, 0), el_r=-20, wr_r=ALONG, sh_l=(-185, 0, 0), el_l=-20,
                      **LG_AIR)),
               (.35, S(torso=(40, 0, 0), head=(-30, 0, 0), sh_r=(-22, -5, 0), el_r=0, wr_r=ALONG,
                       sh_l=(-25, 8, 0), el_l=0, **LG_KNEEL)),
               (.72, S(torso=(36, 0, 0), head=(-28, 0, 0), sh_r=(-22, -5, 0), el_r=0, wr_r=ALONG,
                       sh_l=(-25, 8, 0), el_l=0, **LG_KNEEL)),
               (1, S())],
    # вихрь: вращение с клинком наотлёт и креном
    'tornado': [(0, S(pel=(0, 0, 0), torso=(5, 0, -10), sh_r=(-85, 80, 0), el_r=0, wr_r=ALONG, sh_l=(-85, -80, 0),
                      el_l=0, spin=0, **LG_WIDE)),
                (.05, S(pel=(0, 0, 0), torso=(5, 0, -10), sh_r=(-85, 80, 0), el_r=0, wr_r=ALONG,
                        sh_l=(-85, -80, 0), el_l=0, spin=-30, **LG_WIDE)),
                (.9, S(pel=(0, 0, 0), torso=(8, 0, -12), sh_r=(-85, 80, 0), el_r=0, wr_r=ALONG,
                       sh_l=(-85, -80, 0), el_l=0, spin=-1080, **LG_WIDE)),
                (1, S(spin=-1080))],
    # раскол луны: прыжок с сальто и удар в землю
    'moon': [(0, S(torso=(25, 0, 0), sh_r=(-30, 0, -20), el_r=-20, wr_r=ALONG, sh_l=(-30, 0, 20), el_l=-30,
                   **LG_LOW)),
             (.3, S(torso=(-20, 0, 0), head=(-15, 0, 0), sh_r=(-195, 0, 0), sh_l=(-190, 0, 0), el_r=-20, el_l=-20,
                    wr_r=ALONG, spin=-180, **LG_AIR)),
             (.58, S(torso=(-22, 0, 0), head=(-15, 0, 0), sh_r=(-198, 0, 0), sh_l=(-192, 0, 0), el_r=-25,
                     el_l=-25, wr_r=ALONG, spin=-360, **LG_AIR)),
             (.66, S(torso=(40, 0, 0), head=(-25, 0, 0), sh_r=(-25, 0, 0), sh_l=(-30, 0, 0), el_r=0, el_l=0,
                     wr_r=ALONG, spin=-360, **LG_KNEEL)),
             (.85, S(torso=(36, 0, 0), head=(-22, 0, 0), sh_r=(-25, 0, 0), sh_l=(-30, 0, 0), el_r=0, el_l=0,
                     wr_r=ALONG, spin=-360, **LG_KNEEL)),
             (1, S(spin=-360))],
    # волна духа: взмах из-за плеча
    'skill': [(0, S(pel=(0, 25, 0), torso=(-6, 30, 0), head=(0, -40, 0), sh_r=(-130, 70, -20), el_r=-30,
                    wr_r=ALONG, sh_l=(-80, -20, 20), el_l=-30, **LG_SET)),
              (.4, S(pel=(0, -10, 0), torso=(18, -25, 0), head=(0, 25, 0), sh_r=(-82, -40, 10), el_r=0, wr_r=ALONG,
                     sh_l=(-20, 0, 25), el_l=-30, **LG_LUNGE)),
              (.7, S(pel=(0, -12, 0), torso=(16, -30, 0), head=(0, 28, 0), sh_r=(-70, -50, 10), el_r=-5, wr_r=ALONG,
                     sh_l=(-15, 0, 25), el_l=-30, **LG_LUNGE)),
              (1, S())],
}
for _n, _k in SAM_KEYS.items():
    ACTIONS[_n]['keys'] = _k
ACTIONS['L1']['fx'] = [(.25, 'slash', dict(roll=28))]
ACTIONS['L2']['fx'] = [(.25, 'slash', dict(roll=-30, flip=True))]
ULT_POSE = S(pel=(0, 0, 0), torso=(-10, 0, 0), head=(-20, 0, 0), sh_r=(-178, 5, 0), sh_l=(-176, -5, 0), el_r=0,
             el_l=0, wr_r=ALONG, **LG_WIDE)
SAM_DASH = S(pel=(0, 0, 0), torso=(35, 0, 0), head=(-20, 0, 0), sh_r=(60, -5, -15), el_r=-10, wr_r=(82, 0, 0),
             sh_l=(30, 0, -20), el_l=-40, hip_l=-55, knee_l=70, ly_l=0, lz_l=4, hip_r=40, knee_r=55, ly_r=0, lz_r=-4)
SAM_AIR = S(pel=(0, 0, 0), torso=(-5, 0, 0), sh_r=(30, 0, -25), el_r=-20, wr_r=(82, 0, 0), sh_l=(-40, 0, 30),
            el_l=-50, hip_l=-50, knee_l=80, ly_l=0, lz_l=4, hip_r=-8, knee_r=55, ly_r=0, lz_r=-4)
SAM_HURT = S(torso=(-22, 10, 0), head=(-20, 0, 0), sh_r=(-10, 20, -25), el_r=-60, sh_l=(-30, 0, 30), el_l=-60,
             **LG_WIDE)


class Samurai(Hero):
    KIND = 'samurai'
    NAME = 'АСАХИ'
    TITLE = 'Единственный выживший из экспедиции'
    ROLE = 'катана  ·  ближний бой'
    MAX_HP = 170
    SPEED = 7.0
    DMG = 1.0
    ULT_NAME = 'БАГРОВОЕ ПОЛНОЛУНИЕ'
    ACT = ACTIONS
    ULT_POSE = ULT_POSE
    IDLE = SAM_IDLE
    SPEAKER = 'samurai'
    DASH = SAM_DASH
    AIR = SAM_AIR
    HURT = SAM_HURT
    PETAL = C('#ff6a8a')
    ICONS = ('icon_sword', 'icon_heavy', 'icon_wave', 'icon_moon')
    DESC = 'Странствующий воин. Хочет дойти до самого дна и уничтожить источник проклятия. Узнаёт древние знаки на стенах, хотя не помнит, чтобы бывал здесь. Медленнее, но выносливее, рубит тяжело и широко'
    STATS = (('Здоровье', .85), ('Урон', .9), ('Скорость', .55), ('Дальность', .65))
    MOVES = (('ЛКМ', 'цепочка из 5 ударов катаной'), ('ПКМ', 'иай: выпад сквозь врагов'),
             ('E', 'волна духа, пробивает насквозь'), ('Q', 'Багровое Полнолуние'),
             ('ЛКМ ЛКМ ПКМ', 'Вихрь сакуры'), ('ЛКМ×4 ПКМ', 'Раскол луны'))

    def build(self):
        if build_anime(self, 'build_samurai'):
            fix_proportions(self, head_drop=.05, sh_in=.04, sh_down=.025, collar=(.17, .13, .16), collar_y=.57,
                            collar_col=C('#2a2130'))
            wr = self.arms['r'][2]
            self.aura = glow_entity(Entity(parent=wr, model='cube', z=.77, scale=(.09, .16, 1.32),
                                           color=C('#ff2a2a', .35)))
            self.aura.enabled = False
            return
        self.build_classic()

    def run_pose(self, ph):
        """Бег с клинком, отведённым назад: рука вытянута, лезвие летит следом"""
        p = dict(self.IDLE)
        self.run_legs(ph, p, stride=38, sway=3, lean=18, twist=8)
        sn = math.sin(ph)
        p['sh_r'] = (58 + 4 * sn, -6, -12)
        p['el_r'] = -10
        p['wr_r'] = (82, 0, 0)
        p['sh_l'] = (-10 + 46 * sn, 0, -6)
        p['el_l'] = -75 - 20 * max(0, -sn)
        p['wr_l'] = (0, 0, 0)
        return p

    def apply_extra(self, p):
        lift = self.move_amt * 30 + (30 if self.dash_t > 0 else 0)
        for i, s in enumerate(getattr(self, 'hair', [])):
            if i == 0:
                s.rotation_x = -150 - p['torso'][0] - p['head'][0] + lift * .3
            else:
                s.rotation_x = math.sin(game.clock * 5 + i * .7) * (2 + i) - lift * .04

    def build_classic(self):
        lac = dict(texture='lacquer', color=C('#ffffff'))
        lac_dark = dict(texture='lacquer', color=C('#7a6a6a'))
        met = dict(texture='metal', color=C('#ffffff'))
        clo = dict(texture='cloth', color=C('#ffffff'))
        skin = C('#5a3a32')

        self.body = Entity(parent=self)
        b = self.body
        self.hips = Entity(parent=b, y=.98)
        # кусадзури: пластинчатая юбка доспеха
        for x, z, ry in ((0, .17, 0), (0, -.17, 180), (.22, 0, 90), (-.22, 0, -90), (.16, .12, 40), (-.16, .12, -40)):
            part(self.hips, model='rbox', position=(x, -.17, z), rotation=(12, ry, 0), scale=(.2, .3, .03), **lac)
        part(self.hips, model='rbox', y=0, scale=(.44, .1, .34), color=BLOOD)  # оби
        part(self.hips, model='rbox', y=0, z=.17, scale=(.1, .14, .03), color=GOLD)
        # ножны с левого бока
        part(self.hips, model='rbox', position=(-.26, -.05, .05), rotation=(-20, 8, 0), scale=(.05, .06, 1.05),
             texture='lacquer', color=C('#3a0b10'))
        # ноги
        self.legs = {}
        for side, name in ((-1, 'l'), (1, 'r')):
            hip = Entity(parent=self.hips, x=.13 * side, y=-.04)
            part(hip, model='taper', y=-.22, scale=(.19, .46, .21), **clo)
            part(hip, model='taper', y=-.2, z=.11, scale=(.18, .34, .03), **lac_dark)  # хайдатэ
            knee = Entity(parent=hip, y=-.46)
            part(knee, model='taper', y=-.21, scale=(.15, .44, .16), **clo)
            part(knee, model='taper', y=-.2, z=.09, scale=(.15, .4, .03), **met)  # сунэатэ
            part(knee, model='taper', y=-.45, z=.06, scale=(.16, .07, .3), color=C('#2a1a12'))
            self.legs[name] = (hip, knee)
        # корпус
        self.torso = Entity(parent=self.hips, y=.05)
        t = self.torso
        part(t, model='torso', y=.3, scale=(.48, .56, .3), **lac)
        part(t, model='rbox', y=.33, z=.15, scale=(.5, .48, .04), **lac)  # до
        part(t, model='rbox', y=.55, z=.165, scale=(.5, .05, .02), color=GOLD)
        for x in (-.1, .1):
            part(t, model='rbox', position=(x, .3, .17), scale=(.025, .5, .02), color=BLOOD)  # шнуровка
        part(t, model='rbox', y=.62, scale=(.14, .1, .14), color=skin)
        # содэ — наплечники
        for side in (-1, 1):
            part(t, model='rbox', position=(.34 * side, .5, 0), rotation=(0, 0, 18 * side), scale=(.26, .32, .38), **lac)
            part(t, model='rbox', position=(.36 * side, .35, 0), rotation=(0, 0, 18 * side), scale=(.27, .03, .39),
                 color=GOLD)
        # голова, мэмпо и кабуто
        self.head = Entity(parent=t, y=.68)
        h = self.head
        part(h, model='skull', y=.1, scale=.26, color=skin)
        part(h, model='rbox', position=(0, .04, .09), scale=(.24, .15, .12), **met)  # маска
        part(h, model='rbox', position=(0, .0, .155), scale=(.1, .025, .01), color=BLOOD)
        part(h, model='rbox', position=(0, .08, .16), rotation=(-20, 0, 0), scale=(.05, .07, .05), **met)  # нос
        self.eyes = [part(h, unlit=True, model='rbox', position=(x, .15, .13), scale=(.07, .018, .02), color=EMBER)
                     for x in (-.055, .055)]
        part(h, model='orb', y=.2, scale=(.34, .25, .36), **met)  # шлем
        part(h, model='rbox', y=.15, scale=(.36, .04, .38), color=GOLD)
        part(h, model='rbox', position=(0, .09, -.15), rotation=(-35, 0, 0), scale=(.44, .2, .05), **lac)  # сикоро
        for side in (-1, 1):
            part(h, model='rbox', position=(.2 * side, .1, -.06), rotation=(-20, 30 * side, 10 * side),
                 scale=(.05, .18, .26), **lac)
            part(h, model='rbox', position=(.22 * side, .2, .07), rotation=(0, 25 * side, 0), scale=(.05, .13, .14),
                 color=BLOOD)  # фукигаэси
            # маэдатэ: рогатый гербовый гребень
            seg = Entity(parent=h, position=(.05 * side, .3, .16), rotation=(0, 0, -25 * side))
            for i in range(4):
                part(seg, model='rbox', y=.06, scale=(.035 - i * .005, .12, .02), color=GOLD)
                seg = Entity(parent=seg, y=.12, rotation=(0, 0, -16 * side))
        part(h, model='diamond', position=(0, .33, .19), scale=(.08, .1, .02), color=GOLD)
        # плащ-шарф
        self.scarf = []
        par = Entity(parent=t, position=(0, .58, -.17))
        for i in range(6):
            s = part(par, model='rbox', z=-.13, scale=(.32 - i * .03, .02, .26), texture='cloth', color=C('#ff4040'))
            self.scarf.append(par)
            par = Entity(parent=par, z=-.26)
        # руки
        self.arms = {}
        for side, name in ((-1, 'l'), (1, 'r')):
            sh = Entity(parent=t, position=(.27 * side, .48, 0))
            part(sh, model='taper', y=-.15, scale=(.13, .3, .13), **clo)
            el = Entity(parent=sh, y=-.3)
            part(el, model='taper', y=-.14, scale=(.11, .28, .11), **met)  # котэ
            part(el, model='taper', y=-.3, scale=(.1, .09, .1), color=INK)
            wr = Entity(parent=el, y=-.3)
            self.arms[name] = (sh, el, wr)
        # катана
        wr = self.arms['r'][2]
        part(wr, model='rbox', z=0, scale=(.04, .04, .28), texture='cloth', color=C('#ff5050'))
        part(wr, model='rbox', z=.15, scale=(.14, .14, .025), color=GOLD)
        self.blade = part(wr, model='rbox', z=.77, scale=(.022, .07, 1.2), color=C('#e8e2e0'))
        part(wr, unlit=True, model='rbox', position=(0, -.032, .77), scale=(.024, .01, 1.18), color=C('#ffffff'))
        self.aura = glow_entity(Entity(parent=wr, model='rbox', z=.77, scale=(.09, .16, 1.32), color=C('#ff2a2a', .35)))
        self.aura.enabled = False
        # доработка по референсу: стёганая кираса, верёвки, второй меч, сандалии
        t = self.torso
        part(t, model='torso', y=.3, z=-.01, scale=(.5, .5, .32), texture='quilt', color=WHITE)
        for y in (.18, .44):
            part(t, model='rbox', y=y, z=.175, scale=(.52, .025, .02), texture='cloth', color=C('#d8c0a0'))
        part(t, model='rbox', position=(.12, .48, .17), rotation_z=40, scale=(.32, .025, .02), texture='cloth',
             color=C('#d8c0a0'))
        part(self.hips, model='rbox', position=(.24, -.04, .1), rotation=(-25, -10, 0), scale=(.04, .05, .62),
             texture='lacquer', color=C('#2a080c'))  # вакидзаси
        part(self.hips, model='rbox', position=(.24, .02, .38), rotation=(-25, -10, 0), scale=(.05, .05, .16),
             texture='cloth', color=C('#ff5050'))
        part(self.hips, model='rbox', position=(.25, -.12, -.06), scale=(.09, .12, .08), texture='cloth',
             color=C('#4a3020'))  # подсумок
        for nm in ('l', 'r'):
            knee = self.legs[nm][1]
            for y in (-.12, -.3):
                part(knee, model='rbox', position=(0, y, .1), scale=(.17, .02, .02), texture='cloth', color=C('#d8c0a0'))
        for nm in ('l', 'r'):
            el = self.arms[nm][1]
            part(el, model='taper', y=-.14, scale=(.12, .26, .12), texture='quilt', color=WHITE)
            part(el, model='taper', y=-.14, z=.06, scale=(.11, .24, .02), texture='metal', color=WHITE)


# =====================================================================
# ХАНА — Танцующая с ветром: боевые веера и сила ветра
# =====================================================================
WIND = C('#5fe8c8', .85)
WIND2 = C('#f4fffb', .95)
WIND_GLOW = C('#9fffe6')


def fan_mesh(r=.46, a0=-78, a1=78, segs=14):
    """Раскрытый веер: сектор от рукояти вдоль -Y, в плоскости XY"""
    verts, uvs, tris = [Vec3(0, 0, 0)], [Vec2(.5, 0)], []
    for i in range(segs + 1):
        a = math.radians(a0 + (a1 - a0) * i / segs)
        verts.append(Vec3(math.sin(a) * r, -math.cos(a) * r, 0))
        uvs.append(Vec2(.5 + math.sin(a) * .5, math.cos(a) * .98))
    for i in range(segs):
        tris.append((0, i + 1, i + 2))
    return Mesh(vertices=verts, triangles=tris, uvs=uvs, normals=[Vec3(0, 0, 1)] * len(verts), mode='triangle')


# старая стойка — от неё отсчитаны приёмы
KAZE_BASE = PI(BASE, torso=(2, -12, 0), head=(0, 12, 0),
               sh_r=(-40, 40, 0), el_r=-55, wr_r=(-20, 0, 0),
               sh_l=(-25, -30, 0), el_l=-35, wr_l=(-10, 0, 0),
               hip_l=-8, knee_l=12, hip_r=16, knee_r=22, crouch=-.04)
# стойка танцовщицы с веерами: левый веер поднят у лица, правый отведён вниз-назад, бедро в сторону
KAZE_IDLE = PI(BASE, pel=(0, -22, 5), torso=(3, 16, -4), head=(0, 8, 5),
               hip_l=-22, knee_l=26, ly_l=-4, lz_l=2, hip_r=10, knee_r=14, ly_r=28, lz_r=-8,
               sh_l=(-62, -28, 22), el_l=-104, wr_l=(-10, 0, -20),
               sh_r=(-25, -10, -38), el_r=-22, wr_r=(0, 0, 0), crouch=-.04)


def K(**kw):
    return PI(KAZE_BASE, **kw)


KAZE_ACTIONS = {
    'L1': dict(dur=.28, cancel=.5, keys=[
        (0, K(torso=(5, 50, 0), sh_r=(-85, 85, 0), el_r=-15, wr_r=(0, 0, 90), sh_l=(-50, -10, 0))),
        (.5, K(torso=(5, -25, 0), sh_r=(-88, -35, 0), el_r=-5, wr_r=(0, 0, 90), sh_l=(-60, -50, 0))),
        (1, K())],
        hits=[(.4, 'arc', dict(reach=2.9, cone=.15, dmg=17, kb=4))],
        fx=[(.3, 'slash', dict(roll=6, scale=.9, feathers=True))], move=[(.1, .45, .5)], snd=1.35),
    'L2': dict(dur=.28, cancel=.5, keys=[
        (0, K(torso=(5, -50, 0), sh_l=(-85, -85, 0), el_l=-15, wr_l=(0, 0, -90), sh_r=(-50, 10, 0))),
        (.5, K(torso=(5, 25, 0), sh_l=(-88, 35, 0), el_l=-5, wr_l=(0, 0, -90), sh_r=(-60, 50, 0))),
        (1, K())],
        hits=[(.4, 'arc', dict(reach=2.9, cone=.15, dmg=17, kb=4))],
        fx=[(.3, 'slash', dict(roll=-6, scale=.9, feathers=True))], move=[(.1, .45, .5)], snd=1.3),
    'L3': dict(dur=.34, cancel=.55, keys=[
        (0, K(crouch=-.22, torso=(20, 0, 0), sh_r=(-20, 20, 0), sh_l=(-20, -20, 0), el_r=-20, el_l=-20,
              hip_l=-35, knee_l=55)),
        (.5, K(crouch=.05, torso=(-10, 0, 0), sh_r=(-165, 25, 0), sh_l=(-165, -25, 0), el_r=0, el_l=0,
               wr_r=(0, 0, 0), wr_l=(0, 0, 0))),
        (1, K())],
        hits=[(.42, 'arc', dict(reach=2.8, cone=.2, dmg=14, kb=3, height=4.4))],
        fx=[(.35, 'slash', dict(roll=78, scale=.9, feathers=True)), (.45, 'windblade', {})], move=[(.1, .4, .3)],
        snd=1.25),
    'L4': dict(dur=.48, cancel=.62, keys=[
        (0, K(sh_r=(-85, 85, 0), el_r=0, sh_l=(-85, -85, 0), el_l=0, wr_r=(0, 0, 90), wr_l=(0, 0, -90),
              crouch=-.1, spin=0)),
        (.8, K(sh_r=(-85, 85, 0), el_r=0, sh_l=(-85, -85, 0), el_l=0, wr_r=(0, 0, 90), wr_l=(0, 0, -90),
               crouch=-.06, spin=-540)),
        (1, K(spin=-540))],
        hits=[(.3, 'circle', dict(radius=3.3, dmg=15, kb=3)), (.62, 'circle', dict(radius=3.3, dmg=15, kb=5))],
        fx=[(.25, 'spin', dict(petals=True)), (.55, 'spin', dict(petals=True))], move=[(.1, .7, .5)], snd=1.2),
    'L5': dict(dur=.5, cancel=.75, keys=[
        (0, K(torso=(-10, 0, 0), sh_r=(-20, 60, 0), sh_l=(-20, -60, 0), el_r=-60, el_l=-60, crouch=-.1)),
        (.35, K(torso=(-12, 0, 0), sh_r=(-15, 70, 0), sh_l=(-15, -70, 0), el_r=-70, el_l=-70, crouch=-.12)),
        (.5, K(torso=(25, 0, 0), sh_r=(-92, 10, 0), sh_l=(-92, -10, 0), el_r=0, el_l=0, wr_r=(-90, 0, 0),
               wr_l=(-90, 0, 0), crouch=-.25, hip_l=-40, knee_l=40, hip_r=30, knee_r=30)),
        (1, K())],
        hits=[(.5, 'arc', dict(reach=5.4, cone=.3, dmg=36, kb=11, hitstop=.08, shake=.3))],
        fx=[(.5, 'gust', {})], move=[(.38, .5, .5)], snd=.9),
    'heavy': dict(dur=.55, cancel=.8, keys=[
        (0, K(torso=(15, 0, 0), sh_r=(-70, -30, 0), sh_l=(-70, 30, 0), el_r=-30, el_l=-30, crouch=-.3,
              hip_l=-40, knee_l=60, hip_r=30, knee_r=50, wr_r=(0, 0, 90), wr_l=(0, 0, -90))),
        (.35, K(torso=(18, 0, 0), sh_r=(-72, -35, 0), sh_l=(-72, 35, 0), el_r=-35, el_l=-35, crouch=-.32,
                hip_l=-42, knee_l=62, hip_r=32, knee_r=52, wr_r=(0, 0, 90), wr_l=(0, 0, -90))),
        (.55, K(torso=(-5, 0, 0), sh_r=(-85, 95, 0), sh_l=(-85, -95, 0), el_r=0, el_l=0, crouch=-.08,
                wr_r=(0, 0, 90), wr_l=(0, 0, -90))),
        (1, K())],
        hits=[(.52, 'arc', dict(reach=6.2, cone=.05, dmg=48, kb=14, hitstop=.1, shake=.35))],
        fx=[(.5, 'gust', dict(big=True))], snd=.8, name='БУРНЫЙ ПОРЫВ'),
    'cross': dict(dur=.42, cancel=.7, keys=[
        (0, K(sh_r=(-60, 120, 0), sh_l=(-60, -120, 0), el_r=-60, el_l=-60, torso=(-5, 0, 0))),
        (.4, K(sh_r=(-95, -20, 0), sh_l=(-95, 20, 0), el_r=0, el_l=0, torso=(15, 0, 0), crouch=-.15)),
        (1, K())],
        hits=[], fx=[(.38, 'fanthrow', {})], move=[(0, .3, 1.0)], snd=1.4, name='ВЕЕРА-БУМЕРАНГИ'),
    'plunge': dict(dur=.5, cancel=.85, keys=[
        (0, K(sh_r=(-170, 40, 0), sh_l=(-170, -40, 0), el_r=0, el_l=0, hip_l=-50, knee_l=80, hip_r=-20,
              knee_r=60, spin=0)),
        (.2, K(sh_r=(-170, 40, 0), sh_l=(-170, -40, 0), el_r=0, el_l=0, hip_l=-50, knee_l=80, hip_r=-20,
               knee_r=60, spin=0)),
        (.35, K(torso=(30, 0, 0), sh_r=(-60, 80, 0), sh_l=(-60, -80, 0), crouch=-.4, hip_l=-60, knee_l=90,
                hip_r=40, knee_r=70, spin=-180)),
        (1, K(spin=-180))],
        hits=[(.35, 'circle', dict(radius=4.3, dmg=44, kb=9, hitstop=.08, shake=.4))],
        fx=[(.35, 'windquake', {})], snd=.9, air=True),
    'tornado': dict(dur=1.1, cancel=.92, keys=[
        (0, K(sh_r=(-150, 60, 0), sh_l=(-90, -85, 0), el_r=0, el_l=0, wr_r=(0, 0, 90), wr_l=(0, 0, -90),
              crouch=-.05, spin=0)),
        (.9, K(sh_r=(-150, 60, 0), sh_l=(-90, -85, 0), el_r=0, el_l=0, wr_r=(0, 0, 90), wr_l=(0, 0, -90),
               crouch=-.05, spin=-1440)),
        (1, K(spin=-1440))],
        hits=[(t, 'circle', dict(radius=3.9, dmg=13, kb=-2, pull=True)) for t in (.15, .3, .45, .6, .75)] +
             [(.9, 'circle', dict(radius=4.2, dmg=30, kb=10, shake=.3))],
        fx=[(t, 'spin', dict(petals=True, scale=1.15)) for t in (.12, .3, .48, .66, .84)], move=[(.05, .9, 2.6)],
        snd=1.3, name='ТАНЕЦ УРАГАНА'),
    'moon': dict(dur=1.0, cancel=.9, keys=[
        (0, K(crouch=-.35, torso=(25, 0, 0), hip_l=-50, knee_l=80, hip_r=40, knee_r=70)),
        (.3, K(crouch=0, sh_r=(-160, 70, 0), sh_l=(-160, -70, 0), el_r=0, el_l=0, spin=-360,
               hip_l=-60, knee_l=90, hip_r=-30, knee_r=80)),
        (.6, K(crouch=0, sh_r=(-165, 75, 0), sh_l=(-165, -75, 0), el_r=0, el_l=0, spin=-720,
               hip_l=-60, knee_l=90, hip_r=-30, knee_r=80)),
        (.68, K(crouch=-.4, torso=(35, 0, 0), sh_r=(-50, 90, 0), sh_l=(-50, -90, 0), spin=-720,
                hip_l=-60, knee_l=70, hip_r=50, knee_r=60)),
        (1, K(spin=-720))],
        hits=[(.68, 'circle', dict(radius=5.2, dmg=70, kb=4, hitstop=.12, shake=.55))],
        fx=[(.68, 'bigcyclone', {})], leap=(.15, .64, 3.8), snd=.75, name='НЕБЕСНЫЙ СМЕРЧ'),
    'skill': dict(dur=.42, cancel=.7, keys=[
        (0, K(torso=(-5, 30, 0), sh_r=(-60, 110, 0), el_r=-40, wr_r=(0, 0, 90))),
        (.45, K(torso=(10, -20, 0), sh_r=(-90, -20, 0), el_r=0, wr_r=(0, 0, 90), crouch=-.12)),
        (1, K())],
        hits=[], fx=[(.42, 'cyclone', {})], snd=None),
}

KAZE_ULT = K(torso=(-12, 0, 0), head=(-20, 0, 0), sh_r=(-150, 65, 0), sh_l=(-150, -65, 0), el_r=0, el_l=0,
             wr_r=(0, 0, 0), wr_l=(0, 0, 0), crouch=0)


# =====================================================================
# ХАНА: стиль танцовщицы с веерами — режущие веера, пируэты, подъём веерами, толчок ветра
# =====================================================================
def KZ(**kw):
    return PI(KAZE_IDLE, **kw)


KG_SET = dict(hip_l=-22, knee_l=26, ly_l=-4, lz_l=2, hip_r=10, knee_r=14, ly_r=28, lz_r=-8)
KG_LUNGE = dict(hip_l=-44, knee_l=40, ly_l=-4, lz_l=3, hip_r=26, knee_r=8, ly_r=28, lz_r=-6)
KG_WIDE = dict(hip_l=-14, knee_l=30, ly_l=-18, lz_l=16, hip_r=12, knee_r=28, ly_r=26, lz_r=-16)
KG_LOW = dict(hip_l=-50, knee_l=86, ly_l=-6, lz_l=8, hip_r=28, knee_r=76, ly_r=22, lz_r=-8)
KG_AIR = dict(hip_l=-58, knee_l=100, ly_l=0, lz_l=6, hip_r=-20, knee_r=92, ly_r=0, lz_r=-6)
KG_PASSE = dict(hip_l=-4, knee_l=4, ly_l=-6, lz_l=2, hip_r=-48, knee_r=105, ly_r=30, lz_r=-18)   # стопа у колена
KG_KNEEL = dict(hip_l=-68, knee_l=110, ly_l=-4, lz_l=10, hip_r=34, knee_r=100, ly_r=12, lz_r=-10)
FAN_FLAT = (0, 0, 0)
FAN_UP_R, FAN_UP_L = (0, 0, 90), (0, 0, -90)

KAZE_KEYS = {
    # правый веер: размашистый горизонтальный разрез
    'L1': [(0, KZ(pel=(0, 25, 0), torso=(4, 30, -4), head=(0, -38, 0), sh_r=(-85, 88, 0), el_r=-25, wr_r=FAN_FLAT,
                  sh_l=(-50, 30, 10), el_l=-95, **KG_SET)),
           (.45, KZ(pel=(0, -10, 0), torso=(8, -35, 4), head=(0, 30, 0), sh_r=(-88, -45, 0), el_r=-5, wr_r=FAN_FLAT,
                    sh_l=(-40, 15, 20), el_l=-70, **KG_LUNGE)),
           (.72, KZ(pel=(0, -15, 0), torso=(8, -45, 4), head=(0, 38, 0), sh_r=(-84, -72, 0), el_r=-12,
                    wr_r=FAN_FLAT, sh_l=(-35, 15, 22), el_l=-70, **KG_LUNGE)),
           (1, KZ())],
    # левый веер навстречу, с полуоборотом
    'L2': [(0, KZ(pel=(0, -25, 0), torso=(4, -32, 4), head=(0, 34, 0), sh_l=(-85, -88, 0), el_l=-25, wr_l=FAN_FLAT,
                  sh_r=(-40, -20, -25), el_r=-40, **KG_LUNGE)),
           (.45, KZ(pel=(0, 15, 0), torso=(6, 35, -4), head=(0, -32, 0), sh_l=(-88, 45, 0), el_l=-5, wr_l=FAN_FLAT,
                    sh_r=(-30, 20, -40), el_r=-20, spin=-30, **KG_SET)),
           (.72, KZ(pel=(0, 18, 0), torso=(6, 42, -4), head=(0, -38, 0), sh_l=(-84, 70, 0), el_l=-12,
                    wr_l=FAN_FLAT, sh_r=(-30, 25, -45), el_r=-20, spin=-45, **KG_SET)),
           (1, KZ())],
    # подъём веерами: оба веера взмывают снизу вверх, тело тянется следом
    'L3': [(0, KZ(pel=(0, 0, 0), torso=(22, 0, 0), head=(-15, 0, 0), sh_r=(-15, 20, -25), sh_l=(-15, -20, 25),
                  el_r=-20, el_l=-20, wr_r=FAN_UP_R, wr_l=FAN_UP_L, **KG_LOW)),
           (.42, KZ(pel=(0, 0, 0), torso=(-14, 0, 0), head=(-20, 0, 0), sh_r=(-170, 25, -10), sh_l=(-170, -25, 10),
                    el_r=0, el_l=0, wr_r=FAN_UP_R, wr_l=FAN_UP_L, hip_l=-14, knee_l=6, ly_l=-6, lz_l=3, hip_r=8,
                    knee_r=4, ly_r=18, lz_r=-4)),
           (.7, KZ(pel=(0, 0, 0), torso=(-16, 0, 0), head=(-18, 0, 0), sh_r=(-176, 30, -12), sh_l=(-176, -30, 12),
                   el_r=-8, el_l=-8, wr_r=FAN_UP_R, wr_l=FAN_UP_L, hip_l=-14, knee_l=6, ly_l=-6, lz_l=3, hip_r=8,
                   knee_r=4, ly_r=18, lz_r=-4)),
           (1, KZ())],
    # вращение с раскрытыми веерами
    'L4': [(0, KZ(pel=(0, 0, 0), torso=(4, 0, -8), head=(0, 0, 0), sh_r=(-85, 85, 0), sh_l=(-85, -85, 0), el_r=0,
                  el_l=0, wr_r=FAN_FLAT, wr_l=FAN_FLAT, spin=0, **KG_WIDE)),
           (.8, KZ(pel=(0, 0, 0), torso=(4, 0, 8), head=(0, 0, 0), sh_r=(-85, 85, 0), sh_l=(-85, -85, 0), el_r=0,
                   el_l=0, wr_r=FAN_FLAT, wr_l=FAN_FLAT, spin=-540, **KG_WIDE)),
           (1, KZ(spin=-540))],
    # двойной толчок веерами — порыв ветра
    'L5': [(0, KZ(pel=(0, 20, 0), torso=(-10, 25, 0), head=(0, -25, 0), sh_r=(-30, 60, -30), sh_l=(-30, -60, 30),
                  el_r=-70, el_l=-70, wr_r=FAN_FLAT, wr_l=FAN_FLAT, **KG_SET)),
           (.35, KZ(pel=(0, 24, 0), torso=(-12, 30, 0), head=(0, -30, 0), sh_r=(-25, 66, -30), sh_l=(-25, -66, 30),
                    el_r=-82, el_l=-82, wr_r=FAN_FLAT, wr_l=FAN_FLAT, **KG_SET)),
           (.5, KZ(pel=(0, -5, 0), torso=(22, 0, 0), head=(-12, 0, 0), sh_r=(-92, 8, 0), sh_l=(-92, -8, 0), el_r=0,
                   el_l=0, wr_r=(-90, 0, 0), wr_l=(-90, 0, 0), **KG_LUNGE)),
           (.76, KZ(pel=(0, -5, 0), torso=(20, 0, 0), head=(-10, 0, 0), sh_r=(-90, 10, 0), sh_l=(-90, -10, 0),
                    el_r=-5, el_l=-5, wr_r=(-90, 0, 0), wr_l=(-90, 0, 0), **KG_LUNGE)),
           (1, KZ())],
    # бурный порыв: веера скрещены, затем распахиваются в стороны
    'heavy': [(0, KZ(pel=(0, 0, 0), torso=(15, 0, 0), head=(-8, 0, 0), sh_r=(-70, -30, 0), sh_l=(-70, 30, 0),
                     el_r=-30, el_l=-30, wr_r=FAN_UP_R, wr_l=FAN_UP_L, **KG_LOW)),
              (.35, KZ(pel=(0, 0, 0), torso=(18, 0, 0), head=(-10, 0, 0), sh_r=(-72, -36, 0), sh_l=(-72, 36, 0),
                       el_r=-36, el_l=-36, wr_r=FAN_UP_R, wr_l=FAN_UP_L, **KG_LOW)),
              (.55, KZ(pel=(0, 0, 0), torso=(-5, 0, 0), head=(-10, 0, 0), sh_r=(-85, 95, 0), sh_l=(-85, -95, 0),
                       el_r=0, el_l=0, wr_r=FAN_UP_R, wr_l=FAN_UP_L, **KG_WIDE)),
              (.8, KZ(pel=(0, 0, 0), torso=(-6, 0, 0), head=(-10, 0, 0), sh_r=(-80, 100, 0), sh_l=(-80, -100, 0),
                      el_r=-5, el_l=-5, wr_r=FAN_UP_R, wr_l=FAN_UP_L, **KG_WIDE)),
              (1, KZ())],
    # бросок вееров из-за головы
    'cross': [(0, KZ(pel=(0, 0, 0), torso=(-10, 0, 0), head=(-5, 0, 0), sh_r=(-150, 60, 0), sh_l=(-150, -60, 0),
                     el_r=-70, el_l=-70, wr_r=FAN_FLAT, wr_l=FAN_FLAT, **KG_SET)),
              (.4, KZ(pel=(0, 0, 0), torso=(18, 0, 0), head=(-12, 0, 0), sh_r=(-95, -20, 0), sh_l=(-95, 20, 0),
                      el_r=0, el_l=0, wr_r=FAN_FLAT, wr_l=FAN_FLAT, **KG_LUNGE)),
              (.7, KZ(pel=(0, 0, 0), torso=(16, 0, 0), head=(-10, 0, 0), sh_r=(-90, -25, 0), sh_l=(-90, 25, 0),
                      el_r=-5, el_l=-5, wr_r=FAN_FLAT, wr_l=FAN_FLAT, **KG_LUNGE)),
              (1, KZ())],
    'plunge': [(0, KZ(pel=(0, 0, 0), torso=(-5, 0, 0), sh_r=(-170, 40, 0), sh_l=(-170, -40, 0), el_r=0, el_l=0,
                      wr_r=FAN_UP_R, wr_l=FAN_UP_L, spin=0, **KG_AIR)),
               (.2, KZ(pel=(0, 0, 0), torso=(-5, 0, 0), sh_r=(-170, 40, 0), sh_l=(-170, -40, 0), el_r=0, el_l=0,
                       wr_r=FAN_UP_R, wr_l=FAN_UP_L, spin=0, **KG_AIR)),
               (.35, KZ(pel=(0, 0, 0), torso=(30, 0, 0), head=(-20, 0, 0), sh_r=(-60, 80, 0), sh_l=(-60, -80, 0),
                        el_r=0, el_l=0, wr_r=FAN_FLAT, wr_l=FAN_FLAT, spin=-180, **KG_KNEEL)),
               (.72, KZ(pel=(0, 0, 0), torso=(28, 0, 0), head=(-18, 0, 0), sh_r=(-55, 85, 0), sh_l=(-55, -85, 0),
                        el_r=0, el_l=0, wr_r=FAN_FLAT, wr_l=FAN_FLAT, spin=-180, **KG_KNEEL)),
               (1, KZ(spin=-180))],
    # танец урагана: пируэт на одной ноге, один веер над головой, второй наотлёт
    'tornado': [(0, KZ(pel=(0, 0, 0), torso=(-4, 0, 0), head=(-8, 0, 0), sh_r=(-160, 60, 0), sh_l=(-90, -85, 0),
                       el_r=-10, el_l=0, wr_r=FAN_UP_R, wr_l=FAN_FLAT, spin=0, **KG_PASSE)),
                (.9, KZ(pel=(0, 0, 0), torso=(-4, 0, 0), head=(-8, 0, 0), sh_r=(-160, 60, 0), sh_l=(-90, -85, 0),
                        el_r=-10, el_l=0, wr_r=FAN_UP_R, wr_l=FAN_FLAT, spin=-1440, **KG_PASSE)),
                (1, KZ(spin=-1440))],
    'moon': [(0, KZ(pel=(0, 0, 0), torso=(25, 0, 0), sh_r=(-30, 40, -30), sh_l=(-30, -40, 30), el_r=-30, el_l=-30,
                    **KG_LOW)),
             (.3, KZ(pel=(0, 0, 0), torso=(-10, 0, 0), sh_r=(-160, 70, 0), sh_l=(-160, -70, 0), el_r=0, el_l=0,
                     wr_r=FAN_UP_R, wr_l=FAN_UP_L, spin=-360, **KG_AIR)),
             (.6, KZ(pel=(0, 0, 0), torso=(-10, 0, 0), sh_r=(-165, 75, 0), sh_l=(-165, -75, 0), el_r=0, el_l=0,
                     wr_r=FAN_UP_R, wr_l=FAN_UP_L, spin=-720, **KG_AIR)),
             (.68, KZ(pel=(0, 0, 0), torso=(32, 0, 0), head=(-20, 0, 0), sh_r=(-50, 90, 0), sh_l=(-50, -90, 0),
                      el_r=0, el_l=0, wr_r=FAN_FLAT, wr_l=FAN_FLAT, spin=-720, **KG_KNEEL)),
             (.86, KZ(pel=(0, 0, 0), torso=(28, 0, 0), head=(-18, 0, 0), sh_r=(-48, 92, 0), sh_l=(-48, -92, 0),
                      el_r=0, el_l=0, wr_r=FAN_FLAT, wr_l=FAN_FLAT, spin=-720, **KG_KNEEL)),
             (1, KZ(spin=-720))],
    # вихрь: правый веер заводится за плечо и хлёстко выбрасывается вперёд
    'skill': [(0, KZ(pel=(0, 20, 0), torso=(-5, 35, 0), head=(0, -40, 0), sh_r=(-60, 110, 0), el_r=-40,
                     wr_r=FAN_UP_R, **KG_SET)),
              (.45, KZ(pel=(0, -10, 0), torso=(12, -25, 0), head=(0, 25, 0), sh_r=(-90, -25, 0), el_r=0,
                       wr_r=FAN_UP_R, **KG_LUNGE)),
              (.75, KZ(pel=(0, -12, 0), torso=(10, -30, 0), head=(0, 28, 0), sh_r=(-86, -32, 0), el_r=-6,
                       wr_r=FAN_UP_R, **KG_LUNGE)),
              (1, KZ())],
}
for _n, _k in KAZE_KEYS.items():
    KAZE_ACTIONS[_n]['keys'] = _k
# веерный шквал: правый веер заводится за плечо и хлёстко выбрасывает веер перьев-лезвий
KAZE_ACTIONS['volley'] = dict(dur=.42, cancel=.62, keys=[
    (0, KZ(pel=(0, 25, 0), torso=(-8, 35, 0), head=(0, -40, 0), sh_r=(-150, 70, 0), el_r=-60, wr_r=FAN_FLAT,
           sh_l=(-80, -40, 20), el_l=-30, wr_l=FAN_FLAT, **KG_SET)),
    (.4, KZ(pel=(0, -12, 0), torso=(16, -30, 0), head=(0, 28, 0), sh_r=(-92, -15, 0), el_r=0, wr_r=FAN_FLAT,
            sh_l=(-40, 20, 30), el_l=-60, wr_l=FAN_FLAT, **KG_LUNGE)),
    (.72, KZ(pel=(0, -14, 0), torso=(14, -34, 0), head=(0, 30, 0), sh_r=(-88, -22, 0), el_r=-5, wr_r=FAN_FLAT,
             sh_l=(-35, 20, 30), el_l=-60, wr_l=FAN_FLAT, **KG_LUNGE)),
    (1, KZ())],
    hits=[], fx=[(.4, 'volley', {})], snd=1.5, name='ВЕЕРНЫЙ ШКВАЛ')
KAZE_ULT = KZ(pel=(0, 0, 0), torso=(-12, 0, 0), head=(-20, 0, 0), sh_r=(-150, 65, 0), sh_l=(-150, -65, 0), el_r=0,
              el_l=0, wr_r=FAN_UP_R, wr_l=FAN_UP_L, **KG_PASSE)
KAZE_DASH = KZ(pel=(0, 0, 0), torso=(30, 0, 0), head=(-18, 0, 0), sh_r=(55, -10, -30), sh_l=(55, 10, 30), el_r=-10,
               el_l=-10, wr_r=FAN_FLAT, wr_l=FAN_FLAT, hip_l=-52, knee_l=66, ly_l=0, lz_l=4, hip_r=38, knee_r=50,
               ly_r=0, lz_r=-4)
KAZE_AIR = KZ(pel=(0, 0, 0), torso=(-6, 0, 0), sh_r=(-40, 40, -40), sh_l=(-40, -40, 40), el_r=-30, el_l=-30,
              wr_r=FAN_FLAT, wr_l=FAN_FLAT, hip_l=-55, knee_l=95, ly_l=0, lz_l=4, hip_r=10, knee_r=40, ly_r=0, lz_r=-4)
KAZE_HURT = KZ(pel=(0, 0, 0), torso=(-22, -10, 0), head=(-18, 0, 0), sh_r=(-20, 30, -30), sh_l=(-20, -30, 30),
               el_r=-70, el_l=-70, **KG_WIDE)


class Kaze(Hero):
    KIND = 'kaze'
    NAME = 'ХАРУКАЗЭ'
    TITLE = 'Ищет пропавшего брата'
    ROLE = 'веера  ·  дальний бой'
    MAX_HP = 150
    SPEED = 8.5
    DMG = 1.05
    AIR_JUMPS = 1
    SKILL_CD = 5.0
    RANGED_CD = 3.0
    ULT_NAME = 'БУРЯ ТЫСЯЧИ ПЕРЬЕВ'
    ACT = KAZE_ACTIONS
    ULT_POSE = KAZE_ULT
    IDLE = KAZE_IDLE
    SPEAKER = 'hana'
    SOLE = ((0, -.46, -.015), (0, -.46, .165))
    DASH = KAZE_DASH
    AIR = KAZE_AIR
    HURT = KAZE_HURT
    FX1 = WIND
    FX2 = WIND2
    FX_GLOW = WIND_GLOW
    AURA = (.2, 1.0, .8)
    PETAL = C('#ffffff')
    ICONS = ('icon_fan', 'icon_wave', 'icon_swirl', 'icon_feather')
    DESC = 'Спустилась в Бездну за младшим братом Рэном, ушедшим с последней экспедицией. Демоны порой замирают, почуяв её, а во снах её зовут по имени. Быстрая и хрупкая, двойной прыжок, веерами поднимает смерчи'
    STATS = (('Здоровье', .7), ('Урон', .82), ('Скорость', .95), ('Дальность', 1.0))
    MOVES = (('ЛКМ', 'танец вееров из 5 ударов'), ('ПКМ', 'бурный порыв, отбрасывает'),
             ('E', 'вихрь: затягивает и режет'), ('Q', 'Буря тысячи перьев'),
             ('R', 'веерный шквал: перья летят далеко, бьют и летающих'), ('ЛКМ ЛКМ ПКМ', 'Танец урагана'))

    def build(self):
        if build_anime(self, 'build_kaze'):
            fix_proportions(self, head_drop=.065, sh_in=.03, sh_down=.02, collar=(.12, .1, .12), collar_y=.5,
                            collar_col=C('#f2ece8'))
            self.aura = Entity(parent=self)
            self.aura_parts = [glow_entity(Entity(parent=fan, model='quad', texture='glow', y=-.25, scale=.9,
                                                  color=Color(.4, 1, .85, .45), double_sided=True))
                               for fan in self.fans]
            return
        self.build_classic()

    def build_classic(self):
        skin = C('#c98f74')
        hair = C('#140a0e')
        silk = dict(texture='silk', color=WHITE)
        red = dict(texture='cloth', color=C('#ff4048'))
        dark = dict(texture='cloth', color=C('#7a6a70'))
        lac = dict(texture='lacquer', color=C('#ffffff'))
        self.body = Entity(parent=self)
        b = self.body
        self.hips = Entity(parent=b, y=.95)
        # хакама-юбка из шести складок
        for i in range(8):
            a = i / 8 * 360
            r = math.radians(a)
            part(self.hips, model='rbox', position=(math.sin(r) * .15, -.17, math.cos(r) * .12),
                 rotation=(14, a, 0), scale=(.15, .34, .03), **red)
        part(self.hips, model='rbox', y=.02, scale=(.34, .1, .24), color=BLOOD)  # оби
        part(self.hips, model='rbox', position=(0, .02, .125), scale=(.12, .12, .02), color=GOLD)
        part(self.hips, model='rbox', position=(-.17, -.02, .05), rotation_z=20, scale=(.03, .2, .03), color=GOLD)
        # ноги в тёмных леггинсах и наголенниках
        self.legs = {}
        for side, name in ((-1, 'l'), (1, 'r')):
            hip = Entity(parent=self.hips, x=.09 * side, y=-.04)
            part(hip, model='taper', y=-.22, scale=(.13, .45, .14), **dark)
            knee = Entity(parent=hip, y=-.45)
            part(knee, model='taper', y=-.2, scale=(.1, .42, .11), **dark)
            part(knee, model='taper', y=-.17, z=.06, scale=(.11, .3, .02), **lac)
            part(knee, model='rbox', position=(0, -.44, .05), scale=(.1, .05, .22), color=INK)
            part(knee, model='rbox', position=(0, -.36, 0), scale=(.115, .03, .12), color=GOLD)
            self.legs[name] = (hip, knee)
        # корпус: белый шёлк, перекрёстный ворот, наплечник
        self.torso = Entity(parent=self.hips, y=.06)
        t = self.torso
        part(t, model='rbox', y=.14, scale=(.28, .22, .19), **silk)
        part(t, model='torso', y=.36, scale=(.33, .26, .21), **silk)
        part(t, model='rbox', position=(.04, .32, .107), rotation_z=35, scale=(.05, .32, .015), color=BLOOD)
        part(t, model='rbox', position=(-.04, .32, .108), rotation_z=-35, scale=(.05, .32, .015), color=BLOOD)
        part(t, model='rbox', y=.08, scale=(.3, .07, .21), color=BLOOD)
        part(t, model='rbox', position=(-.2, .5, 0), rotation_z=-20, scale=(.14, .08, .22), **lac)  # наплечник
        part(t, model='rbox', y=.52, scale=(.09, .08, .09), color=skin)
        # голова, чёлка, высокий хвост, кандзаси
        self.head = Entity(parent=t, y=.62)
        h = self.head
        part(h, model='skull', y=.08, scale=(.2, .24, .21), color=skin)
        self.eyes = [part(h, unlit=True, model='rbox', position=(x, .1, .095), scale=(.045, .014, .02), color=WIND_GLOW)
                     for x in (-.045, .045)]
        for x in (-.07, .07):
            part(h, model='rbox', position=(x, .065, .1), rotation_z=-x * 200, scale=(.03, .006, .01), color=BLOOD)
        part(h, model='orb', position=(0, .14, -.015), scale=(.23, .2, .23), color=hair)
        part(h, model='rbox', position=(0, .19, .08), rotation_x=20, scale=(.2, .06, .07), color=hair)  # чёлка
        for x in (-.1, .1):
            part(h, model='rbox', position=(x, .06, .05), scale=(.03, .18, .05), color=hair)
        part(h, model='rbox', position=(0, .23, -.07), scale=(.08, .06, .08), color=BLOOD)
        part(h, model='rbox', position=(.05, .26, -.06), rotation_z=-30, scale=(.015, .14, .015), color=GOLD)
        glow_entity(Entity(parent=h, model='orb', position=(.085, .325, -.06), scale=.03, color=WIND_GLOW))
        self.hair = []
        par = Entity(parent=h, position=(0, .24, -.1), rotation_x=-150)
        for i in range(6):
            part(par, model='rbox', y=.05, scale=(.085 - i * .008, .11, .05), color=hair)
            self.hair.append(par)
            par = Entity(parent=par, y=.1)
        # ленты оби — то, что развевается
        self.scarf = []
        par = Entity(parent=t, position=(0, .08, -.12))
        for i in range(4):
            part(par, model='rbox', z=-.08, x=-.05, scale=(.06, .015, .16), **red)
            part(par, model='rbox', z=-.08, x=.05, scale=(.06, .015, .16), **red)
            self.scarf.append(par)
            par = Entity(parent=par, z=-.16)
        # руки: широкие рукава, лакированные наручи, веера
        self.arms = {}
        self.fans = []
        for side, name in ((-1, 'l'), (1, 'r')):
            sh = Entity(parent=t, position=(.2 * side, .44, 0))
            part(sh, model='taper', y=-.13, scale=(.12, .27, .13), **silk)
            part(sh, model='rbox', position=(0, -.24, -.02), scale=(.17, .16, .2), **silk)  # рукав
            el = Entity(parent=sh, y=-.27)
            part(el, model='taper', y=-.12, scale=(.08, .25, .085), **lac)
            part(el, model='taper', y=-.04, scale=(.09, .03, .095), color=GOLD)
            wr = Entity(parent=el, y=-.26)
            part(wr, model='rbox', y=-.03, scale=(.07, .07, .06), color=skin)
            fan = Entity(parent=wr, y=-.05)
            part(fan, model=fan_mesh(), texture='paper', color=WHITE, double_sided=True)
            part(fan, model='rbox', y=-.04, scale=(.03, .1, .03), color=BLOOD)
            for k in (-1, 1):
                part(fan, model='rbox', position=(math.sin(math.radians(78 * k)) * .23, -math.cos(math.radians(78 * k)) * .23, 0),
                     rotation_z=-78 * k, scale=(.022, .47, .02), texture='lacquer', color=C('#ff6060'))
            self.fans.append(fan)
            self.arms[name] = (sh, el, wr)
        self.aura = Entity(parent=self)
        self.aura_parts = [glow_entity(Entity(parent=fan, model='quad', texture='glow', y=-.25, scale=.9,
                                              color=Color(.4, 1, .85, .45), double_sided=True)) for fan in self.fans]

    def animate_body(self, dt):
        super().animate_body(dt)
        on = self.energy >= 100 or self.pose_override == 'ult'
        for a in getattr(self, 'aura_parts', []):
            a.enabled = on

    def run_pose(self, ph):
        """Бег с веерами, отведёнными назад и в стороны, лёгкий шаг и покачивание бёдер"""
        p = dict(self.IDLE)
        self.run_legs(ph, p, stride=40, sway=7, lean=16, twist=11)
        sn = math.sin(ph)
        p['sh_l'] = (52 + 6 * sn, 10, 24)
        p['sh_r'] = (52 - 6 * sn, -10, -24)
        p['el_l'] = p['el_r'] = -12
        p['wr_l'] = p['wr_r'] = (0, 0, 0)
        return p

    def apply_extra(self, p):
        lift = self.move_amt * 40 + (40 if self.dash_t > 0 else 0)
        for i, s in enumerate(self.hair):
            if i == 0:
                s.rotation_x = -150 - p['torso'][0] - p['head'][0] + lift * .4
            else:
                s.rotation_x = math.sin(game.clock * 5 + i * .7) * (3 + i) - lift * .05
            s.rotation_z = math.sin(game.clock * 3.3 + i * .5) * 4

    def extra_fx(self, kind, prm, pos, h):
        f = dir_of(h)
        if kind == 'volley':
            for k, da in enumerate((-16, -8, 0, 8, 16)):
                waves.append(RazorFeather(pos + f * .6, h + da, delay=abs(da) * .004))
            flash_fx(BIG_ARC, pos, (0, h, 0), WIND, .35, 1.0, .2)
            burst(pos + f * 1.2, 10, WIND2, 5, .08, .4, grav=0, glow=True)
            sfx('dash', .55, 1.7)
            sfx('wave', .4, 1.6)
        elif kind == 'windblade':
            waves.append(WindBlade(pos + f * .8, h))
            sfx('wave', .5, 1.4)
        elif kind == 'gust':
            big = prm.get('big')
            flash_fx(BIG_ARC, pos, (0, h, 0), WIND, .5, 1.9 if big else 1.5, .32)
            flash_fx(BIG_ARC, pos + Vec3(0, .3, 0), (0, h, 8), WIND2, .4, 1.7 if big else 1.3, .25)
            for i in range(14 if big else 8):
                burst(pos + f * random.uniform(1, 5) + Vec3(random.uniform(-1.5, 1.5), 0, 0), 1, WIND2, 6, .1, .6,
                      grav=-1, glow=True)
            sfx('wave', .7, .8)
            game.shake = max(game.shake, .2)
        elif kind == 'fanthrow':
            waves.append(FanBoomerang(self, h - 12))
            waves.append(FanBoomerang(self, h + 12, delay=.08))
            sfx('dash', .5, 1.5)
        elif kind == 'windquake':
            shockring(self.position, 8, WIND)
            shockring(self.position, 5.5, WIND2, .4)
            burst(self.position + Vec3(0, .4, 0), 24, WIND2, 8, .1, .7, grav=0, glow=True)
            add_flash(self.position + Vec3(0, 1, 0), (.3, 1, .8), 9, .35)
        elif kind == 'cyclone':
            waves.append(Cyclone(flat(self.position) + f * 6.5, life=3.6, radius=4.6, dmg=11))
            sfx('wave', .7, .6)
        elif kind == 'bigcyclone':
            waves.append(Cyclone(flat(self.position), life=3.0, radius=6.2, dmg=16, big=True))
            shockring(self.position, 9, WIND)
            add_flash(self.position + Vec3(0, 1, 0), (.3, 1, .8), 11, .5)


def seg_dist(p, a, b):
    ab = b - a
    L2 = ab.dot(ab)
    if L2 < 1e-6:
        return (p - a).length()
    t = max(0, min(1, (p - a).dot(ab) / L2))
    return (p - (a + ab * t)).length()


def move_input():
    x = held_keys['d'] - held_keys['a']
    z = held_keys['w'] - held_keys['s']
    if not x and not z:
        return Vec3(0, 0, 0)
    f = dir_of(cam.yaw)
    r = Vec3(f[2], 0, -f[0])
    return (f * z + r * x).normalized()


# =====================================================================
# ДЕМОНЫ
# =====================================================================
enemies = []
orbs = []
waves = []
fireballs = []


def chain(parent, n, seg_len, size0, size1, rot_step, tex=None, col=None, first_rot=(0, 0, 0)):
    """Цепочка сегментов для рогов и хвостов"""
    root = Entity(parent=parent, rotation=first_rot)
    cur = root
    segs = []
    for i in range(n):
        k = i / max(1, n - 1)
        s = size0 + (size1 - size0) * k
        kw = dict(model='rbox', y=seg_len / 2, scale=(s, seg_len * 1.05, s))
        if tex:
            kw['texture'] = tex
        part(cur, color=col or WHITE, **kw)
        nxt = Entity(parent=cur, y=seg_len, rotation=rot_step)
        segs.append(cur)
        cur = nxt
    return root, segs


def time_now():
    return game.clock


def gone(e):
    """Демон уже убран со сцены (например, вместе с боссом) — трогать его нельзя"""
    try:
        return e not in enemies or e.is_empty()
    except Exception:
        return True


class Enemy(Entity):
    kind = 'enemy'
    title = ''
    hp_base = 100
    speed = 3.0
    dmg = 10
    radius = .5
    height = 2.0
    size = 1.0
    flying = False
    armor = False
    souls = 6
    TEX = 'skin_red'
    TINT = WHITE
    TEX2 = 'skin_dark'
    TINT2 = C('#404040')

    def __init__(self, pos, level=0, boss=False, elite=False):
        super().__init__(position=pos)
        self.boss = boss
        self.elite = elite and not boss
        D = game.diff
        mult = (1 + .45 * level) * D['hp'] * (10 if boss else 1) * (2.2 if self.elite else 1)
        self.max_hp = int(self.hp_base * mult)
        self.hp = self.max_hp
        self.dmg = int(self.dmg * (1 + .2 * level) * D['dmg'] * (1.35 if boss else 1) * (1.3 if self.elite else 1))
        self.speed = self.speed * (1 + .03 * level)
        self.speed = self.speed * (1.15 if self.elite else 1)
        grow = 2.1 if boss else (1.18 if self.elite else 1)
        self.sz = self.size * grow
        self.radius = self.radius * grow
        self.height = self.height * grow
        self.state = 'chase'
        self.timer = 0
        self.kb = Vec3(0, 0, 0)
        self.phase = random.uniform(0, 6)
        self.stun = 0
        self.hesitated = False
        self.enraged = False
        self.special_t = random.uniform(4, 7)
        self.vis = Entity(parent=self, scale=self.sz)
        self.eyes = []
        self.build()
        bake_rig(self.vis)
        self.shadow = blob_shadow(self, self.radius * 3)
        self.hp_root = Entity(parent=self, y=self.height + .45, billboard=True, enabled=False)
        glow_entity(Entity(parent=self.hp_root, model='quad', scale=(1.1, .1), color=C('#200609', .9)))
        self.hp_fill = glow_entity(Entity(parent=self.hp_root, model='quad', scale=(1.06, .06), x=-.53,
                                          origin=(-.5, 0), z=-.01, color=BLOOD))
        if self.elite:
            glow_entity(Entity(parent=self, model='quad', texture='glow', rotation_x=90, y=.05, scale=self.radius * 5,
                               color=C('#ff2020', .55), double_sided=True))
            self.crown = glow_entity(Entity(parent=self, model='diamond', y=self.height + .9, scale=(.25, .35, .25),
                                            color=C('#ffb020')))
        self.vis.scale_y = .01
        self.vis.animate_scale_y(self.sz, duration=.45, curve=curve.out_back)
        burst(pos + Vec3(0, .5, 0), 16, C('#3a050a'), 4, .2, .6, grav=-2)
        decal(pos, self.radius * 2.5, C('#c3121e', .6), .4, life=.7)
        if boss:
            boss_root.enabled = True
            sfx('roar', .9, .8)

    def build(self):
        pass

    # -------- урон
    def take(self, dmg, crit, push):
        if self.hp <= 0 or gone(self):
            return
        self.hp -= dmg
        player.register_hit()
        if not (self.armor or self.boss) or self.state in ('chase', 'hover', 'grounded'):
            self.kb = Vec3(push) * (1 if not (self.armor or self.boss) else .25)
        if not (self.armor or self.boss) and self.state not in ('dive',):
            self.stun = .22
        self.hp_root.enabled = not self.boss
        self.hp_fill.scale_x = 1.06 * max(0, self.hp) / self.max_hp
        for e in self.eyes:
            e.blink(BONE, duration=.12)
        center = self.position + Vec3(0, self.height * .5, 0)
        burst(center, 10 if crit else 6, EMBER, 6, .1, .45, glow=True)
        burst(center, 5, C('#5a0008'), 4, .1, .6)
        popup_number(center + Vec3(0, self.height * .6, 0), str(dmg), GOLD if crit else BONE, big=crit)
        sfx('hit', .5)
        if self.boss and not self.enraged and self.hp < self.max_hp / 2:
            self.enraged = True
            banner('ЯРОСТЬ', EMBER)
            sfx('roar', 1, .7)
            self.speed *= 1.3
        if self.hp <= 0:
            self.die()

    def die(self):
        center = self.position + Vec3(0, self.height * .5, 0)
        burst(center, 26 if not self.boss else 80, BLOOD, 8, .16, .8)
        burst(center, 12, EMBER, 7, .1, .6, glow=True)
        burst(center, 12, INK, 5, .22, .8)
        add_flash(center, (1, .25, .15), 7 if not self.boss else 14, .4)
        sfx('kill', .5)
        for _ in range(2 if not self.boss else 8):
            orbs.append(Orb(center))
        gain = self.souls * (3 if self.elite else 1) * (1 + .15 * dungeon.level)
        gain = int(gain * (1 + min(1.0, player.combo / 50)))
        game.souls += gain
        popup_number(center + Vec3(0, self.height * .9, 0), f'+{gain} душ', C('#c8a0ff'))
        game.kills += 1
        player.energy = min(100, player.energy + (2 if not self.boss else 10))
        if self.elite:
            orbs.append(Orb(center))
        self.on_death(center)
        if self in enemies:
            enemies.remove(self)
        if self.boss and not any(e.boss for e in enemies):
            boss_root.enabled = False
            game.boss_down(self)
        destroy(self)

    # -------- кадр
    def tick(self, dt):
        dt = dt * game.diff['tempo']
        self.phase += dt
        if self.stun > 0:
            self.stun -= dt
        else:
            self.think(dt)
            # демоны иногда замирают рядом с Харуказэ — кровь Сирасаги
            if (self.state == 'windup' and not self.hesitated and not self.boss and player is not None
                    and player.KIND == 'kaze'):
                self.hesitated = True
                if random.random() < .22 and dist2d(self.position, player.position) < 7:
                    self.state, self.timer = 'recover', 1.1
                    popup_number(self.position + Vec3(0, self.height + .5, 0), '...', C('#c8a0ff'))
        # отталкивание
        for o in enemies:
            if o is self or o.flying != self.flying:
                continue
            v = flat(self.position - o.position)
            d = v.length()
            mind = self.radius + o.radius
            if .001 < d < mind:
                self.position += v.normalized() * (mind - d) * .5
        self.position += self.kb * dt
        self.kb *= max(0, 1 - dt * 7)
        dungeon.collide(self, self.radius)
        self.shadow.y = .03 - self.y
        self.anim(dt)
        if self.boss:
            bosses = [e for e in enemies if e.boss]
            boss_fill.scale_x = .88 * sum(max(0, e.hp) for e in bosses) / max(1, sum(e.max_hp for e in bosses))
            boss_name.text = '  ·  '.join(e.title for e in bosses)

    def to_player(self):
        to = flat(player.position - self.position)
        d = to.length()
        return (to / d if d > .01 else Vec3(0, 0, 1)), d

    def face(self, dirv, dt, rate=8):
        self.rotation_y = lerp_angle(self.rotation_y, heading_of(dirv), min(1, dt * rate))

    def think(self, dt):
        pass

    def anim(self, dt):
        pass

    def on_slam(self, pos, hit):
        pass

    def on_death(self, center):
        pass

    def summon(self, kind_cls, n):
        for i in range(n):
            a = random.uniform(0, math.tau)
            p = flat(self.position) + Vec3(math.sin(a), 0, math.cos(a)) * random.uniform(3, 6)
            dungeon.spawn_enemy(kind_cls, p)


# ------------------------------------------------------------ гаки
class Gaki(Enemy):
    """Голодный дух: мелкий, быстрый, нападает стаей"""
    TEX, TINT, souls = 'skin_bone', C('#d0c4bc'), 4
    kind, title = 'gaki', 'ГАКИ'
    hp_base, speed, dmg, radius, height, size = 45, 5.0, 8, .38, 1.3, .85

    def build(self):
        v = self.vis
        sk = dict(texture=self.TEX, color=self.TINT)
        self.legs = []
        for x in (-.12, .12):
            hip = Entity(parent=v, position=(x, .55, 0))
            part(hip, model='taper', y=-.27, scale=(.08, .55, .08), **sk)
            self.legs.append(hip)
        self.trunk = Entity(parent=v, y=.55, rotation_x=35)
        part(self.trunk, model='torso', y=.25, scale=(.36, .5, .26), **sk)
        part(self.trunk, model='orb', y=.1, z=.08, scale=(.34, .3, .3), **sk)  # вздутый живот
        head = Entity(parent=self.trunk, y=.55, z=.08, rotation_x=-30)
        part(head, model='orb', scale=(.34, .36, .36), **sk)
        part(head, model='rbox', position=(0, -.12, .12), scale=(.22, .06, .14), color=C('#2a0a0c'))
        for x in (-.07, -.02, .03, .08):
            part(head, model='rbox', position=(x, -.09, .2), scale=(.02, .05, .02), color=BONE)
        self.eyes = [part(head, unlit=True, model='orb', position=(x, .04, .16), scale=(.07, .05, .04), color=EMBER)
                     for x in (-.08, .08)]
        self.arms = []
        for x in (-.22, .22):
            sh = Entity(parent=self.trunk, position=(x, .42, 0))
            part(sh, model='taper', y=-.3, scale=(.07, .6, .07), **sk)
            for k in (-1, 0, 1):
                part(sh, model='diamond', position=(k * .025, -.65, .02), scale=(.02, .1, .02), color=BONE)
            self.arms.append(sh)

    def think(self, dt):
        dv, d = self.to_player()
        if self.state == 'chase':
            self.face(dv, dt, 10)
            if d > 1.8:
                self.position += dv * self.speed * dt
            else:
                self.state, self.timer = 'windup', .32
        elif self.state == 'windup':
            self.timer -= dt
            if self.timer <= 0:
                self.state, self.timer = 'lunge', .25
                self.lunge_dir = dv
        elif self.state == 'lunge':
            self.timer -= dt
            self.position += self.lunge_dir * 13 * dt
            if dist2d(self.position, player.position) < self.radius + .7:
                player.hurt(self.dmg, self.position)
                self.state, self.timer = 'recover', .6
            if self.timer <= 0:
                self.state, self.timer = 'recover', .5
        elif self.state == 'recover':
            self.timer -= dt
            if self.timer <= 0:
                self.state = 'chase'

    def anim(self, dt):
        w = math.sin(self.phase * 14) * 35 if self.state == 'chase' else 0
        self.legs[0].rotation_x, self.legs[1].rotation_x = w, -w
        reach = -110 if self.state in ('windup', 'lunge') else -w * .8
        for a in self.arms:
            a.rotation_x = lerp(a.rotation_x, reach, min(1, dt * 14))
        self.trunk.rotation_x = lerp(self.trunk.rotation_x, 55 if self.state == 'lunge' else 35, min(1, dt * 10))


# ------------------------------------------------------------ они с канабо
class Oni(Enemy):
    TEX, TINT, souls = 'skin_red', C('#a07070'), 14
    """Громила с шипастой дубиной: медленный, бьёт по площади"""
    kind, title = 'oni', 'ВЕЛИКИЙ ОНИ ГОРО'
    hp_base, speed, dmg, radius, height, size = 280, 2.4, 26, .85, 2.7, 1.25
    armor = True

    def build(self):
        v = self.vis
        sk = dict(texture=self.TEX, color=self.TINT)
        self.legs = []
        for x in (-.25, .25):
            hip = Entity(parent=v, position=(x, .78, 0))
            part(hip, model='taper', y=-.39, scale=(.3, .78, .32), **sk)
            self.legs.append(hip)
        part(v, model='rbox', y=.82, scale=(.85, .32, .6), texture='cloth', color=C('#ffd080'))  # набедренник
        self.trunk = Entity(parent=v, y=.95)
        part(self.trunk, model='torso', y=.45, z=.05, rotation_x=14, scale=(1.0, .9, .72), **sk)
        part(self.trunk, model='rbox', y=.25, z=.33, scale=(.7, .35, .1), **sk)
        head = Entity(parent=self.trunk, y=1.0, z=.28)
        part(head, model='rbox', scale=(.56, .52, .5), **sk)
        part(head, model='rbox', position=(0, -.18, .2), scale=(.5, .14, .2), **sk)
        for x in (-.16, .16):
            part(head, model='diamond', position=(x, -.12, .32), scale=(.05, .14, .05), color=BONE)  # клыки
            part(head, model='diamond', position=(x, .36, 0), rotation_z=-x * 90, scale=(.09, .38, .09),
                 texture='horn', color=WHITE)
        part(head, model='rbox', position=(0, .15, .26), scale=(.5, .07, .04), color=INK)  # бровь
        self.eyes = [part(head, unlit=True, model='orb', position=(x, .07, .26), scale=(.11, .07, .04), color=EMBER)
                     for x in (-.13, .13)]
        self.arms = []
        for x in (-.62, .62):
            sh = Entity(parent=self.trunk, position=(x, .78, .1))
            part(sh, model='taper', y=-.45, scale=(.26, .95, .28), **sk)
            self.arms.append(sh)
        club = Entity(parent=self.arms[1], y=-.95, rotation_x=90)
        part(club, model='rbox', y=.9, scale=(.22, 1.9, .22), texture='metal', color=C('#c0b0b0'))
        for i in range(6):
            for ry in (0, 90):
                part(club, model='diamond', position=(0, 1.0 + i * .16, 0), rotation_y=ry, scale=(.38, .05, .05),
                     color=C('#c8a868'))

    def think(self, dt):
        dv, d = self.to_player()
        if self.boss:
            self.special_t -= dt
        if self.state == 'chase':
            self.face(dv, dt, 5)
            if self.boss and self.special_t <= 0:
                self.special_t = 9 if not self.enraged else 6
                if random.random() < .5:
                    self.state, self.timer = 'rings', 1.0
                    sfx('roar', .9, .75)
                else:
                    self.summon(Gaki, 3 if self.enraged else 2)
                    sfx('roar', .8, .9)
                return
            reach = self.radius + 1.9
            if d > reach:
                self.position += dv * self.speed * dt
            else:
                self.state, self.timer = 'windup', .9 if not self.boss else .75
                self.slam_r = 3.2 * (1.6 if self.boss else 1)
                self.slam_pos = flat(self.position) + dir_of(self.rotation_y) * (self.radius + 1.2)
                decal(self.slam_pos, self.slam_r, dur=self.timer)
        elif self.state == 'windup':
            self.timer -= dt
            if self.timer <= 0:
                hit = dist2d(player.position, self.slam_pos) < self.slam_r and player.y < 1.2
                if hit:
                    player.hurt(self.dmg, self.slam_pos)
                self.on_slam(self.slam_pos, hit)
                shockring(self.slam_pos, self.slam_r * 1.3)
                ground_crack(self.slam_pos, self.rotation_y, 2.5)
                add_flash(self.slam_pos + Vec3(0, 1, 0), (1, .3, .1), 8, .3)
                game.shake = max(game.shake, .4)
                sfx('hit', .8, .6)
                self.state, self.timer = 'recover', 1.0
        elif self.state == 'rings':
            # серия волн по земле: перепрыгни!
            self.timer -= dt
            if self.timer <= 0:
                self.ring_list = [[0.0, 0.0], [-.6, 0.0], [-1.2, 0.0]]
                game.shake = .5
                self.state = 'rings_go'
                for i in range(3):
                    invoke(shockring, flat(self.position), 22, C('#ff3b2f', .9), 1.8, delay=i * .6)
        elif self.state == 'rings_go':
            alive = False
            for rg in self.ring_list:
                rg[0] += dt
                if rg[0] > 0:
                    r = 22 * min(1, rg[0] / 1.8)
                    pd = dist2d(player.position, self.position)
                    if abs(pd - r) < .7 and player.y < .5 and rg[1] == 0:
                        player.hurt(int(self.dmg * .7), self.position)
                        rg[1] = 1
                if rg[0] < 1.8:
                    alive = True
            if not alive:
                self.state, self.timer = 'recover', .8
        elif self.state == 'recover':
            self.timer -= dt
            if self.timer <= 0:
                self.state = 'chase'

    def anim(self, dt):
        w = math.sin(self.phase * self.speed * 2.4) * 25 if self.state == 'chase' else 0
        self.legs[0].rotation_x, self.legs[1].rotation_x = w, -w
        if self.state == 'windup':
            club, other = -165, -120
            self.trunk.rotation_x = lerp(self.trunk.rotation_x, -14, min(1, dt * 8))
        elif self.state == 'recover' and self.timer > .7:
            club, other = -30, -20
            self.trunk.rotation_x = lerp(self.trunk.rotation_x, 22, min(1, dt * 14))
        elif self.state in ('rings', 'rings_go'):
            club, other = -170, -170
        else:
            club, other = -40 - w * .4, w * .6
            self.trunk.rotation_x = lerp(self.trunk.rotation_x, 0, min(1, dt * 6))
        self.arms[1].rotation_x = lerp(self.arms[1].rotation_x, club, min(1, dt * 12))
        self.arms[0].rotation_x = lerp(self.arms[0].rotation_x, other, min(1, dt * 12))
        glow = self.state == 'windup'
        for e in self.eyes:
            e.scale_x = .16 if glow else .11


# ------------------------------------------------------------ онибі
class Onibi(Enemy):
    FLAME1, FLAME2, CORE, SHOT, SLOW, souls = C('#ff3b2f', .55), C('#ff8a3d', .5), C('#ffd2b0'), None, 0, 7
    """Блуждающий огонь: держит дистанцию и плюётся огненными шарами"""
    kind, title = 'onibi', 'ХИ-НО-КАМИ, ПОВЕЛИТЕЛЬ ПЛАМЕНИ'
    hp_base, speed, dmg, radius, height, size = 55, 3.6, 14, .5, 2.2, .9
    flying = True

    def build(self):
        v = self.vis
        self.fly_y = random.uniform(1.6, 2.2)
        self.flames = []
        for i in range(5):
            f = glow_entity(Entity(parent=v, model='quad', texture='glow', billboard=True, scale=.9 - i * .1,
                                   color=self.FLAME1 if i % 2 else self.FLAME2))
            self.flames.append(f)
        self.core = glow_entity(Entity(parent=v, model='orb', scale=.32, color=self.CORE))
        skull = Entity(parent=v, z=.12)
        part(skull, model='orb', scale=(.3, .28, .26), texture='skin_bone', color=WHITE)
        self.eyes = [glow_entity(Entity(parent=skull, model='rbox', position=(x, .03, .13), scale=(.07, .05, .02),
                                        color=C('#200000'))) for x in (-.06, .06)]
        self.shoot_t = random.uniform(1.5, 2.5)

    def think(self, dt):
        dv, d = self.to_player()
        self.face(dv, dt, 6)
        if self.boss:
            self.special_t -= dt
            if self.special_t <= 0:
                self.special_t = 6 if not self.enraged else 4
                nova(self.position, 14 if not self.enraged else 20, self.dmg)
                self.summon(Gaki, 2)
        side = Vec3(dv[2], 0, -dv[0])
        if d > 10:
            self.position += dv * self.speed * dt
        elif d < 6.5:
            self.position -= dv * self.speed * dt
        self.position += side * math.sin(self.phase * .7) * 1.6 * dt
        self.shoot_t -= dt
        if self.state == 'chase' and self.shoot_t <= 0:
            self.state, self.timer = 'windup', .55
        elif self.state == 'windup':
            self.timer -= dt
            if self.timer <= 0:
                n = 3 if self.boss else 1
                for i in range(n):
                    spread = (i - (n - 1) / 2) * 18
                    fireballs.append(Fireball(self.position + dv * .6, dir_of(heading_of(dv) + spread), self.dmg,
                                              col=self.SHOT, slow=self.SLOW))
                sfx('fireball', .5)
                self.state = 'chase'
                self.shoot_t = random.uniform(1.5, 2.4)

    def anim(self, dt):
        self.y = lerp(self.y, self.fly_y + math.sin(self.phase * 2.6) * .3, min(1, dt * 4))
        charge = 1.6 if self.state == 'windup' else 1
        for i, f in enumerate(self.flames):
            f.scale = (.9 - i * .1) * charge * (1 + .12 * math.sin(self.phase * 11 + i))
            f.y = i * .1 + math.sin(self.phase * 7 + i) * .05
        if random.random() < .4:
            burst(self.position + Vec3(0, -.1, 0), 1, C('#ff4a3d', .8), 1, .1, .5, grav=-3, glow=True)


# ------------------------------------------------------------ клинорук
class BladeDemon(Enemy):
    souls = 11
    """Красный демон с клинками на руках и хвостом: рывок-разрез"""
    kind, title = 'blade', 'КАМАИТАТИ, ЖНЕЦ ЁМИ'
    hp_base, speed, dmg, radius, height, size = 150, 4.4, 22, .5, 2.4, 1.0

    def build(self):
        v = self.vis
        sk = dict(texture=self.TEX, color=self.TINT)
        dk = dict(texture=self.TEX2, color=self.TINT2)
        self.legs = []
        for x in (-.14, .14):
            hip = Entity(parent=v, position=(x, 1.0, 0))
            part(hip, model='taper', y=-.25, scale=(.17, .5, .19), **sk)
            knee = Entity(parent=hip, y=-.5, rotation_x=10)
            part(knee, model='taper', y=-.24, scale=(.13, .48, .14), **dk)
            for k in (-1, 0, 1):
                part(knee, model='diamond', position=(k * .05, -.5, .1), rotation_x=70, scale=(.025, .14, .025),
                     color=C('#c0a080'))
            self.legs.append(hip)
        self.trunk = Entity(parent=v, y=1.02)
        part(self.trunk, model='rbox', y=.15, scale=(.3, .3, .2), **sk)
        part(self.trunk, model='torso', y=.5, scale=(.5, .45, .28), **sk)
        part(self.trunk, model='rbox', y=.5, z=.13, scale=(.36, .36, .04), **sk)
        for x in (-.28, .28):
            part(self.trunk, model='diamond', position=(x, .76, 0), rotation_z=-x * 120, scale=(.05, .16, .05),
                 color=C('#c0a080'))
        head = Entity(parent=self.trunk, y=.92, z=.05)
        part(head, model='rbox', y=-.1, scale=(.12, .2, .12), **sk)
        part(head, model='orb', y=.08, scale=(.22, .26, .26), **dk)
        part(head, model='rbox', position=(0, -.03, .11), scale=(.13, .1, .06), color=C('#200406'))
        self.eyes = [part(head, unlit=True, model='rbox', position=(x, .1, .12), scale=(.06, .02, .02), color=EMBER)
                     for x in (-.05, .05)]
        for side in (-1, 1):
            chain(head, 4, .2, .07, .02, (25, 0, -12 * side), 'skin_dark', C('#606060'),
                  first_rot=(-65, 0, -70 * side))
        self.arms = []
        for side in (-1, 1):
            sh = Entity(parent=self.trunk, position=(.32 * side, .66, 0))
            part(sh, model='taper', y=-.2, scale=(.12, .4, .12), **sk)
            el = Entity(parent=sh, y=-.4, rotation_x=-20)
            part(el, model='taper', y=-.18, scale=(.1, .36, .1), **sk)
            blade = part(el, model='diamond', position=(.04 * side, -.35, .05), rotation=(0, 0, -6 * side),
                         scale=(.04, 1.0, .1), texture='horn', color=WHITE)
            self.arms.append((sh, el, blade))
        tail_root = Entity(parent=v, position=(0, .95, -.15), rotation_x=120)
        self.tail_root, self.tail = chain(tail_root, 8, .16, .1, .03, (-12, 0, 0), 'skin_red', WHITE)
        tip = Entity(parent=self.tail[-1], y=.18)
        for ry in (0, 60, 120):
            part(tip, model='diamond', rotation_y=ry, scale=(.04, .18, .04), color=C('#c0a080'))
        self.dash_left = 0

    def think(self, dt):
        dv, d = self.to_player()
        if self.state == 'chase':
            self.face(dv, dt, 9)
            if d > 6:
                self.position += dv * self.speed * dt
            elif d < 2.5:
                self.position -= dv * self.speed * .5 * dt
                self.state, self.timer = 'aim', .3
            else:
                self.state, self.timer = 'aim', .45 if not self.enraged else .32
            if self.state == 'aim':
                self.dash_dir = dv
                self.dash_left = 3 if self.boss else 1
                line = glow_entity(Entity(model='quad', position=flat(self.position) + dv * 4.5 + Vec3(0, .05, 0),
                                          rotation=(90, heading_of(dv), 0), scale=(1.2 * self.sz, 9),
                                          color=C('#ff2a2a', .35), double_sided=True))
                destroy(line, delay=self.timer)
        elif self.state == 'aim':
            self.timer -= dt
            self.face(self.dash_dir, dt, 20)
            if self.timer <= 0:
                self.state, self.timer = 'dash', .32
                self.hit_done = False
                sfx('slash', .6, .7)
        elif self.state == 'dash':
            self.timer -= dt
            self.position += self.dash_dir * 26 * dt
            if random.random() < .8:
                burst(self.position + Vec3(0, 1.2, 0), 1, EMBER, .5, .1, .3, grav=0, glow=True)
            if not self.hit_done and dist2d(self.position, player.position) < self.radius + 1.0 and abs(player.y) < 1.4:
                player.hurt(self.dmg, self.position)
                self.hit_done = True
            if self.timer <= 0:
                self.dash_left -= 1
                if self.dash_left > 0:
                    dv, d = self.to_player()
                    self.dash_dir = dv
                    self.state, self.timer = 'aim', .25
                elif self.boss and self.enraged and random.random() < .4:
                    self.state, self.timer = 'spin', .7
                    decal(flat(self.position), 4.2, dur=.7)
                else:
                    self.state, self.timer = 'recover', .85
        elif self.state == 'spin':
            self.timer -= dt
            self.rotation_y += dt * 1400
            if self.timer <= 0:
                if dist2d(player.position, self.position) < 4.2:
                    player.hurt(self.dmg, self.position)
                flash_fx(SPIN_ARC, self.position + Vec3(0, 1.2, 0), (0, 0, 0), C('#ff3b2f', .8), 1.4, 1.8, .3)
                self.state, self.timer = 'recover', 1.0
        elif self.state == 'recover':
            self.timer -= dt
            if self.timer <= 0:
                self.state = 'chase'
                if self.boss:
                    self.special_t -= 1
                    if self.special_t <= 0:
                        self.special_t = 4
                        self.summon(Onibi, 2)

    def anim(self, dt):
        w = math.sin(self.phase * 11) * 30 if self.state == 'chase' else 0
        self.legs[0].rotation_x, self.legs[1].rotation_x = w, -w
        pose = {'aim': (-60, 70), 'dash': (40, 90), 'spin': (-90, 90)}.get(self.state, (-w * .5, 20))
        for i, (sh, el, bl) in enumerate(self.arms):
            side = -1 if i == 0 else 1
            sh.rotation_x = lerp(sh.rotation_x, pose[0], min(1, dt * 14))
            sh.rotation_z = lerp(sh.rotation_z, -pose[1] * .3 * side, min(1, dt * 14))
        self.trunk.rotation_x = lerp(self.trunk.rotation_x, 30 if self.state in ('aim', 'dash') else 8, min(1, dt * 10))
        for i, s in enumerate(self.tail):
            s.rotation_y = math.sin(self.phase * 4 + i * .6) * 14


# ------------------------------------------------------------ крылатый демон
class WingedDemon(Enemy):
    TEX, WTEX, WTINT, SHOOT, souls = 'skin_dark', 'membrane', C('#ffffff', .92), False, 15
    """Рогатый демон с крыльями: кружит в воздухе и пикирует"""
    kind, title = 'winged', 'ОКО БЕЗДНЫ'
    hp_base, speed, dmg, radius, height, size = 190, 4.0, 25, .6, 2.0, 1.05
    flying = True
    FLY_Y = 2.9

    def build(self):
        self.build_eye()
        self.fly_y = self.FLY_Y if not self.boss else 3.0
        self.state = 'hover'
        self.timer = random.uniform(2.5, 4)
        self.orbit = random.uniform(0, math.tau)
        self.flap_snd = 0

    IRIS, IRIS_IN, HALO = C('#ff5a1a'), C('#ffd040'), C('#ff3020', .22)
    WING_COL, WING_SHADE = C('#f7f5fb'), C('#dcd8e6')

    def build_eye(self):
        """Летающее око: просто огромный глаз с крыльями"""
        v = self.vis
        self.trunk = Entity(parent=v, y=1.0)
        t = self.trunk
        # ореол, чтобы его было видно в темноте подземелья
        # billboard=True в Ursina сдвигает квад на 1 к камере — тогда ореол закрывает глаз красной пеленой.
        # Ставим ореол позади глаза
        self.halo = glow_entity(Entity(parent=t, model='quad', texture='glow', scale=2.8, color=self.HALO))
        try:
            self.halo.setBillboardPointEye(-.6)
        except Exception:
            self.halo.billboard = True
        part(t, model='orb', scale=1.4, texture='eyeball', color=WHITE)
        # радужка и вертикальный зрачок-щель — светятся
        self.iris_root = Entity(parent=t)
        self.iris = glow_entity(Entity(parent=self.iris_root, model='orb', z=.6, scale=(.66, .66, .25),
                                       color=self.IRIS))
        glow_entity(Entity(parent=self.iris_root, model='orb', z=.64, scale=(.46, .46, .2), color=self.IRIS_IN))
        self.pupil = Entity(parent=self.iris_root, model='orb', z=.73, scale=(.12, .44, .08), color=C('#050102'))
        self.pupil.unlit = True
        self.eyes = [self.iris]
        self.jaw = self.iris_root
        # белые перьевые крылья растут прямо из боков глаза
        self.wings = []
        for side in (-1, 1):
            pv = Entity(parent=t, position=(.6 * side, .1, -.15))
            w = Entity(parent=pv, scale=(side * .95, .95, 1))
            feather_wing(w, self.WING_COL, self.WING_SHADE)
            self.wings.append(pv)
        self.arms, self.legs, self.tails = [], [], []
        dlog('eye model built:', type(self).__name__, 'boss' if self.boss else '', 'wings', len(self.wings))

    def think(self, dt):
        dv, d = self.to_player()
        if self.boss:
            self.special_t -= dt
        if self.state == 'hover':
            self.orbit += dt * .6
            # кружит перед камерой, а не за спиной игрока — чтобы его было видно
            ang = cam.yaw + 55 * math.sin(self.orbit)
            tgt = flat(player.position) + dir_of(ang) * (7 if not self.boss else 9)
            mv = tgt - flat(self.position)
            if mv.length() > .2:
                self.position += mv.normalized() * min(mv.length(), self.speed * 1.5 * dt * 2)
            self.y = lerp(self.y, self.fly_y + math.sin(self.phase * 2) * .3, min(1, dt * 2))
            self.face(dv, dt, 5)
            self.timer -= dt
            if self.SHOOT:
                self.shot_t = getattr(self, 'shot_t', 2.0) - dt
                if self.shot_t <= 0 and d < 15:
                    self.shot_t = random.uniform(1.6, 2.4)
                    fireballs.append(Fireball(self.position + Vec3(0, 1.2 * self.sz, 0), dv, int(self.dmg * .7),
                                              col=C('#7affc8')))
                    sfx('flap', .5, 1.3)
            if self.boss and self.special_t <= 0:
                self.special_t = 10 if not self.enraged else 7
                self.state, self.timer = 'rain', 1.4
                sfx('roar', .9, .85)
                self.rain_spots = []
                for i in range(7 if self.enraged else 5):
                    p = flat(player.position) + Vec3(random.uniform(-6, 6), 0, random.uniform(-6, 6))
                    if i == 0:
                        p = flat(player.position)
                    self.rain_spots.append(p)
                    decal(p, 2.2, dur=1.4)
                return
            if self.timer <= 0:
                self.state, self.timer = 'screech', .65
                self.dive_target = flat(player.position)
                decal(self.dive_target, 2.0, dur=.65 + .5)
                sfx('shriek', .7)
        elif self.state == 'screech':
            self.timer -= dt
            self.face(dv, dt, 12)
            self.y = lerp(self.y, self.fly_y + (.5 if self.boss else 1.0), min(1, dt * 3))
            if self.timer <= 0:
                self.state = 'dive'
                self.dives = getattr(self, 'dives', 0) + 1
                self.hit_done = False
        elif self.state == 'dive':
            to = Vec3(self.dive_target[0], .2, self.dive_target[2]) - self.position
            if to.length() < .8:
                if dist2d(player.position, self.position) < 2.2 + (1 if self.boss else 0) and player.y < 1.5:
                    player.hurt(self.dmg, self.position)
                shockring(self.position, 4 if not self.boss else 7)
                ground_crack(self.position, self.rotation_y, 2)
                game.shake = max(game.shake, .35)
                sfx('hit', .7, .7)
                if self.boss and self.dives < 3:
                    self.state, self.timer = 'takeoff', .5
                    self.after_takeoff = 'screech'
                else:
                    self.dives = 0
                    self.state, self.timer = 'grounded', 1.8
            else:
                self.position += to.normalized() * 21 * dt
                self.face(flat(to), dt, 12)
        elif self.state == 'grounded':
            self.timer -= dt
            self.y = lerp(self.y, 0, min(1, dt * 8))
            self.face(dv, dt, 6)
            if d < 2.6 and not getattr(self, 'claw_cd', 0) > 0:
                self.claw_cd = 1.2
                decal(flat(self.position) + dv * 1.3, 1.6, dur=.4)
                invoke(self.claw, delay=.4)
            self.claw_cd = getattr(self, 'claw_cd', 0) - dt
            if self.timer <= 0:
                self.state, self.timer = 'takeoff', .7
                self.after_takeoff = 'hover'
                sfx('flap', .6)
        elif self.state == 'takeoff':
            self.timer -= dt
            self.y = lerp(self.y, self.fly_y + (.4 if self.boss else 1), min(1, dt * 3))
            if self.timer <= 0:
                nxt = getattr(self, 'after_takeoff', 'hover')
                if nxt == 'screech':
                    self.state, self.timer = 'screech', .45
                    self.dive_target = flat(player.position)
                    decal(self.dive_target, 2.4, dur=.95)
                    sfx('shriek', .7)
                else:
                    self.state, self.timer = 'hover', random.uniform(2.5, 4) * (.7 if self.enraged else 1)
        elif self.state == 'rain':
            self.timer -= dt
            self.y = lerp(self.y, self.fly_y + (.6 if self.boss else 2), min(1, dt * 2))
            if self.timer <= 0:
                for i, p in enumerate(self.rain_spots):
                    invoke(lambda p=p: fireballs.append(SkyFire(p, self.dmg)), delay=i * .08)
                self.state, self.timer = 'hover', 2.5

    def claw(self):
        if gone(self):
            return
        if self in enemies and dist2d(player.position, self.position + dir_of(self.rotation_y) * 1.3) < 1.8:
            player.hurt(self.dmg, self.position)
        flash_fx(SLASH, self.position + Vec3(0, 1.2 * self.sz, 0), (0, self.rotation_y, 30), C('#3a8a8a', .7), .8, 1.1)

    def anim(self, dt):
        in_air = self.state != 'grounded'
        dive = self.state == 'dive'
        spd = 0 if dive else (10 if in_air else 4)
        amp = 0 if dive else (40 if in_air else 18)
        flap = math.sin(self.phase * spd) * amp
        for i, w in enumerate(self.wings):
            side = -1 if i == 0 else 1
            base = 70 if dive else 18
            w.rotation_z = lerp(w.rotation_z, -side * (flap - base * .3), min(1, dt * 18))
            w.rotation_y = lerp(w.rotation_y, side * (60 if dive else 20), min(1, dt * 8))
        if in_air and not dive and math.sin(self.phase * spd) > .95 and self.flap_snd <= 0:
            self.flap_snd = .5
            if player is not None and dist2d(self.position, player.position) < 14:
                sfx('flap', .22, 1.2)
        self.flap_snd -= dt
        # взгляд: наклон к игроку, при пикировании смотрит вниз
        if player is not None:
            dy = (player.y + 1.2) - (self.y + 1.0 * self.sz)
            look = -math.degrees(math.atan2(dy, max(1.0, dist2d(player.position, self.position))))
        else:
            look = 0
        tilt = 45 if dive else clamp(look, -10, 40)
        self.trunk.rotation_x = lerp(self.trunk.rotation_x, tilt, min(1, dt * 6))
        self.trunk.rotation_z = math.sin(self.phase * 1.3) * 6
        # зрачок: сужается перед броском, бегает по сторонам
        angry = self.state in ('screech', 'dive', 'rain')
        self.pupil.scale_x = lerp(self.pupil.scale_x, .06 if angry else .12, min(1, dt * 10))
        self.iris_root.rotation_y = math.sin(self.phase * .9) * 8
        self.iris_root.rotation_x = math.sin(self.phase * .7 + 1) * 5
        self.iris.scale = (.76, .76, .25) if angry else (.66, .66, .25)
        self.halo.alpha = .18 + .06 * math.sin(self.phase * 4) + (.12 if angry else 0)

# ------------------------------------------------------------ снаряды и сгустки
def nova(pos, n, dmg):
    for i in range(n):
        fireballs.append(Fireball(Vec3(pos[0], 1.4, pos[2]), dir_of(i / n * 360 + random.uniform(-4, 4)), dmg, homing=False))
    shockring(pos, 3, C('#ff7a3d', .9), .4)
    sfx('fireball', .7, .8)


class DemonLord(Oni):
    souls = 300
    """Шутэн-додзи: финальный владыка, собирает приёмы всех демонов"""
    kind, title = 'lord', 'ШУТЭН-ДОДЗИ, ВЛАДЫКА ДЕМОНОВ'
    hp_base, speed, dmg, radius, height, size = 360, 2.7, 27, .9, 3.0, 1.32   # −10% после отзыва

    def build(self):
        super().build()
        v = self.vis
        crown = Entity(parent=self.trunk, y=1.0, z=.28)
        for side in (-1, 1):
            chain(crown, 7, .16, .09, .03, (-22, 0, -20 * side), 'horn', C('#ffd28a'), first_rot=(-10, 0, -55 * side))
        for i in range(5):
            part(self.trunk, model='cube', position=(-.4 + i * .2, .9, .4), scale=(.12, .05, .04), color=GOLD)
        part(self.trunk, model='cube', position=(0, .5, .38), scale=(.8, .6, .05), texture='obsidian', color=WHITE)
        self.core = glow_entity(Entity(parent=self.trunk, model='orb', position=(0, .55, .42), scale=.22,
                                       color=C('#ffb040')))
        self.halo = Entity(parent=v, y=2.0, z=-.6)
        for k in range(12):
            a = k / 12 * 360
            r = math.radians(a)
            glow_entity(Entity(parent=self.halo, model='diamond', position=(math.sin(r) * 1.1, math.cos(r) * 1.1, 0),
                               rotation_z=-a, scale=(.08, .32, .08), color=C('#ff5a2a')))
        glow_entity(Entity(parent=self.halo, model=RING(), rotation_x=90, scale=1.2, color=C('#ff3b2f', .8),
                           double_sided=True))
        self.lord_t = 5

    def think(self, dt):
        self.lord_t -= dt
        if self.state == 'chase' and self.lord_t <= 0:
            self.lord_t = 6.5 if not self.enraged else 4.5
            pick = random.choice(('nova', 'sky', 'summon', 'nova', 'sky'))
            sfx('roar', .9, .65)
            if pick == 'nova':
                nova(self.position, 18 if not self.enraged else 26, int(self.dmg * .6))
                if self.enraged:
                    invoke(nova, Vec3(self.position), 18, int(self.dmg * .6), delay=.5)
            elif pick == 'sky':
                for i in range(6 if not self.enraged else 9):
                    p = flat(player.position) + Vec3(random.uniform(-5, 5), 0, random.uniform(-5, 5)) if i else flat(player.position)
                    decal(p, 2.2, dur=1.1)
                    invoke(lambda p=p: fireballs.append(SkyFire(p, int(self.dmg * .8))), delay=1.1 + i * .07)
            else:
                self.summon(WingedDemon if random.random() < .5 else BladeDemon, 1)
                self.summon(Gaki, 2)
            return
        super().think(dt)

    def anim(self, dt):
        super().anim(dt)
        self.halo.rotation_z += dt * 40
        self.core.scale = .22 * (1 + .2 * math.sin(self.phase * 6))


# =====================================================================
# УНИКАЛЬНЫЕ ДЕМОНЫ ПОДЗЕМЕЛИЙ
# =====================================================================
hazards = []


class LavaPool(Entity):
    """Лужа лавы после удара лавового они"""
    def __init__(self, pos, radius=2.2, life=4.5, dmg=8, col=None):
        super().__init__(position=Vec3(pos[0], .05, pos[2]))
        self.radius, self.life, self.dmg = radius, life, dmg
        self.col = col or C('#ff5a10')
        self.disc = glow_entity(Entity(parent=self, model='circle', rotation_x=90, scale=radius * 2,
                                       color=Color(self.col[0], self.col[1], self.col[2], .8), double_sided=True))
        self.t = 0
        LT.torches.append([Vec3(pos[0], .8, pos[2]), (1.4, .4, .1), 5, 0])
        self.light = LT.torches[-1]

    def tick(self, dt):
        self.life -= dt
        self.t -= dt
        self.disc.alpha = min(.8, self.life)
        if random.random() < .5:
            a = random.uniform(0, math.tau)
            r = random.uniform(0, self.radius)
            burst(self.position + Vec3(math.sin(a) * r, .1, math.cos(a) * r), 1, self.col, 1.5, .08, .5, grav=-2, glow=True)
        if self.t <= 0 and dist2d(player.position, self.position) < self.radius and player.y < .6:
            self.t = .5
            player.inv = 0 if player.inv < .3 else player.inv
            player.hurt(self.dmg, self.position)
        if self.life <= 0:
            if self.light in LT.torches:
                LT.torches.remove(self.light)
            hazards.remove(self)
            destroy(self)


# --- бамбуковая роща
class Kamaitachi(BladeDemon):
    """Ласка-серп: мелкая, очень быстрая, режет на рывке"""
    kind, title = 'weasel', 'КАМАИТАТИ'
    hp_base, speed, dmg, radius, height, size = 70, 6.2, 13, .4, 1.7, .72
    TEX, TINT, TEX2, TINT2, souls = 'fur', WHITE, 'fur', C('#9a7a60'), 7


class KarasuTengu(WingedDemon):
    """Вороний тэнгу: кружит и стреляет серпами ветра"""
    kind, title = 'tengu', 'ГЛАЗ ТЭНГУ'
    hp_base, speed, dmg, radius, height, size = 110, 4.6, 16, .5, 2.2, .85
    TEX, TINT, WTEX, WTINT, SHOOT, souls = 'feather', WHITE, 'feather', C('#9090a8', .95), True, 12
    # меньший зелёный глаз на перистых крыльях, стреляет серпами ветра
    IRIS, IRIS_IN, HALO = C('#2affa0'), C('#d0ffe8'), C('#30ffb0', .2)
    WING_COL, WING_SHADE = C('#e6e8f0'), C('#c4c8d6')


# --- пещеры
class FireGaki(Gaki):
    """Огненный гаки: после смерти взрывается — отходи"""
    kind, title = 'firegaki', 'ОГНЕННЫЙ ГАКИ'
    hp_base, speed, dmg = 55, 5.4, 10
    TEX, TINT, souls = 'lava_rock', C('#ffb090'), 6

    def anim(self, dt):
        super().anim(dt)
        if random.random() < .25:
            burst(self.position + Vec3(0, .8 * self.sz, 0), 1, EMBER, 1.2, .08, .4, grav=-3, glow=True)

    def on_death(self, center):
        pos = flat(center)
        decal(pos, 2.8, C('#ff7a10', .8), .6, life=.65)
        dmg = self.dmg * 2

        def boom():
            shockring(pos, 3.5, C('#ff7a10', .9), .35)
            burst(pos + Vec3(0, .5, 0), 20, EMBER, 7, .12, .5, glow=True)
            add_flash(pos + Vec3(0, 1, 0), (1, .5, .1), 7, .3)
            if player is not None and dist2d(player.position, pos) < 2.8 and player.y < 1.5:
                player.hurt(dmg, pos)
            for e in enemies[:]:
                if gone(e):
                    continue
                if dist2d(e.position, pos) < 2.8:
                    e.take(dmg * 2, False, Vec3(0, 0, 0))
            sfx('hit', .7, .6)
        invoke(boom, delay=.6)


class LavaOni(Oni):
    """Лавовый они: после удара остаётся лужа лавы"""
    kind, title = 'lavaoni', 'ЛАВОВЫЙ ОНИ'
    hp_base, dmg = 300, 26
    TEX, TINT, souls = 'obsidian', C('#ffc0a0'), 18

    def on_slam(self, pos, hit):
        hazards.append(LavaPool(pos, 2.4 * (1.5 if self.boss else 1), 4.5, int(self.dmg * .3)))


# --- ледяное святилище
class FrostOni(Oni):
    """Ледяной они: удар замораживает и замедляет"""
    kind, title = 'frostoni', 'ЛЕДЯНОЙ ОНИ'
    hp_base, dmg = 320, 24
    TEX, TINT, souls = 'ice', C('#d0e4ff'), 18

    def on_slam(self, pos, hit):
        shockring(pos, self.slam_r * 1.6, C('#c0e8ff', .9), .5)
        burst(pos + Vec3(0, .3, 0), 18, C('#e0f4ff'), 6, .12, .7, glow=True)
        if dist2d(player.position, pos) < self.slam_r * 1.6 and player.y < 1:
            player.apply_slow(2.4)


class YukiOnna(Onibi):
    """Снежная дева: ледяные шары замедляют"""
    kind, title = 'yuki', 'ЮКИ-ОННА'
    hp_base, dmg = 70, 13
    FLAME1, FLAME2, CORE, SHOT, SLOW, souls = C('#7ac8ff', .55), C('#e8f6ff', .5), C('#ffffff'), C('#9adfff'), 1.8, 9


# --- паучье логово
class Spider(Enemy):
    """Цутигумо: быстрый паук, плюётся паутиной и кусает в прыжке"""
    kind, title = 'spider', 'ДЗЁРОГУМО, ПАУЧЬЯ КНЯГИНЯ'
    hp_base, speed, dmg, radius, height, size = 95, 5.0, 15, .7, 1.1, 1.0
    souls = 10
    WEB = True

    def build(self):
        v = self.vis
        ch = dict(texture='chitin', color=WHITE)
        self.body = Entity(parent=v, y=.6)
        part(self.body, model='skull', position=(0, .15, -.55), rotation_x=-70, scale=(.8, .95, .7), **ch)  # брюшко
        part(self.body, model='skull', position=(0, .05, .1), rotation_x=-80, scale=(.5, .55, .42), **ch)
        part(self.body, model='skull', position=(0, .05, .42), scale=(.3, .26, .3), **ch)
        self.eyes = []
        for i, (x, y) in enumerate(((-.06, .14), (.06, .14), (-.11, .1), (.11, .1), (-.04, .2), (.04, .2))):
            self.eyes.append(part(self.body, unlit=True, model='orb', position=(x, y, .55), scale=.045,
                                  color=C('#ff2a2a')))
        for x in (-.06, .06):
            part(self.body, model='diamond', position=(x, -.06, .6), rotation_x=30, scale=(.03, .14, .03),
                 texture='horn', color=WHITE)
        self.legs = []
        for side in (-1, 1):
            for k in range(4):
                root = Entity(parent=self.body, position=(.18 * side, 0, .3 - k * .2), rotation=(0, side * (50 - k * 30), 0))
                up = Entity(parent=root, rotation_z=-side * 55)
                part(up, model='taper', position=(side * .28, 0, 0), rotation_z=side * 90, scale=(.07, .56, .07), **ch)
                low = Entity(parent=up, x=side * .55, rotation_z=side * 110)
                part(low, model='taper', position=(side * .32, 0, 0), rotation_z=-side * 90, scale=(.05, .66, .05), **ch)
                self.legs.append((root, up, side, k))
        self.web_t = random.uniform(2, 4)

    def think(self, dt):
        dv, d = self.to_player()
        if self.state == 'chase':
            self.face(dv, dt, 10)
            self.web_t -= dt
            if self.WEB and self.web_t <= 0 and 3 < d < 11:
                self.web_t = random.uniform(3, 4.5) * (.6 if self.boss else 1)
                n = 5 if self.boss else 1
                for i in range(n):
                    fireballs.append(Fireball(self.position + Vec3(0, .7 * self.sz, 0) + dv * .6,
                                              dir_of(heading_of(dv) + (i - (n - 1) / 2) * 14), int(self.dmg * .5),
                                              col=C('#f4f0ff'), slow=2.0))
                sfx('fireball', .4, 1.6)
            if d > 2.2 + self.radius:
                self.position += dv * self.speed * dt
            else:
                self.state, self.timer = 'windup', .35
            if self.boss:
                self.special_t -= dt
                if self.special_t <= 0:
                    self.special_t = 7 if not self.enraged else 5
                    self.summon(Spiderling, 3 if not self.enraged else 5)
                    sfx('shriek', .8, .7)
        elif self.state == 'windup':
            self.timer -= dt
            if self.timer <= 0:
                self.state, self.timer = 'lunge', .28
                self.lunge_dir = dv
                self.hit_done = False
        elif self.state == 'lunge':
            self.timer -= dt
            self.position += self.lunge_dir * 14 * dt
            if not self.hit_done and dist2d(self.position, player.position) < self.radius + .8:
                player.hurt(self.dmg, self.position)
                self.hit_done = True
            if self.timer <= 0:
                self.state, self.timer = 'recover', .6
        elif self.state == 'recover':
            self.timer -= dt
            if self.timer <= 0:
                self.state = 'chase'

    def anim(self, dt):
        moving = self.state in ('chase', 'lunge')
        sp = 16 if self.state == 'lunge' else 11
        for root, up, side, k in self.legs:
            ph = self.phase * sp + k * 1.6 + (0 if side > 0 else math.pi)
            up.rotation_z = -side * (55 + (18 * math.sin(ph) if moving else 0))
            root.rotation_y = side * (50 - k * 30) + (10 * math.cos(ph) if moving else 0)
        self.body.y = .6 + (math.sin(self.phase * 22) * .03 if moving else 0)
        self.body.rotation_x = -15 if self.state == 'windup' else (10 if self.state == 'lunge' else 0)


class Spiderling(Spider):
    kind, title = 'spiderling', 'ПАУЧОНОК'
    hp_base, speed, dmg, radius, height, size = 28, 6.4, 7, .35, .6, .5
    souls = 2
    WEB = False


# --- замок и сад
class Nukekubi(Enemy):
    """Летучая голова: кружит и пикирует с укусом"""
    kind, title = 'nukekubi', 'НУКЭКУБИ'
    hp_base, speed, dmg, radius, height, size = 55, 5.2, 13, .45, 1.0, 1.0
    flying = True
    souls = 8

    def build(self):
        v = self.vis
        self.fly_y = random.uniform(1.4, 2.0)
        self.head = Entity(parent=v)
        part(self.head, model='skull', scale=(.42, .5, .44), texture='skin_bone', color=C('#f0e0d8'))
        part(self.head, model='skull', position=(0, .08, -.05), scale=(.47, .45, .48), color=C('#0c0608'))
        self.eyes = [part(self.head, unlit=True, model='orb', position=(x, .02, .2), scale=(.07, .04, .03),
                          color=C('#ff3030')) for x in (-.08, .08)]
        part(self.head, model='rbox', position=(0, -.12, .19), scale=(.16, .05, .04), color=C('#300408'))
        for x in (-.05, 0, .05):
            part(self.head, model='diamond', position=(x, -.1, .21), scale=(.02, .05, .02), color=BONE)
        part(self.head, model='taper', position=(0, -.3, -.02), scale=(.12, .18, .12), color=C('#8a0a14'))
        self.hair = []
        par = Entity(parent=self.head, position=(0, .1, -.2), rotation_x=-110)
        for i in range(6):
            part(par, model='rbox', y=.07, scale=(.3 - i * .035, .15, .04), color=C('#0c0608'))
            self.hair.append(par)
            par = Entity(parent=par, y=.14)
        self.orbit = random.uniform(0, math.tau)
        self.timer = random.uniform(1.5, 3)

    def think(self, dt):
        dv, d = self.to_player()
        if self.state == 'chase':
            self.orbit += dt * 1.1
            tgt = flat(player.position) + Vec3(math.sin(self.orbit), 0, math.cos(self.orbit)) * 4.5
            mv = tgt - flat(self.position)
            if mv.length() > .2:
                self.position += mv.normalized() * min(mv.length(), self.speed * dt)
            self.y = lerp(self.y, self.fly_y + math.sin(self.phase * 3) * .3, min(1, dt * 3))
            self.face(dv, dt, 8)
            self.timer -= dt
            if self.timer <= 0:
                self.state, self.timer = 'windup', .4
                sfx('shriek', .4, 1.4)
        elif self.state == 'windup':
            self.timer -= dt
            self.face(dv, dt, 14)
            self.y = lerp(self.y, self.fly_y + .8, min(1, dt * 6))
            if self.timer <= 0:
                self.state, self.timer = 'dive', .45
                self.dive_to = player.position + Vec3(0, 1.1, 0)
                self.hit_done = False
        elif self.state == 'dive':
            self.timer -= dt
            to = self.dive_to - self.position
            if to.length() > .2:
                self.position += to.normalized() * 15 * dt
            if not self.hit_done and (player.position + Vec3(0, 1.1, 0) - self.position).length() < .9:
                player.hurt(self.dmg, self.position)
                self.hit_done = True
            if self.timer <= 0:
                self.state, self.timer = 'chase', random.uniform(1.8, 3)

    def anim(self, dt):
        for i, h in enumerate(self.hair):
            h.rotation_x = (-110 if i == 0 else 0) + math.sin(self.phase * 8 + i) * 10
        self.head.rotation_z = math.sin(self.phase * 2) * 8


class GhostRonin(Enemy):
    """Призрак-ронин: блокирует удары спереди — заходи сбоку или со спины"""
    kind, title = 'ronin', 'СЁГУН-ПРИЗРАК'
    hp_base, speed, dmg, radius, height, size = 170, 3.6, 22, .5, 2.1, 1.0
    souls = 16

    def build(self):
        v = self.vis
        gh = dict(texture='silk', color=C('#a8e8ff', .75))
        dk = dict(texture='cloth', color=C('#5070a0', .8))
        self.legs = []
        for x in (-.13, .13):
            hip = Entity(parent=v, position=(x, .95, 0))
            part(hip, model='taper', y=-.45, scale=(.2, .9, .22), **dk)
            self.legs.append(hip)
        self.trunk = Entity(parent=v, y=.95)
        part(self.trunk, model='torso', y=.35, scale=(.5, .7, .3), **gh)
        part(self.trunk, model='rbox', y=.02, scale=(.46, .08, .3), color=C('#202840', .9))
        head = Entity(parent=self.trunk, y=.85)
        part(head, model='skull', scale=(.22, .26, .23), **gh)
        part(head, model='diamond', position=(0, .16, 0), scale=(.7, .14, .7), texture='wood', color=C('#d0e0f0', .85))
        self.eyes = [part(head, unlit=True, model='cube', position=(x, .02, .11), scale=(.05, .015, .02),
                          color=C('#60f0ff')) for x in (-.05, .05)]
        self.arms = []
        for side in (-1, 1):
            sh = Entity(parent=self.trunk, position=(.3 * side, .62, 0))
            part(sh, model='taper', y=-.28, scale=(.13, .56, .13), **gh)
            self.arms.append(sh)
        self.sword = Entity(parent=self.arms[1], y=-.55, rotation_x=-90)
        part(self.sword, model='rbox', y=.6, scale=(.03, 1.2, .07), color=C('#e0f8ff'))
        glow_entity(Entity(parent=self.sword, model='cube', y=.6, scale=(.08, 1.25, .12), color=C('#60f0ff', .3)))
        self.guard_fx = 0

    def take(self, dmg, crit, push):
        to_me = flat(player.position - self.position)
        facing = dir_of(self.rotation_y)
        if self.state in ('chase', 'recover') and to_me.length() > .1 and to_me.normalized().dot(facing) > .35:
            dmg = max(1, int(dmg * .25))
            if self.guard_fx <= 0:
                self.guard_fx = .3
                popup_number(self.position + Vec3(0, self.height + .4, 0), 'БЛОК', C('#9adfff'))
                sfx('clang', .5)
                flash_fx(SLASH_IN, self.position + Vec3(0, 1.2 * self.sz, 0), (0, self.rotation_y, 90),
                         C('#c0f4ff', .9), .5, .8, .15)
            push = Vec3(0, 0, 0)
        super().take(dmg, crit, push)

    def think(self, dt):
        dv, d = self.to_player()
        self.guard_fx -= dt
        if self.state == 'chase':
            self.face(dv, dt, 7)
            if d > 3.2:
                self.position += dv * self.speed * dt
            else:
                self.state, self.timer = 'windup', .55 if not self.enraged else .4
                self.dash_dir = dv
                self.dashes = 3 if self.boss else 1
                decal(flat(self.position) + dv * 2.5, 1.6, C('#60f0ff', .5), self.timer)
        elif self.state == 'windup':
            self.timer -= dt
            if self.timer <= 0:
                self.state, self.timer = 'dash', .22
                self.hit_done = False
                sfx('slash', .6, .8)
                flash_fx(SLASH, self.position + Vec3(0, 1.2 * self.sz, 0), (0, self.rotation_y, 10),
                         C('#60f0ff', .8), .8, 1.3 * self.sz, .25)
        elif self.state == 'dash':
            self.timer -= dt
            self.position += self.dash_dir * 22 * dt
            if not self.hit_done and dist2d(self.position, player.position) < self.radius + 1.3:
                player.hurt(self.dmg, self.position)
                self.hit_done = True
            if self.timer <= 0:
                self.dashes -= 1
                if self.dashes > 0:
                    dv, d = self.to_player()
                    self.dash_dir = dv
                    self.face(dv, 1, 50)
                    self.state, self.timer = 'windup', .25
                else:
                    self.state, self.timer = 'recover', .9
                    if self.boss:
                        self.special_t -= 1
                        if self.special_t <= 0:
                            self.special_t = 3
                            self.summon(Nukekubi, 2)
        elif self.state == 'recover':
            self.timer -= dt
            if self.timer <= 0:
                self.state = 'chase'

    def anim(self, dt):
        w = math.sin(self.phase * 7) * 22 if self.state == 'chase' else 0
        self.legs[0].rotation_x, self.legs[1].rotation_x = w, -w
        sw = {'windup': -150, 'dash': 20}.get(self.state, -40)
        self.arms[1].rotation_x = lerp(self.arms[1].rotation_x, sw, min(1, dt * 14))
        self.arms[0].rotation_x = lerp(self.arms[0].rotation_x, sw * .6, min(1, dt * 10))
        self.vis.y = math.sin(self.phase * 2) * .06 + .05



class Fireball(Entity):
    def __init__(self, pos, dirv, dmg, homing=True, col=None, slow=0):
        col = col or C('#ff3b2f')
        super().__init__(model='orb', position=pos, scale=.32,
                         color=Color(col[0] + (1 - col[0]) * .6, col[1] + (1 - col[1]) * .6, col[2] + (1 - col[2]) * .6, 1))
        self.unlit = True
        self.col = col
        self.slow = slow
        self.halo = glow_entity(Entity(parent=self, model='quad', texture='glow', billboard=True, scale=3.5,
                                       color=Color(col[0], col[1], col[2], .7)))
        self.v = Vec3(dirv) * 9
        self.dmg = dmg
        self.life = 4
        self.owner = 'enemy'
        self.age = 0
        self.homing = homing

    def tick(self, dt):
        self.age += dt
        self.life -= dt
        if self.owner == 'enemy' and self.homing and self.age < .8:
            to = (player.position + Vec3(0, 1.2, 0)) - self.position
            self.v = lerp(self.v, to.normalized() * 9, min(1, dt * 1.2))
        self.position += self.v * dt
        if random.random() < .6:
            burst(self.position, 1, self.col, .5, .1, .3, grav=-1, glow=True)
        hit = False
        if self.owner == 'enemy':
            if (player.position + Vec3(0, 1.1, 0) - self.position).length() < .9:
                player.hurt(self.dmg, self.position)
                if self.slow:
                    player.apply_slow(self.slow)
                hit = True
        else:
            for e in enemies:
                if (e.position + Vec3(0, e.height * .5, 0) - self.position).length() < e.radius + .8:
                    e.take(self.dmg * 3, True, self.v.normalized() * 4)
                    hit = True
                    break
        if hit or self.life <= 0 or not dungeon.inside(self.position, .2):
            self.explode()

    def explode(self):
        burst(self.position, 14, self.col, 6, .1, .5, glow=True)
        add_flash(self.position, (1, .4, .1), 5, .25)
        if self in fireballs:
            fireballs.remove(self)
        destroy(self)


class SkyFire(Fireball):
    """Огненный дождь: падает сверху в отмеченную точку"""
    def __init__(self, target, dmg):
        super().__init__(Vec3(target[0], 14, target[2]), Vec3(0, -1, 0), dmg)
        self.target = target
        self.v = Vec3(0, -22, 0)
        self.scale = .5

    def tick(self, dt):
        self.position += self.v * dt
        if random.random() < .8:
            burst(self.position, 1, EMBER, .5, .12, .3, grav=-2, glow=True)
        if self.y <= .3:
            if dist2d(player.position, self.target) < 2.2 and player.y < 1.5:
                player.hurt(self.dmg, self.target)
            shockring(self.target, 3.5)
            game.shake = max(game.shake, .2)
            self.explode()


def reflect_fireballs(pos, fwd, reach, cone):
    for f in fireballs:
        if f.owner != 'enemy' or isinstance(f, SkyFire):
            continue
        v = flat(f.position) - flat(pos)
        if v.length() < reach and (cone < -0.9 or v.length() < .5 or v.normalized().dot(fwd) > cone):
            f.owner = 'player'
            f.v = fwd * 18
            f.color = C('#fff0e0')
            f.halo.color = C('#ffffff', .6)
            sfx('clang', .6)
            popup_number(f.position + Vec3(0, .5, 0), 'ОТРАЖЕНО', GOLD)


class Orb(Entity):
    def __init__(self, pos):
        super().__init__(model='quad', texture='glow', billboard=True, position=pos, scale=.6, color=C('#ff4a3d'))
        self.unlit = True
        self.v = Vec3(random.uniform(-1, 1), random.uniform(.6, 1.4), random.uniform(-1, 1)) * 4
        self.age = 0

    def tick(self, dt):
        self.age += dt
        target = player.position + Vec3(0, 1.2, 0)
        if self.age > .35:
            to = target - self.position
            self.v = lerp(self.v, to.normalized() * (10 + self.age * 14), min(1, dt * 6))
        else:
            self.v += Vec3(0, -9 * dt, 0)
        self.position += self.v * dt
        if (target - self.position).length() < .6:
            player.energy = min(100, player.energy + 1.2)
            sfx('orb', .35, random.uniform(.95, 1.15))
            orbs.remove(self)
            destroy(self)


class SpiritWave(Entity):
    def __init__(self, pos, heading):
        super().__init__(model=WAVE_MESH(), position=pos, rotation=(0, heading, 90), scale=1.5,
                         color=C('#ff3b2f', .9), double_sided=True)
        self.unlit = True
        self.inner = glow_entity(Entity(parent=self, model=SLASH_IN(), scale=.9, color=C('#fff2ec', .9),
                                        double_sided=True))
        self.dir = dir_of(heading)
        self.life = 1.0
        self.hit = set()

    def tick(self, dt):
        self.position += self.dir * 24 * dt
        self.life -= dt
        self.scale = 1.5 + (1 - self.life) * .9
        if random.random() < .9:
            burst(self.position + Vec3(random.uniform(-.3, .3), random.uniform(-.8, .8), 0), 1, EMBER, 1.5, .1, .35,
                  grav=0, glow=True)
        for d in enemies[:]:
            if gone(d):
                continue
            if id(d) in self.hit:
                continue
            if dist2d(d.position, self.position) < 1.8 + d.radius and abs(d.y - self.y) < 4:
                self.hit.add(id(d))
                crit = random.random() < .25
                d.take(int(60 * (2 if crit else 1) * random.uniform(.9, 1.1)), crit, self.dir * 4)
        reflect_fireballs(self.position, self.dir, 1.8, -1)
        if self.life <= 0 or not dungeon.inside(self.position, 0):
            waves.remove(self)
            destroy(self)



class WindBlade(Entity):
    """Серп ветра — быстрый и короткий"""
    def __init__(self, pos, heading):
        super().__init__(model=WAVE_MESH(), position=pos, rotation=(0, heading, 90), scale=.9, color=WIND,
                         double_sided=True)
        self.unlit = True
        glow_entity(Entity(parent=self, model=SLASH_IN(), scale=.9, color=WIND2, double_sided=True))
        self.dir = dir_of(heading)
        self.life = .6
        self.hit = set()

    def tick(self, dt):
        self.position += self.dir * 30 * dt
        self.life -= dt
        if random.random() < .7:
            burst(self.position, 1, WIND2, 1, .08, .3, grav=0, glow=True)
        for d in enemies[:]:
            if gone(d):
                continue
            if id(d) in self.hit:
                continue
            if dist2d(d.position, self.position) < 1.3 + d.radius and abs(d.y - self.y) < 3.5:
                self.hit.add(id(d))
                d.take(int(26 * random.uniform(.9, 1.1)), False, self.dir * 5)
        reflect_fireballs(self.position, self.dir, 1.3, -1)
        if self.life <= 0 or not dungeon.inside(self.position, 0):
            waves.remove(self)
            destroy(self)


class RazorFeather(Entity):
    """Перо-лезвие из веерного шквала: летит далеко, пробивает насквозь, достаёт летающих"""
    SPEED = 34
    def __init__(self, pos, heading, delay=0):
        super().__init__(position=pos, rotation=(0, heading, 0))
        self.vis = Entity(parent=self)
        glow_entity(Entity(parent=self.vis, model='diamond', scale=(.12, .05, .9), color=WIND2))
        glow_entity(Entity(parent=self.vis, model='diamond', scale=(.3, .08, .6), z=-.15, color=WIND))
        glow_entity(Entity(parent=self.vis, model='quad', texture='glow', billboard=True, scale=.9,
                           color=Color(.4, 1, .85, .45)))
        self.dir = dir_of(heading)
        self.t = -delay
        self.life = .72
        self.hit = set()
        self.vis.enabled = delay <= 0

    def tick(self, dt):
        self.t += dt
        if self.t < 0:
            return
        self.vis.enabled = True
        # чуть доворачивает на ближайшего демона впереди
        best, bd = None, 6.0
        for d in enemies:
            if id(d) in self.hit:
                continue
            v = flat(d.position) - flat(self.position)
            L = v.length()
            if L < bd and L > .1 and v.normalized().dot(self.dir) > .7:
                best, bd = d, L
        if best is not None:
            v = (flat(best.position) - flat(self.position)).normalized()
            self.dir = (self.dir + v * dt * 4).normalized()
            self.rotation_y = heading_of(self.dir)
            want_y = best.y + best.height * .45
            self.y += (want_y - self.y) * min(1, dt * 6)
        self.position += self.dir * self.SPEED * dt
        self.vis.rotation_z += dt * 900
        self.life -= dt
        if random.random() < .5:
            burst(self.position, 1, WIND2, .6, .06, .25, grav=0, glow=True)
        for d in enemies[:]:
            if gone(d):
                continue
            if id(d) in self.hit:
                continue
            if dist2d(d.position, self.position) < .9 + d.radius and -1.0 < self.y - d.y < d.height + 1.5:
                self.hit.add(id(d))
                dmg = int(22 * player.DMG * random.uniform(.9, 1.1)) if player is not None else 22
                d.take(dmg, random.random() < .15, self.dir * 3)
        reflect_fireballs(self.position, self.dir, .9, -1)
        if self.life <= 0 or not dungeon.inside(self.position, 0):
            waves.remove(self)
            destroy(self)


class FanBoomerang(Entity):
    """Брошенный веер: летит вперёд и возвращается в руку"""
    def __init__(self, owner, heading, delay=0):
        super().__init__(position=owner.position + Vec3(0, 1.2, 0), rotation_y=heading)
        self.spin = Entity(parent=self, rotation_x=90)
        part(self.spin, model=fan_mesh(.6, -100, 100), texture='paper', color=WHITE, double_sided=True, unlit=True)
        glow_entity(Entity(parent=self.spin, model='quad', texture='glow', scale=1.6, color=Color(.4, 1, .85, .5)))
        self.owner = owner
        self.dir = dir_of(heading)
        self.t = -delay
        self.returning = False
        self.hit = set()

    def tick(self, dt):
        self.t += dt
        if self.t < 0:
            return
        self.spin.rotation_y += dt * 1500
        if not self.returning:
            self.position += self.dir * 22 * dt
            if self.t > .42 or not dungeon.inside(self.position, .4):
                self.returning = True
                self.hit = set()
        else:
            to = (self.owner.position + Vec3(0, 1.2, 0)) - self.position
            if to.length() < .8 or self.t > 2.5:
                waves.remove(self)
                destroy(self)
                return
            self.position += to.normalized() * 26 * dt
        if random.random() < .6:
            burst(self.position, 1, WIND2, .5, .07, .3, grav=0, glow=True)
        for d in enemies[:]:
            if gone(d):
                continue
            if id(d) in self.hit:
                continue
            if dist2d(d.position, self.position) < 1.2 + d.radius and abs(d.y + d.height * .5 - self.y) < 2.5:
                self.hit.add(id(d))
                d.take(int(24 * random.uniform(.9, 1.1)), random.random() < .25, self.dir * 3)
        reflect_fireballs(self.position, self.dir, 1.2, -1)


class Cyclone(Entity):
    """Смерч: затягивает демонов и режет их ветром"""
    def __init__(self, pos, life=3.5, radius=4.5, dmg=11, big=False):
        super().__init__(position=Vec3(pos[0], 0, pos[2]))
        self.radius, self.dmg, self.life, self.max_life = radius, dmg, life, life
        self.tick_t = 0
        self.rings = []
        n = 7 if big else 5
        for i in range(n):
            k = i / (n - 1)
            r = glow_entity(Entity(parent=self, model=RING(), y=.3 + k * (5 if big else 3.6),
                                   scale=(radius * (.35 + k * .55)), color=WIND if i % 2 else WIND2, double_sided=True))
            self.rings.append(r)
        self.core = glow_entity(Entity(parent=self, model='quad', texture='glow', billboard=True, y=1.8,
                                       scale=(radius * .9, 5), color=Color(.4, 1, .85, .25)))
        self.base = decal(pos, radius, Color(.3, 1, .8, .35), grow=False, life=life + .1)
        self.scale = .1
        self.animate_scale(1, duration=.25, curve=curve.out_back)

    def tick(self, dt):
        self.life -= dt
        for i, r in enumerate(self.rings):
            r.rotation_y += dt * (500 + i * 120) * (1 if i % 2 else -1)
            r.x = math.sin(game.clock * 6 + i) * .25
        if random.random() < .9:
            a = random.uniform(0, math.tau)
            burst(self.position + Vec3(math.sin(a) * self.radius * .7, random.uniform(.2, 3), math.cos(a) * self.radius * .7),
                  1, WIND2, 3, .09, .5, grav=-3, glow=True)
        for d in enemies:
            v = flat(self.position) - flat(d.position)
            dd = v.length()
            if dd < self.radius * 1.35 and dd > .3:
                pull = (5.5 if not (d.boss or d.armor) else 1.6) * dt
                d.position += v.normalized() * min(pull, dd)
        for f in fireballs[:]:
            if f.owner == 'enemy' and dist2d(f.position, self.position) < self.radius:
                f.explode()
        self.tick_t -= dt
        if self.tick_t <= 0:
            self.tick_t = .25
            for d in enemies[:]:
                if gone(d):
                    continue
                if dist2d(d.position, self.position) < self.radius + d.radius:
                    d.take(int(self.dmg * random.uniform(.9, 1.1)), False, Vec3(0, 0, 0))
        if self.life <= 0:
            waves.remove(self)
            self.animate_scale(.01, duration=.2)
            destroy(self, delay=.25)

# =====================================================================
# ПОДЗЕМЕЛЬЯ: уровни, комнаты, ворота
# =====================================================================
LEVELS = [
    dict(name='ЗАБЫТОЕ СВЯТИЛИЩЕ', floor='floor_stone', wall='wall_brick', ftint=C('#c8b4b4'), wtint=C('#b8a0a0'),
         torch=(1.0, .42, .22), fog=Vec3(.06, .015, .03), amb=Vec3(.09, .04, .05), ambient='embers', elite=0,
         pool=[Gaki, Gaki, Gaki, Oni, Onibi], boss=[(Oni, 'ГОРО, ПРИВРАТНИК ПЕЧАТИ')], deco='temple',
         foes='гаки, они'),
    dict(name='КОРНЕВАЯ РОЩА', floor='moss', wall='bamboo', ftint=C('#b0b8a0'), wtint=C('#a0b090'),
         torch=(1.0, .55, .25), fog=Vec3(.02, .035, .03), amb=Vec3(.05, .07, .06), ambient='fireflies', elite=.05,
         pool=[Kamaitachi, Kamaitachi, KarasuTengu, Gaki], boss=[(BladeDemon, 'КАМАИТАТИ, ЖНЕЦ КОРНЕЙ')], deco='bamboo',
         foes='камаитати, карасу-тэнгу'),
    dict(name='МЁРТВАЯ ДЕРЕВНЯ', floor='floor_stone', wall='wood', ftint=C('#a09898'), wtint=C('#8a7070'),
         torch=(1.0, .6, .3), fog=Vec3(.04, .03, .03), amb=Vec3(.07, .05, .05), ambient='embers', elite=.08,
         pool=[Nukekubi, Nukekubi, GhostRonin, Gaki], boss=[(GhostRonin, 'СТАРОСТА МИДЗУНО')], deco='village',
         foes='нукэкуби, призраки жителей'),
    dict(name='ПЕЩЕРЫ ЁМИ', floor='lava_rock', wall='lava_rock', ftint=C('#c0a0a0'), wtint=C('#806868'),
         torch=(1.0, .25, .12), fog=Vec3(.08, .01, .015), amb=Vec3(.12, .03, .03), ambient='embers', elite=.1,
         pool=[FireGaki, FireGaki, LavaOni, Onibi], boss=[(Onibi, 'ХИ-НО-КАМИ, ПЛАМЯ РИТУАЛА')], deco='cave',
         foes='огненные гаки, лавовые они'),
    dict(name='ЛЕДЯНОЙ СКЛЕП', floor='snow', wall='ice', ftint=C('#a8b0c0'), wtint=C('#a0b0c8'),
         torch=(.45, .75, 1.0), fog=Vec3(.03, .04, .07), amb=Vec3(.08, .09, .13), ambient='snow', elite=.14,
         pool=[YukiOnna, YukiOnna, FrostOni, Kamaitachi], boss=[(WingedDemon, 'ХРАНИТЕЛЬ СКЛЕПА')], deco='ice',
         foes='юки-онна, ледяные они'),
    dict(name='ПАУЧЬЕ ЛОГОВО', floor='moss', wall='wall_brick', ftint=C('#9080a0'), wtint=C('#706080'),
         torch=(.5, 1.0, .45), fog=Vec3(.04, .02, .05), amb=Vec3(.07, .05, .09), ambient='spores', elite=.16,
         pool=[Spider, Spider, Spiderling, Spiderling, Nukekubi], boss=[(Spider, 'ДЗЁРОГУМО, ПРЯДИЛЬЩИЦА')], deco='lair',
         foes='цутигумо, паучата'),
    dict(name='САД РИТУАЛА', floor='moss', wall='wall_brick', ftint=C('#b08080'), wtint=C('#a07070'),
         torch=(1.0, .35, .3), fog=Vec3(.07, .015, .02), amb=Vec3(.1, .04, .04), ambient='petals', elite=.22,
         pool=[GhostRonin, FrostOni, LavaOni, Nukekubi, KarasuTengu, Spider],
         boss=[(Oni, 'ЖРЕЦ ПЛОТИ'), (BladeDemon, 'ЖРЕЦ КЛИНКА')], deco='garden', foes='жрецы и их паства'),
    dict(name='СЕРДЦЕ БЕЗДНЫ', floor='obsidian', wall='obsidian', ftint=C('#a090a0'), wtint=C('#807080'),
         torch=(1.0, .3, .5), fog=Vec3(.06, .01, .04), amb=Vec3(.1, .03, .07), ambient='petals', elite=.3,
         pool=[GhostRonin, WingedDemon, LavaOni, FrostOni, Spider, BladeDemon],
         boss=[(DemonLord, 'ПЕРВЫЙ ЖРЕЦ, ПОБЕДИВШИЙ СМЕРТЬ')], deco='moongate', foes='всё, во что превратились люди'),
]
ROOMS_PER_LEVEL = 4   # 3 зала + логово владыки


class Dungeon:
    def __init__(self):
        self.root = None
        self.puzzle = None
        self.tablets = []
        self.lanterns = []
        self.level = 0
        self.room = 0
        self.w = 30
        self.d = 36
        self.pillars = []
        self.waves = []
        self.wave_i = 0
        self.pending = 0
        self.cleared = False
        self.gate = None
        self.transit = False
        self.boss_room = False

    # ---------- коллизии
    def inside(self, p, r):
        return abs(p[0]) < self.w / 2 - r and abs(p[2]) < self.d / 2 - r

    def collide(self, ent, r):
        hw, hd = self.w / 2 - r - .5, self.d / 2 - r - .5
        x, z = ent.x, ent.z
        exit_ok = self.cleared and abs(x) < 1.8 and ent is player
        x = max(-hw, min(hw, x))
        if not exit_ok:
            z = max(-hd, min(hd, z))
        else:
            z = max(-hd, z)
        for (px, pz, pr) in self.pillars:
            dx, dz = x - px, z - pz
            dd = math.hypot(dx, dz)
            if dd < pr + r and dd > .001:
                x = px + dx / dd * (pr + r)
                z = pz + dz / dd * (pr + r)
        ent.x, ent.z = x, z

    # ---------- построение
    def build(self, level, room):
        if self.root:
            destroy(self.root)
        for e in enemies[:]:
            if gone(e):
                continue
            destroy(e)
        enemies.clear()
        for lst in (fireballs, orbs, waves, hazards):
            for e in lst[:]:
                destroy(e)
            lst.clear()
        LT.torches = []
        self.level, self.room = level, room
        self.boss_room = room == ROOMS_PER_LEVEL - 1
        L = LEVELS[level]
        LT.fog, LT.amb = L['fog'], L['amb']
        window.color = Color(L['fog'][0] * .8, L['fog'][1] * .8, L['fog'][2] * .8, 1)
        rnd = random.Random(level * 100 + room * 7 + game.seed)
        self.w = 40 if self.boss_room else rnd.choice((26, 30, 34))
        self.d = 44 if self.boss_room else rnd.choice((32, 36, 40))
        w, d, H = self.w, self.d, 6.5
        self.root = Entity()
        R = self.root
        part(R, model='plane', scale=(w, 1, d), texture=L['floor'], texture_scale=(w / 4, d / 4), color=L['ftint'])
        # стены: в торцах проёмы для ворот
        def wall(x, z, sx, sz):
            part(R, model='cube', position=(x, H / 2, z), scale=(sx, H, sz), texture=L['wall'],
                 texture_scale=(max(sx, sz) / 4, H / 4), color=L['wtint'])
            part(R, model='cube', position=(x, H + .2, z), scale=(sx + .3, .4, sz + .3), texture='wood',
                 color=C('#504040'))
            part(R, model='cube', position=(x, .25, z), scale=(sx + .1, .5, sz + .1), texture='wood', color=C('#403030'))
        wall(-w / 2 - .5, 0, 1, d + 2)
        wall(w / 2 + .5, 0, 1, d + 2)
        for zs in (-1, 1):
            seg = (w - 4) / 2
            wall(-(2 + seg / 2), zs * (d / 2 + .5), seg, 1)
            wall(2 + seg / 2, zs * (d / 2 + .5), seg, 1)
        # входные ворота — завалены
        part(R, model='cube', position=(0, 1.6, -d / 2 - .6), scale=(4, 3.2, .4), texture='wood', color=C('#3a2020'))
        self.make_torii(R, Vec3(0, 0, -d / 2 - .2), 1.0, closed=True)
        # выход
        self.gate = self.make_torii(R, Vec3(0, 0, d / 2 + .2), 1.0)
        self.barrier = glow_entity(Entity(parent=R, model='cube', position=(0, 1.8, d / 2 + .5), scale=(4, 3.6, .2),
                                          color=C('#ff1a2a', .45)))
        self.cleared = False
        # колонны
        self.pillars = []
        self.lanterns = []
        self.tablets = []
        n_p = 0 if self.boss_room else rnd.randint(2, 6)
        tries = 0
        while len(self.pillars) < n_p and tries < 60:
            tries += 1
            px = rnd.uniform(-w / 2 + 4, w / 2 - 4)
            pz = rnd.uniform(-d / 2 + 6, d / 2 - 6)
            if abs(px) < 3.5 or math.hypot(px, pz) < 6:
                continue
            if any(math.hypot(px - a, pz - b) < 5 for a, b, _ in self.pillars):
                continue
            if room == ROOMS_PER_LEVEL - 2 and pz > d / 2 - 14 and abs(px) < 9:
                continue      # место для загадки перед вратами к стражу
            self.pillars.append((px, pz, .85))
            self.make_pillar(R, px, pz, L)
        self.puzzle = None
        if room == ROOMS_PER_LEVEL - 2 and not self.boss_room:
            self.puzzle = make_puzzle(level, R, d, rnd)
            self.pillars += self.puzzle.blockers()
        if self.boss_room:
            for px, pz in ((-12, -10), (12, -10), (-12, 10), (12, 10)):
                self.pillars.append((px, pz, 1.1))
                self.make_pillar(R, px, pz, L, big=True)
        # факелы по стенам
        for zs in range(int(-d / 2 + 4), int(d / 2 - 2), 7):
            for side in (-1, 1):
                self.make_torch(R, Vec3(side * (w / 2 - .15), 2.8, zs), L['torch'], side)
        for side in (-1, 1):
            self.make_brazier(R, Vec3(side * 3.2, 0, d / 2 - 1.5), L['torch'])
            self.make_brazier(R, Vec3(side * 3.2, 0, -d / 2 + 1.5), L['torch'])
        getattr(self, 'deco_' + L['deco'])(R, rnd)
        game.ambient_mode = L['ambient']
        if not self.boss_room and room in (0, 1):
            side = rnd.choice((-1, 1))
            spot = (side * (w / 2 - 1.6), rnd.uniform(-d / 4, d / 6)) if room == 0 else self.free_spot(rnd)
            add_tablets(R, level, room, spot)
        # свод: всё действие под землёй
        part(R, model='plane', position=(0, H + .6, 0), rotation_x=180, scale=(w + 2, 1, d + 2), texture=L['wall'],
             texture_scale=(w / 5, d / 5), color=Color(L['wtint'][0] * .5, L['wtint'][1] * .5, L['wtint'][2] * .5, 1))
        for k in range(int(w * d / 40)):
            x, z = rnd.uniform(-w / 2, w / 2), rnd.uniform(-d / 2, d / 2)
            h = rnd.uniform(.4, 1.6)
            part(R, model='diamond', position=(x, H + .6 - h / 2, z), scale=(rnd.uniform(.15, .4), h, rnd.uniform(.15, .4)),
                 texture=L['wall'], color=Color(L['wtint'][0] * .6, L['wtint'][1] * .6, L['wtint'][2] * .6, 1))
        for zz in range(int(-d / 2) + 3, int(d / 2), 6):
            part(R, model='rbox', position=(0, H + .3, zz), scale=(w, .35, .4), texture='wood', color=C('#3a2626'))
        # неподвижное склеиваем; фонари, факелы, барьер и скрижали остаются живыми
        for l in self.lanterns:
            l[0].world_parent = R
        keep = [self.barrier] + [l[0] for l in self.lanterns] + list(self.tablets)
        if self.puzzle is not None:
            keep.append(self.puzzle.root)
        for f in game.flames:
            keep += list(f[:3])
        bake_static(R, keep)
        for t in self.tablets:
            bake_rig(t)
        if self.puzzle is not None:
            bake_rig(self.puzzle.root)
        # волны врагов
        self.plan_waves(L, rnd)
        self.wave_i = 0
        self.pending = 0
        self.wave_t = 1.5
        if self.boss_room:
            play_track('boss')
        else:
            play_track('bgm')
        LIT_ENTS[:] = [e for e in LIT_ENTS if not e.is_empty()]

    def make_torii(self, R, pos, s, closed=False):
        root = Entity(parent=R, position=pos, scale=s)
        red = C('#9e1018')
        for sx in (-2.3, 2.3):
            part(root, model='cube', position=(sx, 2.4, 0), scale=(.4, 4.8, .4), texture='lacquer', color=red)
            part(root, model='cube', position=(sx, .2, 0), scale=(.6, .4, .6), texture='metal', color=WHITE)
        part(root, model='cube', position=(0, 3.9, 0), scale=(5.4, .26, .3), texture='lacquer', color=red)
        part(root, model='cube', position=(0, 5.0, 0), scale=(6.6, .34, .5), texture='wood', color=C('#2a1414'))
        part(root, model='cube', position=(0, 4.7, 0), scale=(5.9, .28, .38), texture='lacquer', color=red)
        part(root, model='cube', position=(0, 4.35, .2), scale=(.9, .55, .06), color=INK)
        return root

    def make_pillar(self, R, x, z, L, big=False):
        s = 1.35 if big else 1.0
        part(R, model='cube', position=(x, 3.2, z), scale=(1.1 * s, 6.4, 1.1 * s), texture=L['wall'],
             texture_scale=(1, 6.4 / 3), color=L['wtint'])
        part(R, model='cube', position=(x, .3, z), scale=(1.6 * s, .6, 1.6 * s), texture='metal', color=C('#906060'))
        part(R, model='cube', position=(x, 6.3, z), scale=(1.6 * s, .5, 1.6 * s), texture='wood', color=C('#503030'))
        part(R, model='cube', position=(x, 3.0, z), scale=(1.15 * s, .18, 1.15 * s), color=BLOOD)

    def make_torch(self, R, pos, col, side):
        part(R, model='cube', position=pos + Vec3(-side * .2, -.35, 0), rotation_z=side * 30, scale=(.08, .6, .08),
             texture='metal', color=WHITE)
        part(R, model='cube', position=pos + Vec3(-side * .35, 0, 0), scale=(.22, .16, .22), texture='metal',
             color=WHITE)
        fp = pos + Vec3(-side * .35, .3, 0)
        f1 = glow_entity(Entity(parent=R, model='quad', texture='glow', billboard=True, position=fp, scale=1.0,
                                color=Color(col[0], col[1] * .8, col[2], .9)))
        f2 = glow_entity(Entity(parent=R, model='quad', texture='glow', billboard=True, position=fp + Vec3(0, .05, 0),
                                scale=.4, color=C('#fff0c0', .95)))
        halo = glow_entity(Entity(parent=R, model='quad', texture='glow', billboard=True, position=fp, scale=3.2,
                                  color=Color(col[0], col[1] * .5, col[2] * .5, .18)))
        game.flames.append((f1, f2, halo, random.uniform(0, 9)))
        LT.torches.append([fp + Vec3(-side * .6, 0, 0), (col[0] * 2.2, col[1] * 2.2, col[2] * 2.2), 11, random.uniform(0, 9)])

    def make_brazier(self, R, pos, col):
        part(R, model='cube', position=pos + Vec3(0, .45, 0), scale=(.25, .9, .25), texture='metal', color=WHITE)
        part(R, model='cube', position=pos + Vec3(0, .95, 0), scale=(.8, .2, .8), texture='metal', color=WHITE)
        fp = pos + Vec3(0, 1.35, 0)
        f1 = glow_entity(Entity(parent=R, model='quad', texture='glow', billboard=True, position=fp, scale=1.6,
                                color=Color(col[0], col[1] * .8, col[2], .9)))
        f2 = glow_entity(Entity(parent=R, model='quad', texture='glow', billboard=True, position=fp, scale=.6,
                                color=C('#fff0c0', .9)))
        halo = glow_entity(Entity(parent=R, model='quad', texture='glow', billboard=True, position=fp, scale=4.5,
                                  color=Color(col[0], col[1] * .5, col[2] * .5, .16)))
        game.flames.append((f1, f2, halo, random.uniform(0, 9)))
        LT.torches.append([fp, (col[0] * 2.6, col[1] * 2.6, col[2] * 2.6), 12, random.uniform(0, 9)])

    # ---------- декор по темам
    def deco_temple(self, R, rnd):
        self.remnants(R, rnd, 4)
        for i in range(10):
            x, z = self.free_spot(rnd)
            for k in range(rnd.randint(3, 7)):
                px, pz = x + rnd.uniform(-1.2, 1.2), z + rnd.uniform(-1.2, 1.2)
                h = rnd.uniform(.3, .55)
                part(R, model='cube', position=(px, h / 2, pz), scale=(.03, h, .03), color=C('#2a4a1a'))
                for j in range(5):
                    glow_entity(Entity(parent=R, model='diamond', position=(px, h + .05, pz), scale=(.04, .04, .2),
                                       rotation=(-35, j * 72, 0), color=BLOOD))
        for i in range(4):
            x, z = self.free_spot(rnd)
            part(R, model='cube', position=(x, .4, z), rotation_y=rnd.uniform(0, 90),
                 scale=(rnd.uniform(.8, 1.6), .8, rnd.uniform(.6, 1.2)), texture=LEVELS[0]['wall'], color=C('#a09090'))
        for zs in (-1, 1):  # статуи-стражи у ворот
            for side in (-1, 1):
                x, z = side * 4.2, zs * (self.d / 2 - 2.5)
                part(R, model='cube', position=(x, .5, z), scale=(1.1, 1, 1.1), texture='floor_stone', color=WHITE)
                part(R, model='cube', position=(x, 1.4, z), scale=(.7, .9, .9), texture='floor_stone', color=WHITE)
                part(R, model='orb', position=(x, 2.1, z + zs * -.15), scale=(.7, .6, .7), texture='floor_stone',
                     color=WHITE)
                self.pillars.append((x, z, .8))

    def deco_cave(self, R, rnd):
        for i in range(16):
            x, z = self.free_spot(rnd)
            h = rnd.uniform(.8, 2.6)
            part(R, model='diamond', position=(x, h / 2 - .2, z), scale=(rnd.uniform(.4, .9), h, rnd.uniform(.4, .9)),
                 rotation_y=rnd.uniform(0, 90), texture='lava_rock', color=C('#806060'))
            if h > 1.8:
                self.pillars.append((x, z, .45))
        for i in range(5):
            x, z = self.free_spot(rnd)
            pool = glow_entity(Entity(parent=R, model='circle', rotation_x=90, position=(x, .03, z),
                                      scale=rnd.uniform(1.5, 3), color=C('#ff3010', .85), double_sided=True))
            LT.torches.append([Vec3(x, .8, z), (1.2, .2, .05), 6, rnd.uniform(0, 9)])
        for i in range(8):
            x, z = self.free_spot(rnd)
            for k in range(4):
                part(R, model='cube', position=(x + rnd.uniform(-.4, .4), .06, z + rnd.uniform(-.4, .4)),
                     rotation_y=rnd.uniform(0, 180), scale=(.06, .06, .45), texture='skin_bone', color=WHITE)
            part(R, model='orb', position=(x, .12, z), scale=(.2, .18, .22), texture='skin_bone', color=WHITE)

    def deco_castle(self, R, rnd):
        for zs in range(int(-self.d / 2 + 5), int(self.d / 2 - 3), 9):
            for side in (-1, 1):
                b = part(R, model='cube', position=(side * (self.w / 2 - .12), 3.4, zs + 3.5), scale=(.05, 3.6, 1.3),
                         texture='cloth', color=C('#ff3030'))
                glow_entity(Entity(parent=R, model='circle', position=(side * (self.w / 2 - .18), 4.2, zs + 3.5),
                                   rotation_y=90 * side, scale=.6, color=C('#100204'), double_sided=True))
        for i in range(6):
            x, z = self.free_spot(rnd)
            part(R, model='cube', position=(x, .03, z), scale=(2, .04, 1), texture='shoji', color=C('#806060'))
        for i in range(4):
            x, z = self.free_spot(rnd)
            # стойка с доспехом
            part(R, model='cube', position=(x, .8, z), scale=(.1, 1.6, .1), texture='wood', color=WHITE)
            part(R, model='cube', position=(x, 1.5, z), scale=(.6, .6, .35), texture='lacquer', color=C('#808080'))
            part(R, model='orb', position=(x, 2.0, z), scale=(.35, .28, .38), texture='metal', color=WHITE)
            self.pillars.append((x, z, .5))
        for i in range(6):
            x, z = self.free_spot(rnd)
            lan = glow_entity(Entity(parent=R, model='orb', position=(x, 5.2, z), scale=(.6, .8, .6),
                                     color=C('#ff4030', .9)))
            part(R, model='cube', position=(x, 6.0, z), scale=(.02, 1.2, .02), color=INK)

    def deco_bamboo(self, R, rnd):
        for i in range(14):
            x, z = self.free_spot(rnd)
            for k in range(rnd.randint(3, 6)):
                px, pz = x + rnd.uniform(-.9, .9), z + rnd.uniform(-.9, .9)
                h = rnd.uniform(5, 9)
                st = part(R, model='cube', position=(px, h / 2, pz), scale=(.16, h, .16), texture='bamboo',
                          texture_scale=(.3, h / 3), color=WHITE, rotation=(rnd.uniform(-4, 4), 0, rnd.uniform(-4, 4)))
                for j in range(3):
                    part(R, model='diamond', position=(px + rnd.uniform(-.4, .4), h - j * .6, pz + rnd.uniform(-.4, .4)),
                         rotation=(rnd.uniform(-40, 40), rnd.uniform(0, 180), 70), scale=(.12, .7, .05),
                         color=C('#3a6a2a'))
            self.pillars.append((x, z, .9))
        for i in range(3):
            x, z = self.free_spot(rnd)
            part(R, model='cube', position=(x, .5, z), scale=(.5, 1, .5), texture='floor_stone', color=WHITE)
            part(R, model='cube', position=(x, 1.15, z), scale=(.75, .3, .75), texture='floor_stone', color=WHITE)
            glow_entity(Entity(parent=R, model='cube', position=(x, 1.15, z), scale=(.5, .22, .78), color=C('#ffb060')))
            LT.torches.append([Vec3(x, 1.3, z), (1.4, .8, .3), 7, rnd.uniform(0, 9)])
            self.pillars.append((x, z, .5))

    def deco_ice(self, R, rnd):
        for i in range(12):
            x, z = self.free_spot(rnd)
            for k in range(rnd.randint(2, 4)):
                h = rnd.uniform(1, 3.2)
                e = glow_entity(Entity(parent=R, model='diamond', position=(x + rnd.uniform(-.6, .6), h / 2 - .3,
                                                                            z + rnd.uniform(-.6, .6)),
                                       scale=(rnd.uniform(.3, .6), h, rnd.uniform(.3, .6)),
                                       rotation=(rnd.uniform(-15, 15), rnd.uniform(0, 90), rnd.uniform(-15, 15)),
                                       color=C('#a8dcff', .75)))
            self.pillars.append((x, z, .6))
        for i in range(10):
            x, z = self.free_spot(rnd)
            part(R, model='orb', position=(x, 0, z), scale=(rnd.uniform(1, 2.5), .5, rnd.uniform(1, 2.5)),
                 texture='snow', color=WHITE)
        for i in range(3):
            x, z = self.free_spot(rnd)
            part(R, model='cube', position=(x, .9, z), scale=(.6, 1.8, .5), texture='ice', color=C('#c0d8ff'))
            part(R, model='orb', position=(x, 2.0, z), scale=.5, texture='ice', color=C('#c0d8ff'))
            self.pillars.append((x, z, .5))

    def deco_moongate(self, R, rnd):
        cz = self.d / 2 - 3
        ring = Entity(parent=R, position=(0, 6, cz + 1.5))
        for k in range(28):
            a = k / 28 * 360
            r = math.radians(a)
            part(ring, model='cube', position=(math.sin(r) * 5.5, math.cos(r) * 5.5, 0), rotation_z=-a,
                 scale=(1.3, .6, .6), texture='obsidian', color=WHITE)
            if k % 2 == 0:
                glow_entity(Entity(parent=ring, model='diamond', position=(math.sin(r) * 6.1, math.cos(r) * 6.1, 0),
                                   rotation_z=-a, scale=(.12, .4, .12), color=GOLD))
        glow_entity(Entity(parent=ring, model='circle', scale=10.4, z=.2, color=C('#ff1030', .35), double_sided=True))
        LT.torches.append([Vec3(0, 4, cz), (1.6, .2, .4), 16, 0])
        for i in range(8):
            x, z = self.free_spot(rnd)
            y = rnd.uniform(1.5, 4.5)
            part(R, model='diamond', position=(x, y, z), scale=(rnd.uniform(.5, 1.2), rnd.uniform(.6, 1.4), rnd.uniform(.5, 1.2)),
                 rotation=(rnd.uniform(0, 90), rnd.uniform(0, 90), 0), texture='obsidian', color=WHITE)
        for i in range(4):
            x, z = self.free_spot(rnd)
            glow_entity(Entity(parent=R, model='circle', rotation_x=90, position=(x, .03, z), scale=rnd.uniform(1.4, 2.6),
                               color=C('#ffb040', .8), double_sided=True))
            LT.torches.append([Vec3(x, .8, z), (1.3, .7, .2), 6, rnd.uniform(0, 9)])

    def deco_lair(self, R, rnd):
        w, d = self.w, self.d
        for i in range(14):   # паутина в углах и между колоннами
            x0, z0 = rnd.choice((-1, 1)) * (w / 2 - .2), rnd.uniform(-d / 2 + 2, d / 2 - 2)
            for k in range(6):
                a = rnd.uniform(-60, 60)
                ln = rnd.uniform(2, 5)
                part(R, model='cube', position=(x0 - math.copysign(ln / 2 * math.cos(math.radians(a)), x0), 3 + rnd.uniform(-2, 2), z0),
                     rotation=(0, a, rnd.uniform(-40, 40)), scale=(ln, .02, .02), color=C('#e0d8f0', .55), unlit=True)
        for i in range(10):
            x, z = self.free_spot(rnd)
            for k in range(rnd.randint(2, 5)):
                part(R, model='skull', position=(x + rnd.uniform(-.6, .6), .25, z + rnd.uniform(-.6, .6)),
                     scale=(.4, .5, .4), rotation_x=rnd.uniform(-30, 30), texture='silk', color=C('#e8e0d0'))
        for i in range(6):
            x, z = self.free_spot(rnd)
            part(R, model='rbox', position=(x, .08, z), rotation_y=rnd.uniform(0, 180), scale=(.08, .08, .5),
                 texture='skin_bone', color=WHITE)
            part(R, model='skull', position=(x + .2, .15, z), scale=.28, texture='skin_bone', color=WHITE)
        for i in range(4):
            x, z = self.free_spot(rnd)
            glow_entity(Entity(parent=R, model='orb', position=(x, .3, z), scale=(.5, .35, .5), color=C('#80ff60', .7)))
            LT.torches.append([Vec3(x, .8, z), (.4, 1.2, .3), 6, rnd.uniform(0, 9)])

    def deco_garden(self, R, rnd):
        for i in range(9):   # клёны с красной листвой
            x, z = self.free_spot(rnd)
            h = rnd.uniform(3.5, 5)
            part(R, model='taper', position=(x, h / 2, z), scale=(.35, h, .35), texture='wood', color=C('#806060'))
            for k in range(5):
                part(R, model='skull', position=(x + rnd.uniform(-1.3, 1.3), h + rnd.uniform(-.6, .6), z + rnd.uniform(-1.3, 1.3)),
                     scale=rnd.uniform(1.0, 1.8), color=C('#c01820'))
            self.pillars.append((x, z, .45))
        for i in range(3):
            x, z = self.free_spot(rnd)
            glow_entity(Entity(parent=R, model='circle', rotation_x=90, position=(x, .03, z), scale=rnd.uniform(3, 5),
                               color=C('#5a0a12', .9), double_sided=True))
        for i in range(4):
            x, z = self.free_spot(rnd)
            part(R, model='rbox', position=(x, .5, z), scale=(.5, 1, .5), texture='floor_stone', color=WHITE)
            part(R, model='rbox', position=(x, 1.15, z), scale=(.75, .3, .75), texture='floor_stone', color=WHITE)
            glow_entity(Entity(parent=R, model='cube', position=(x, 1.15, z), scale=(.5, .22, .78), color=C('#ff8060')))
            LT.torches.append([Vec3(x, 1.3, z), (1.4, .5, .3), 7, rnd.uniform(0, 9)])
            self.pillars.append((x, z, .5))

    def remnants(self, R, rnd, n=3):
        """Следы прошлых экспедиций: брошенные мешки, фонари, верёвки"""
        for i in range(n):
            x, z = self.free_spot(rnd)
            part(R, model='rbox', position=(x, .2, z), rotation_y=rnd.uniform(0, 180), scale=(.5, .4, .35),
                 texture='cloth', color=C('#a08a70'))
            part(R, model='taper', position=(x + .4, .06, z + .2), rotation=(90, rnd.uniform(0, 180), 0),
                 scale=(.06, .9, .06), texture='wood', color=WHITE)
            if rnd.random() < .6:
                part(R, model='rbox', position=(x - .35, .15, z - .2), rotation=(0, 0, 80), scale=(.22, .3, .22),
                     texture='metal', color=WHITE)

    def deco_village(self, R, rnd):
        self.lanterns = []
        for i in range(7):   # дома мёртвой деревни
            x, z = self.free_spot(rnd)
            if abs(x) < 6:
                continue
            ry = rnd.choice((0, 90, 180, 270))
            hw, hd = rnd.uniform(2.4, 3.4), rnd.uniform(2.2, 3)
            house = Entity(parent=R, position=(x, 0, z), rotation_y=ry)
            part(house, model='rbox', y=1.2, scale=(hw, 2.4, hd), texture='wood', color=C('#8a6a5a'))
            part(house, model='rbox', position=(0, 1.1, hd / 2 + .02), scale=(hw * .5, 1.6, .05), texture='shoji', color=C('#c0a090'))
            roof = part(house, model='diamond', y=2.9, scale=(hw * 1.5, 1.2, hd * 1.5), rotation_y=45, color=C('#2a1a1a'))
            lan = glow_entity(Entity(parent=house, model='skull', position=(hw * .35, 2.0, hd / 2 + .35),
                                     scale=(.35, .5, .35), color=C('#ff7a40', .95)))
            self.lanterns.append([lan, rnd.uniform(2, 7), Vec3(x, 2, z)])
            self.pillars.append((x, z, max(hw, hd) * .62))
        self.remnants(R, rnd, 2)
        for i in range(2):
            x, z = self.free_spot(rnd)
            part(R, model='taper', position=(x, .45, z), scale=(1.4, .9, 1.4), texture='floor_stone', color=WHITE)
            part(R, model='rbox', position=(x, 1.6, z), scale=(1.6, .12, .12), texture='wood', color=WHITE)
            self.pillars.append((x, z, .8))

    def free_spot(self, rnd):
        for _ in range(30):
            x = rnd.uniform(-self.w / 2 + 2, self.w / 2 - 2)
            z = rnd.uniform(-self.d / 2 + 4, self.d / 2 - 4)
            if abs(x) < 3 or any(math.hypot(x - a, z - b) < 2.5 for a, b, _ in self.pillars):
                continue
            return x, z
        return self.w / 2 - 2.5, 0

    # ---------- волны
    def plan_waves(self, L, rnd):
        self.waves = []
        lvl = self.level
        D = game.diff
        if self.boss_room:
            self.waves = [[('boss', b) for b in L['boss']]]
            return
        n_waves = 2 + (1 if self.room >= 1 else 0)
        for wv in range(n_waves):
            n = 4 + lvl + self.room + wv + D['extra']
            pack = []
            for i in range(n):
                cls = rnd.choice(L['pool'])
                if cls in (Oni, WingedDemon) and sum(1 for c in pack if c[1] is cls) >= 1 + lvl // 2:
                    cls = Gaki
                elite = rnd.random() < L['elite'] + D['elite']
                pack.append(('elite' if elite else 'mob', cls))
            self.waves.append(pack)

    def spawn_enemy(self, cls, pos, boss=False, elite=False):
        if game.state != 'play' and game.state != 'title':
            return
        e = cls(Vec3(pos[0], 0, pos[2]), self.level, boss, elite)
        dlog('spawn level', self.level + 1, 'room', self.room + 1, cls.__name__, 'boss' if boss else '')
        if e.flying and not boss:
            e.y = getattr(e, 'fly_y', 2)
        enemies.append(e)
        return e

    def next_wave(self):
        pack = self.waves[self.wave_i]
        self.wave_i += 1
        if not self.boss_room:
            banner(f'ВОЛНА {self.wave_i}/{len(self.waves)}', EMBER,
                   'среди них элита' if any(t_ == 'elite' for t_, c_ in pack) else '')
        sfx('drum', .8, 1)
        for i, (tp, cls) in enumerate(pack):
            self.pending += 1

            def go(cls=cls, tp=tp):
                self.pending -= 1
                if game.state != 'play':
                    return
                if tp == 'boss':
                    bcls, btitle = cls
                    nb = sum(1 for t_, c_ in pack if t_ == 'boss')
                    k = sum(1 for e_ in enemies if e_.boss)
                    p = Vec3((k - (nb - 1) / 2) * 7, 0, self.d / 2 - 8)
                    e = self.spawn_enemy(bcls, p, boss=True)
                    if e:
                        e.title = btitle
                        if e.flying:
                            e.y = 6
                    if k == 0:
                        banner(' и '.join(c_[1].split(',')[0] for t_, c_ in pack if t_ == 'boss'), BLOOD,
                               'СТРАЖИ ЭТОГО ЯРУСА' if nb > 1 else 'СТРАЖ ЭТОГО ЯРУСА')
                        story.on_boss(self.level)
                    return
                for _ in range(20):
                    a = random.uniform(0, math.tau)
                    p = Vec3(random.uniform(-self.w / 2 + 3, self.w / 2 - 3), 0, random.uniform(-self.d / 2 + 4, self.d / 2 - 4))
                    if dist2d(p, player.position) > 9 and not any(math.hypot(p[0] - a_, p[2] - b_) < 2 for a_, b_, _ in self.pillars):
                        break
                self.spawn_enemy(cls, p, elite=(tp == 'elite'))
            invoke(go, delay=.4 + i * .4)

    def tick(self, dt):
        if self.puzzle is not None:
            self.puzzle.tick(dt)
        if self.cleared:
            self.barrier.alpha = max(0, self.barrier.alpha - dt)
            if self.boss_room and self.level == len(LEVELS) - 1:
                return
            if player.z > self.d / 2 - .2 and not self.transit:
                self.transit = True
                game.advance()
            return
        if not enemies and self.pending == 0:
            if self.wave_i < len(self.waves):
                self.wave_t -= dt
                if self.wave_t <= 0:
                    self.next_wave()
                    self.wave_t = 1.8
            else:
                if self.puzzle is not None and not self.puzzle.solved:
                    if not self.puzzle.active and not self.puzzle.finishing:
                        self.puzzle.activate()
                    return
                self.open_gate()

    def open_gate(self):
        self.cleared = True
        sfx('door', .8)
        if not self.boss_room:
            banner('ПУТЬ ОТКРЫТ', BONE, 'иди к красным воротам')
            player.hp = min(player.max_hp, player.hp + int(player.max_hp * .12))
        game.slowmo = .7


# =====================================================================
# КАМЕРА как в GTA / Genshin: мышь свободно вращает камеру вокруг героя
# =====================================================================
class Cam:
    yaw = 0.0
    pitch = 14.0
    dist = 5.5
    want_dist = 5.5
    sens = .12          # градусов на пиксель
    pivot = None
    grabbed = False
    skip = 0


cam = Cam()


def grab_mouse(on):
    """Свой захват мыши: курсор прячется и каждый кадр возвращается в центр окна.
    Встроенный mouse.locked в Ursina на Windows даёт дрейф и дёрганье"""
    cam.grabbed = on
    cam.skip = 2
    try:
        from panda3d.core import WindowProperties
        props = WindowProperties()
        props.setCursorHidden(on)
        props.setMouseMode(WindowProperties.M_confined if on else WindowProperties.M_absolute)
        application.base.win.requestProperties(props)
        if on:
            w, h = application.base.win.getXSize(), application.base.win.getYSize()
            application.base.win.movePointer(0, w // 2, h // 2)
    except Exception:
        mouse.visible = not on


def read_mouse():
    """Смещение мыши в пикселях за кадр"""
    if not cam.grabbed:
        return 0.0, 0.0
    try:
        win = application.base.win
        w, h = win.getXSize(), win.getYSize()
        cx, cy = w // 2, h // 2
        p = win.getPointer(0)
        if not p.getInWindow():
            return 0.0, 0.0
        dx, dy = p.getX() - cx, p.getY() - cy
        win.movePointer(0, cx, cy)
    except Exception:
        return 0.0, 0.0
    if cam.skip > 0:
        cam.skip -= 1
        return 0.0, 0.0
    if abs(dx) > 400 or abs(dy) > 400:     # окно потеряло фокус и вернулось
        return 0.0, 0.0
    return float(dx), float(dy)


def aim_camera(target):
    """Ставит камеру строго по рысканью и тангажу, крен всегда ноль"""
    d = Vec3(target) - camera.position
    horiz = math.hypot(d[0], d[2])
    yaw = math.degrees(math.atan2(d[0], d[2]))
    pitch = -math.degrees(math.atan2(d[1], max(horiz, 1e-4)))
    camera.rotation = Vec3(pitch, yaw, 0)


def camera_blocked(p):
    if abs(p[0]) > dungeon.w / 2 - .35 or abs(p[2]) > dungeon.d / 2 - .35 and not (dungeon.cleared and abs(p[0]) < 1.8):
        return True
    if p[1] < .3 or p[1] > 6.2:
        return True
    for (px, pz, pr) in dungeon.pillars:
        if math.hypot(p[0] - px, p[2] - pz) < pr + .35:
            return True
    return False


def update_camera(dt):
    if game.state == 'title':
        a = game.clock * .1
        pos = Vec3(math.sin(a) * 11, 4.5, math.cos(a) * 11 - 3)
        camera.position = lerp(camera.position, pos, min(1, dt * 2))
        aim_camera(Vec3(0, 2, 6))
        return
    if game.state in ('over', 'victory'):
        a = game.clock * .25
        tgt = player.position + Vec3(0, 1, 0)
        camera.position = lerp(camera.position, tgt + Vec3(math.sin(a) * 7, 4, math.cos(a) * 7), min(1, dt * 2))
        aim_camera(tgt)
        return

    dx, dy = read_mouse()
    if not game.paused:
        cam.yaw = (cam.yaw + dx * cam.sens) % 360
        cam.pitch = clamp(cam.pitch + dy * cam.sens, -25, 60)

    # точка, вокруг которой вращается камера — мягко догоняет героя
    target = player.position + Vec3(0, 1.55, 0)
    if cam.pivot is None:
        cam.pivot = Vec3(target)
    cam.pivot = lerp(cam.pivot, target, min(1, dt * 14))

    yaw, p = math.radians(cam.yaw), math.radians(cam.pitch)
    back = Vec3(-math.sin(yaw) * math.cos(p), math.sin(p), -math.cos(yaw) * math.cos(p))
    right = Vec3(math.cos(yaw), 0, -math.sin(yaw))
    pivot = cam.pivot + right * .35

    # камера упирается в стены и колонны — подъезжает ближе, а не проходит сквозь
    want = cam.want_dist
    d = .6
    while d < want:
        if camera_blocked(pivot + back * (d + .15)):
            break
        d += .1
    d = min(d, want)
    cam.dist = d if d < cam.dist else lerp(cam.dist, d, min(1, dt * 4))

    want_pos = pivot + back * cam.dist
    if game.cam_blend > 0:
        k = 1 - game.cam_blend / .7
        game.cam_blend = max(0, game.cam_blend - dt)
        camera.position = lerp(camera.position, want_pos, min(1, dt * 4 + k * k * .3))
        camera.rotation = Vec3(lerp(camera.rotation_x, cam.pitch, min(1, dt * 5 + k * .2)),
                               lerp_angle(camera.rotation_y, cam.yaw, min(1, dt * 5 + k * .2)), 0)
    else:
        camera.position = want_pos
        camera.rotation = Vec3(cam.pitch, cam.yaw, 0)


def apply_shake(dt):
    if game.shake > 0:
        s = game.shake
        camera.position += Vec3(random.uniform(-s, s), random.uniform(-s, s), random.uniform(-s, s)) * .5
        game.shake = max(0, game.shake - dt * 1.6)


# =====================================================================
# УЛЬТЫ: «Багровое Полнолуние» самурая и «Буря тысячи перьев» Ханы
# =====================================================================
class Ult:
    tint = C('#2a0004')
    cam_pos = Vec3(0, 0, 0)
    look = Vec3(0, 0, 0)
    active = False
    t = 0.0
    events = []
    petals = []
    base = Vec3(0, 0, 0)
    fwd = Vec3(0, 0, 1)
    right = Vec3(1, 0, 0)


ult = Ult()


def start_ult():
    if player.energy < 100 or ult.active or game.state != 'play':
        return
    player.energy = 0
    player.action = None
    ult.active = True
    ult.t = 0
    ult.base = Vec3(player.position)
    ult.fwd = dir_of(player.rotation_y)
    ult.right = Vec3(ult.fwd[2], 0, -ult.fwd[0])
    ult.events = [(0.0, ult_begin), (1.25, ult_flash), (1.6, ult_slashes), (2.2, ult_impact), (3.3, ult_end)]
    ult.cam_pos = Vec3(camera.position)
    ult.look = player.position + Vec3(0, 1.6, 0)


def ult_begin():
    sfx('ult', .95, 1)
    duck(.1)
    hud.enabled = False
    boss_root.visible = False
    bar_top.animate_y(.45, duration=.25, curve=curve.out_cubic)
    bar_bot.animate_y(-.45, duration=.25, curve=curve.out_cubic)
    ult.tint = C('#00261f') if player.KIND == 'kaze' else C('#2a0004')
    tint.color = Color(ult.tint[0], ult.tint[1], ult.tint[2], 0)
    tint.animate_color(Color(ult.tint[0], ult.tint[1], ult.tint[2], .55), duration=.3)
    player.pose_override = 'ult'
    for i in range(44):
        p = glow_entity(Entity(model='quad', texture='glow', billboard=True, scale=random.uniform(.2, .45),
                               color=player.FX1 if i % 3 else player.FX2))
        p.ang = random.uniform(0, math.tau)
        p.rad = random.uniform(1.4, 2.4)
        p.hgt = random.uniform(0, 2.6)
        ult.petals.append(p)
    sc = Color(player.FX1[0], player.FX1[1], player.FX1[2], .9)
    stroke = ui_quad(scale=(0, .1), position=(-EDGE, -.2), origin=(-.5, 0), color=sc, z=-.2)
    stroke.animate_scale_x(1.1, duration=.35, curve=curve.out_expo)
    name = Text(parent=camera.ui, text=player.ULT_NAME, origin=(-.5, 0), position=(-EDGE - .2, -.2), scale=2.3,
                color=WHITE, z=-.25)
    name.animate_x(-EDGE + .03, duration=.45, curve=curve.out_expo)
    for e in (stroke, name):
        e.fade_out(duration=.2, delay=.85)
        destroy(e, delay=1.1)


def ult_flash():
    white.color = C('#fff4ef', .55)
    white.animate_color(C('#fff4ef', 0), duration=.6, curve=curve.out_quad)
    player.animate_y(3.4, duration=.5, curve=curve.out_sine)
    for p in ult.petals:
        burst(p.position, 2, player.FX1, 5, .1, .5, glow=True)
        destroy(p)
    ult.petals = []
    burst(player.position + Vec3(0, 1, 0), 30, player.FX_GLOW, 9, .14, .7, glow=True)
    add_flash(player.position + Vec3(0, 2, 0), player.AURA, 14, .5)


def ult_slashes():
    for i in range(9):
        ln = ui_quad(scale=(0, .012 if i % 2 else .022), rotation_z=random.uniform(-40, 40),
                     position=(random.uniform(-.4, .4), random.uniform(-.25, .25)),
                     color=BONE if i % 2 else player.FX_GLOW, z=-.15)
        invoke(ln.animate_scale_x, 2.6, duration=.1, curve=curve.out_expo, delay=i * .045)
        ln.fade_out(duration=.25, delay=.2 + i * .045)
        destroy(ln, delay=.6 + i * .05)
    c = player.position + Vec3(0, 1.5, 0)
    for i in range(8):
        rot = (random.uniform(-40, 40), random.uniform(0, 360), random.uniform(-70, 70))
        flash_fx(BIG_ARC, c, rot, player.FX1, .6, 1.5, .3, delay=i * .05)


def ult_impact():
    player.animate_y(0, duration=.22, curve=curve.in_quad)
    invoke(ult_land, delay=.22)


ULT_RADIUS = 11


def ult_damage(d):
    base = random.randint(230, 290) * player.DMG * (1 + .12 * dungeon.level)
    return int(base * (.35 if d.boss else (.6 if d.elite else 1)))


def ult_land():
    c = Vec3(player.x, 0, player.z)
    game.shake = 1.1
    if player.KIND == 'kaze':
        return ult_land_wind(c)
    for k, d in enumerate((0, .12, .24)):
        invoke(shockring, c, ULT_RADIUS * 1.8, C('#ff4a3d', .9) if k != 1 else C('#fff2ec', .8), .6, delay=d)
    pillar = glow_entity(Entity(model='cube', position=c + Vec3(0, 25, 0), scale=(2.6, 50, 2.6), color=C('#ff2a2a', .75)))
    pillar.animate_scale((0, 50, 0), duration=.7, curve=curve.in_cubic)
    destroy(pillar, delay=.75)
    g = glow_entity(Entity(model='quad', texture='glow', rotation_x=90, position=c + Vec3(0, .05, 0), scale=36,
                           color=C('#c3121e', .8), double_sided=True))
    g.fade_out(duration=1.2)
    destroy(g, delay=1.3)
    add_flash(c + Vec3(0, 2, 0), (1, .3, .2), 24, 1.0)
    burst(c + Vec3(0, .3, 0), 60, BLOOD, 14, .18, 1.0)
    burst(c + Vec3(0, .3, 0), 30, EMBER, 12, .12, .8, glow=True)
    for i in range(12):
        a = i / 12 * 360
        eruption(c + dir_of(a) * 4, delay=.05 + i * .02)
        eruption(c + dir_of(a + 15) * 8, delay=.15 + i * .02)
    targets = sorted([d for d in enemies if dist2d(d.position, c) < ULT_RADIUS], key=lambda d: dist2d(d.position, c))
    for i, d in enumerate(targets):
        push = flat(d.position - c).normalized() * 6 if dist2d(d.position, c) > .01 else Vec3(0, 0, 6)
        invoke(lambda d=d, push=push: d.take(ult_damage(d), True, push)
               if d in enemies else None, delay=i * .035)


def ult_land_wind(c):
    for k, d in enumerate((0, .12, .24)):
        invoke(shockring, c, ULT_RADIUS * 1.8, WIND if k != 1 else WIND2, .6, delay=d)
    waves.append(Cyclone(c, life=2.6, radius=6.5, dmg=8, big=True))
    g = glow_entity(Entity(model='quad', texture='glow', rotation_x=90, position=c + Vec3(0, .05, 0), scale=36,
                           color=Color(.3, 1, .8, .6), double_sided=True))
    g.fade_out(duration=1.2)
    destroy(g, delay=1.3)
    add_flash(c + Vec3(0, 2, 0), (.3, 1, .8), 24, 1.0)
    for i in range(70):
        a = random.uniform(0, math.tau)
        r = random.uniform(1, 12)
        burst(c + Vec3(math.sin(a) * r, random.uniform(.5, 5), math.cos(a) * r), 1, WIND2, 9, .14, 1.0, grav=-2, glow=True)
    for i in range(16):
        a = i / 16 * 360
        flash_fx(BIG_ARC, c + Vec3(0, 1 + (i % 4) * .8, 0), (0, a, random.uniform(-30, 30)), WIND, .5, 2.6, .4,
                 delay=i * .03)
    targets = sorted([d for d in enemies if dist2d(d.position, c) < ULT_RADIUS], key=lambda d: dist2d(d.position, c))
    for i, d in enumerate(targets):
        pull = flat(c - d.position).normalized() * 5 if dist2d(d.position, c) > .01 else Vec3(0, 0, 0)
        invoke(lambda d=d, pull=pull: d.take(ult_damage(d), True, pull)
               if d in enemies else None, delay=i * .035)


def ult_end():
    bar_top.animate_y(.62, duration=.3)
    bar_bot.animate_y(-.62, duration=.3)
    tint.animate_color(Color(ult.tint[0], ult.tint[1], ult.tint[2], 0), duration=.4)
    duck(BGM_VOL)
    hud.enabled = True
    boss_root.visible = True
    player.pose_override = None
    player.inv = .8
    ult.active = False
    game.cam_blend = .7


def update_ult(dt):
    ult.t += dt
    while ult.events and ult.t >= ult.events[0][0]:
        ult.events.pop(0)[1]()
    if not ult.active:
        return
    head = player.position + Vec3(0, 1.7, 0)
    # ракурсы те же, но камера не прыгает между ними, а плавно перетекает
    if ult.t < 1.25:
        k = smooth(ult.t / 1.25)
        want = ult.base + ult.fwd * (2.9 - k * 1.0) + ult.right * (.9 - k * .4) + Vec3(0, 1.8 - k * .2, 0)
        look = head + Vec3(0, -.05, 0)
        for p in ult.petals:
            p.ang += dt * (3 + k * 5)
            r = p.rad * (1 - k * .5)
            p.position = player.position + Vec3(math.cos(p.ang) * r, p.hgt + k * 1.2, math.sin(p.ang) * r)
    elif ult.t < 2.2:
        k = smooth((ult.t - 1.25) / .95)
        want = ult.base - ult.fwd * (7 + k * 2.5) + ult.right * 3 + Vec3(0, 1.4 + k * 2, 0)
        look = player.position + Vec3(0, 1.8, 0)
    else:
        k = smooth(min(1, (ult.t - 2.2) / .9))
        want = ult.base - ult.fwd * (9.5 + k * 3) + Vec3(0, 6 + k * 3, 0)
        look = ult.base + Vec3(0, 1, 0)
    rate = min(1, dt * 5)
    ult.cam_pos = lerp(ult.cam_pos, want, rate)
    ult.look = lerp(ult.look, look, rate)
    camera.position = ult.cam_pos
    aim_camera(ult.look)


# =====================================================================
# СЮЖЕТ «Бездна Проклятых»: реплики, надписи, катсцены, напарник, финал
# =====================================================================
SPEAKERS = {'hana': ('ХАРУКАЗЭ', C('#7af0d0')), 'samurai': ('АСАХИ', C('#ff5a4a')), 'voice': ('ГОЛОС', C('#c8a0ff'))}

# скрижали (комната 0) и записки экспедиции (комната 1) по ярусам
TABLETS = {
    0: ('Скрижаль у входа',
        'Здесь заперты те, кто отверг смерть.\nНе открывай. Не слушай.\nНе отвечай, когда они зовут тебя по имени.',
        'Три полосы под кругом... Я видел этот знак. Во сне?', None),
    1: ('Клятва строителей',
        'Мы, строители печати из рода Кагэ, клянёмся:\nкамень будет держать, пока жив наш род.',
        'Кагэ. Это слово отзывается во мне, как старая рана.', None),
    2: ('Табличка на колодце',
        'Деревня Мидзуно. Мы спустились, чтобы жить вечно.\nЖрецы обещали: смерть не придёт под землю.\nНад колодцем — герб белой цапли.',
        'Я знаю этот колодец. Знаю, где ступени. Откуда?', 'Белая цапля... Такая же была на мамином гребне.'),
    3: ('Обугленная надпись',
        'Ритуал начался в полночь. К утру никто не умер.\nК следующей луне никто уже не был человеком.',
        None, 'Никто не умер... и никто не остался собой.'),
    4: ('Ледяная плита',
        'Род Сирасаги остаётся у печати.\nИх кровь — замок, их память — ключ.\nПусть потомки забудут. Кровь вспомнит.',
        'Сирасаги стояли у печати рядом с Кагэ. Рядом с моими...', 'Сирасаги. Это моя фамилия.'),
    5: ('Камень под паутиной',
        'Печать слабеет. Каждые сто лет нужен тот,\nкто останется внизу и замкнёт её собой.\nДобровольцев больше нет.',
        None, None),
    6: ('Алтарь сада',
        'Демоны не пришли из другого мира.\nЭто мы. Это всегда были мы.',
        'Мои предки строили стены, за которыми это делали.', 'Они были людьми. Все. И Рэн мог стать одним из них.'),
}
NOTES = {
    0: 'День 1. Вход закрылся за нами сам.\nТоцука клянётся, что камни двигались изнутри.',
    1: 'День 4. В корнях голоса. Носильщик Дзиро ответил им.\nБольше мы его не видели.',
    2: 'Рэн, если ты это читаешь — не заходи в дома.\nФонари зажигаются сами. — Мики',
    3: 'Рэн рисует в дневнике знаки, которых никто не учил.\nГоворит, что они ему снятся.',
    4: 'Асахи из нашей группы знает дорогу.\nСлишком хорошо знает. Я ему не верю.',
    5: 'Рэн ушёл вперёд один. Сказал: «Сестра поймёт,\nкогда дойдёт до сада». Мы его не догнали.',
    6: 'Харуказэ, если найдёшь это: я узнал, кто мы.\nНе вини маму за то, что молчала. — Рэн',
}
# реплики в начале яруса (после встречи героев)
LEVEL_TALK = {
    1: [('hana', 'Корни светятся. Будто их зажгли для нас.'), ('samurai', 'Не для нас. Для них.')],
    2: [('samurai', 'Деревня под землёй. Я знаю, где здесь колодец. Не спрашивай откуда.'),
        ('hana', 'Я и не спрашиваю. Пока.')],
    3: [('hana', 'Они снова попятились, когда я подошла. Ты видел?'), ('samurai', 'Видел. Это и пугает.')],
    4: [('samurai', 'Этот холод не ото льда. Печать тянет тепло из живых.'), ('hana', 'Тогда не будем стоять.')],
    5: [('hana', 'Здесь были люди из экспедиции. Паутина свежая.'), ('samurai', 'Не смотри в коконы.')],
    6: [('hana', 'Этот сад... здесь и был ритуал.'), ('samurai', 'А мои предки строили для него стены.')],
    7: [('samurai', 'Сердце Бездны. Дальше только печать.'), ('voice', 'Харуказэ... Харуказэ, ты пришла...'),
        ('hana', 'Рэн? Рэн, это ты?!')],
}
BOSS_TALK = {
    0: ('samurai', 'Привратник. Значит, нас и правда не хотят выпускать.'),
    2: ('hana', 'Он защищает деревню. До сих пор.'),
    6: ('samurai', 'Жрецы. Те, кто начал всё это.'),
    7: ('hana', 'Он тоже был человеком. Как и все они.'),
}


class Story:
    def __init__(self):
        self.lines = []
        self.cur = None
        self.t = 0
        self.met = False
        self.read = set()

    def reset(self):
        self.lines = []
        self.cur = None
        self.met = False
        self.read = set()
        dlg_root.enabled = False

    def say(self, who, text, dur=None):
        self.lines.append((who, text, dur or max(2.6, len(text) * .065)))

    def update(self, dt):
        if self.cur is None and self.lines:
            self.cur = list(self.lines.pop(0))
            who, text, dur = self.cur
            nm, col = SPEAKERS[who]
            dlg_name.text = nm
            dlg_name.color = col
            dlg_text.text = fit_text(text, .88, .95)
            dlg_root.enabled = True
            dlg_root.alpha = 1
        if self.cur is not None:
            self.cur[2] -= dt
            if self.cur[2] <= 0:
                self.cur = None
                if not self.lines:
                    dlg_root.enabled = False

    def on_room(self, level, room):
        me = player.KIND
        if level == 0 and room == 0 and not self.met:
            if me == 'kaze':
                self.say('hana', 'Выход... запечатан. Изнутри?')
                self.say('hana', 'Рэн, держись. Я иду.')
            else:
                self.say('samurai', 'Выход запечатан изнутри. Значит, нас ждали.')
        elif level == 0 and room == 1 and not self.met:
            start_meeting()
        elif room == 0 and level in LEVEL_TALK and self.met:
            for who, t in LEVEL_TALK[level]:
                self.say(who, t)

    def on_boss(self, level):
        if self.met and companion[0] is not None:
            r = companion[0].h
            r.hp = max(r.hp, r.max_hp)
            invoke(banner, '1 / 2 — СМЕНИТЬ ГЕРОЯ', BONE, f'{r.NAME} рядом и готов к бою', delay=2.4)
        if level in BOSS_TALK and self.met:
            who, t = BOSS_TALK[level]
            self.say(who, t)


story = Story()

# --- UI сюжета
dlg_root = Entity(parent=camera.ui, enabled=False)
ui_frame(dlg_root, (-.06, -.315), (.92, .095), z=.02)
dlg_name = Text(parent=dlg_root, text='', origin=(0, 0), position=(-.06, -.288), scale=.85, color=BONE)
dlg_text = Text(parent=dlg_root, text='', origin=(0, 0), position=(-.06, -.325), scale=.95, color=BONE)

prompt = Text(parent=camera.ui, text='', origin=(0, 0), y=-.25, scale=1.0, color=C('#f0dcc0'), enabled=False)

read_root = Entity(parent=camera.ui, enabled=False)
ui_quad(parent=read_root, scale=(4, 2), color=C('#000000', .55), z=.1)
ui_frame(read_root, (0, 0), (.95, .52), z=.05, bg=C('#14110e', .96))
ui_quad(parent=read_root, scale=(.95, .006), y=.18, color=C('#c8a070', .6), z=.04)
read_title = Text(parent=read_root, text='', origin=(0, 0), y=.21, scale=1.3, color=C('#e8c890'))
read_body = Text(parent=read_root, text='', origin=(0, .5), y=.14, scale=1.05, color=C('#f0e4d8'))
read_mind = Text(parent=read_root, text='', origin=(0, .5), y=-.09, scale=.95, color=C('#ff8a7a'))
Text(parent=read_root, text='F, Enter или ЛКМ — закрыть', origin=(0, 0), y=-.22, scale=.8, color=C('#a08878'))

cine_text = Text(parent=camera.ui, text='', origin=(0, 0), y=-.36, scale=1.35, color=C('#f4e8e0'), z=-.2,
                 enabled=False)
cine_skip = Text(parent=camera.ui, text='Пробел — пропустить', origin=(.5, 0), position=(EDGE, -.47), scale=.75,
                 color=C('#907070'), z=-.2, enabled=False)
cine_title = Text(parent=camera.ui, text='', origin=(0, 0), y=.05, scale=4.2, color=BLOOD, z=-.25, enabled=False)


class Tablet(Entity):
    """Скрижаль или записка экспедиции — их можно прочитать (F)"""
    def __init__(self, parent, pos, level, kind):
        super().__init__(parent=parent, position=pos)
        self.level, self.kind = level, kind
        if kind == 'stone':
            part(self, model='rbox', y=.9, scale=(1.1, 1.8, .3), texture='floor_stone', color=C('#a09088'))
            part(self, model='rbox', y=.1, scale=(1.4, .2, .5), texture='floor_stone', color=C('#807068'))
            self.glow = glow_entity(Entity(parent=self, model='quad', texture='icon_moon', position=(0, 1.15, -.17),
                                           scale=.5, color=C('#ffb070', .9), double_sided=True))
        else:
            part(self, model='rbox', y=.25, scale=(.5, .5, .35), texture='cloth', color=C('#a08a70'))
            self.glow = glow_entity(Entity(parent=self, model='quad', texture='glow', billboard=True, y=.7, scale=.6,
                                           color=C('#ffd8a0', .7)))
            part(self, model='rbox', position=(.05, .52, 0), rotation_x=-20, scale=(.32, .02, .24), texture='paper',
                 color=WHITE)

    def text(self):
        me = player.KIND
        if self.kind == 'stone':
            title, body, sam, hana = TABLETS[self.level]
            mind = sam if me == 'samurai' else hana
            who = 'АСАХИ' if me == 'samurai' else 'ХАРУКАЗЭ'
            return title, body, (f'{who}: {mind}' if mind else '')
        return 'Записка экспедиции', NOTES[self.level], ''


def add_tablets(R, level, room, spot):
    if room == 0 and level in TABLETS:
        x, z = spot
        t = Tablet(R, Vec3(x, 0, z), level, 'stone')
        dungeon.tablets.append(t)
        dungeon.pillars.append((x, z, .6))
    elif room == 1 and level in NOTES:
        x, z = spot
        dungeon.tablets.append(Tablet(R, Vec3(x, 0, z), level, 'note'))


def nearest_tablet():
    if player is None:
        return None
    best, bd = None, 2.4
    for t in dungeon.tablets:
        d = dist2d(t.world_position, player.position)
        if d < bd:
            best, bd = t, d
    return best


def open_tablet(t):
    title, body, mind = t.text()
    read_title.text = title
    read_body.text = body
    read_mind.text = fit_text(mind, .86, .95) if mind else ''
    read_root.enabled = True
    game.state = 'read'
    grab_mouse(False)
    story.read.add((t.level, t.kind))
    sfx('orb', .5, .7)


def close_tablet():
    read_root.enabled = False
    game.state = 'play'
    grab_mouse(True)


# --- напарник: второй герой идёт рядом и сражается
class Companion:
    def __init__(self, hero_cls, pos):
        self.h = hero_cls()
        self.h.DMG = self.h.DMG * .55
        self.h.position = pos
        self.cd = 1.0
        self.skill_t = 6.0

    def destroy(self):
        destroy(self.h)

    def place(self, pos):
        self.h.position = pos
        self.h.action = None

    def tick(self, dt):
        h = self.h
        aura, acol = LT.aura, LT.aura_col
        h.skill_cd = max(0, h.skill_cd - dt)
        h.range_cd = max(0, h.range_cd - dt)
        self.cd -= dt
        self.skill_t -= dt
        target = None
        bd = 11.0
        for e in enemies:
            d = dist2d(e.position, h.position)
            if d < bd:
                target, bd = e, d
        if h.action:
            h.tick_action(dt)
            h.y = max(0, h.y)
        else:
            if target is not None:
                goal = flat(target.position) - (flat(target.position) - flat(h.position)).normalized() * (target.radius + 1.6)
            else:
                side = Vec3(math.cos(math.radians(player.rotation_y)), 0, -math.sin(math.radians(player.rotation_y)))
                goal = flat(player.position) - dir_of(player.rotation_y) * 1.6 + side * 1.6
            mv = goal - flat(h.position)
            dist = mv.length()
            if dist > .3:
                spd = h.SPEED * (1.25 if dist > 6 else 1)
                h.position += mv.normalized() * min(dist, spd * dt)
                h.rotation_y = lerp_angle(h.rotation_y, heading_of(mv), min(1, dt * 10))
                h.move_amt = lerp(h.move_amt, 1, min(1, dt * 8))
            else:
                h.move_amt = lerp(h.move_amt, 0, min(1, dt * 8))
                if target is not None:
                    h.rotation_y = lerp_angle(h.rotation_y, heading_of(flat(target.position) - flat(h.position)), min(1, dt * 10))
            h.run += h.move_amt * dt * 12
            if target is not None and bd < target.radius + 2.6 and self.cd <= 0:
                self.cd = random.uniform(.7, 1.1)
                if self.skill_t <= 0:
                    self.skill_t = random.uniform(8, 11)
                    h.start('skill', quiet=True)
                else:
                    h.start(random.choice(('L1', 'L2', 'L3', 'L4')), quiet=True)
        if dist2d(h.position, player.position) > 18:
            h.position = player.position - dir_of(player.rotation_y) * 2
        h.y = 0
        dungeon.collide(h, .45)
        h.animate_body(dt)
        LT.aura, LT.aura_col = aura, acol


companion = [None]


def make_companion(pos):
    if companion[0] is not None:
        companion[0].destroy()
    other = Kaze if player.KIND == 'samurai' else Samurai
    companion[0] = Companion(other, pos)
    return companion[0]


def drop_companion():
    if companion[0] is not None:
        companion[0].destroy()
        companion[0] = None


# --- отряд: второй герой выходит только в бою со стражем
def apply_hero_ui(h):
    hp_name.text = h.NAME
    icons = h.ICONS
    btn_attack.set_icon(icons[0])
    btn_heavy.set_icon(icons[1])
    btn_skill.set_icon(icons[2])
    btn_ult.set_icon(icons[3])
    btn_ult.fill.color = Color(h.FX1[0], h.FX1[1], h.FX1[2], 1)
    energy_fill.color = Color(h.FX1[0], h.FX1[1], h.FX1[2], 1)
    hp_lag.scale_x = HPW * max(0, h.hp) / h.max_hp
    pause_help.text = fit_text('\n'.join(f'{k}  —  {v}' for k, v in h.MOVES) +
                               '\nH — лечение на 40% за 100 душ' +
                               '\n1 / 2 / Tab — сменить героя (после первого стража — когда угодно)' +
                               '\nShift — рывок    Пробел — прыжок    колёсико — приблизить камеру',
                               1.14, pause_help.scale_x)


def free_switch():
    """После первого стража героев можно менять в любой момент"""
    return dungeon.level >= 1 or (dungeon.boss_room and dungeon.cleared)


def can_switch():
    return free_switch() or (dungeon.boss_room and not dungeon.cleared)


def switch_hero(forced=False):
    global player
    if companion[0] is None or not story.met or game.state != 'play':
        return False
    new = companion[0].h
    if not forced:
        if not can_switch():
            popup_number(player.position + Vec3(0, 2.4, 0), 'смена героя откроется после первого стража',
                         C('#b09090'))
            return False
        if ult.active or game.switch_cd > 0:
            return False
        if new.hp <= 0:
            if game.souls < REVIVE_COST:
                popup_number(player.position + Vec3(0, 2.4, 0),
                             f'{new.NAME.lower()} пал(а) — воскресить за {REVIVE_COST} душ (есть {game.souls})',
                             C('#c8a0ff'))
                return False
            game.souls -= REVIVE_COST
            new.hp = int(new.max_hp * .6)
            new.inv = 3.0
            banner('ВОСКРЕШЕНИЕ', GOLD, f'{new.NAME.lower()} снова в бою  ·  -{REVIVE_COST} душ')
            invoke(lambda: (shockring(player.position, 6, GOLD, .5),
                            burst(player.position + Vec3(0, 1, 0), 36, C('#ffe0a0'), 7, .12, .9, grav=-2, glow=True),
                            add_flash(player.position + Vec3(0, 1.5, 0), (1, .85, .5), 12, .6), sfx('orb', .9, .6)),
                   delay=.05)
    old = player
    new.position = Vec3(old.x, 0, old.z)
    new.rotation_y = old.rotation_y
    new.vy = 0
    new.action = None
    new.queued = None
    new.dash_t = 0
    new.slow_t = 0
    new.pose_override = None
    new.inv = 1.0
    new.cur = dict(new.IDLE)
    new.enabled = True
    old.action = None
    old.enabled = False
    companion[0].h = old
    player = new
    game.switch_cd = 1.5
    shockring(new.position, 3.5, new.FX1, .4)
    burst(new.position + Vec3(0, 1, 0), 26, new.FX_GLOW, 6, .1, .6, grav=0, glow=True)
    burst(old.position + Vec3(0, 1, 0), 16, C('#2a1a2a'), 3, .2, .7, grav=-1)
    add_flash(new.position + Vec3(0, 1.5, 0), new.AURA, 8, .4)
    sfx('dash', .7, .8)
    show_move_name(new.NAME)
    apply_hero_ui(new)
    return True


def party_rescue():
    """Активный герой пал в бою со стражем — второй подхватывает"""
    if companion[0] is None or not story.met or not can_switch():
        return False
    if companion[0].h.hp <= 0:
        return False
    fell = 'ПАЛА' if player.KIND == 'kaze' else 'ПАЛ'
    banner(f'{player.NAME} {fell}', BLOOD, f'{companion[0].h.NAME} принимает бой')
    burst(player.position + Vec3(0, 1, 0), 30, BLOOD, 6, .14, .9)
    switch_hero(forced=True)
    return True


def switch_back_to_main():
    """После победы над стражем управление возвращается основному герою"""
    if companion[0] is None or game.state not in ('play',):
        return
    main_kind = HEROES[game.hero_i].KIND
    if player.KIND != main_kind and not free_switch():
        r = companion[0].h
        r.hp = max(r.hp, int(r.max_hp * .3))
        switch_hero(forced=True)
    r = companion[0].h
    r.hp = max(r.hp, int(r.max_hp * .3))


# --- панель отряда справа, как в Геншине
party_root = Entity(parent=hud, enabled=False)
party_rows = []
for i in range(2):
    y = .12 - i * .075
    bg = ui_quad(parent=party_root, scale=(.2, .06), position=(EDGE - .1, y), color=C('#12060a', .7), z=.01)
    key = Text(parent=party_root, text=str(i + 1), origin=(0, 0), position=(EDGE - .185, y), scale=1.2, color=GOLD)
    nm = Text(parent=party_root, text='', origin=(-.5, 0), position=(EDGE - .16, y + .012), scale=.85, color=BONE)
    ui_quad(parent=party_root, scale=(.13, .008), position=(EDGE - .16, y - .014), origin=(-.5, 0), color=C('#2a1418'))
    fill = ui_quad(parent=party_root, scale=(.13, .008), position=(EDGE - .16, y - .014), origin=(-.5, 0),
                   color=C('#d7263a'), z=-.01)
    party_rows.append((bg, key, nm, fill))
party_lock = Text(parent=party_root, text='', origin=(.5, 0), position=(EDGE, -.035), scale=.7, color=C('#a08080'))


def update_party():
    if companion[0] is None or not story.met:
        party_root.enabled = False
        return
    party_root.enabled = True
    main = player if player.KIND == HEROES[game.hero_i].KIND else companion[0].h
    other = companion[0].h if main is player else player
    for (bg, key, nm, fill), h in zip(party_rows, (main, other)):
        active = h is player
        set_text(nm, h.NAME)
        nm.color = BONE if h.hp > 0 else C('#806060')
        fill.scale_x = .13 * max(0, h.hp) / h.max_hp
        bg.color = Color(h.FX1[0] * .5, h.FX1[1] * .5, h.FX1[2] * .5, .85) if active else C('#12060a', .7)
    on = can_switch()
    dead = companion[0].h.hp <= 0
    set_text(party_lock, ('смена — после первого стража' if not on else
                          (f'пал — выбери, чтобы воскресить ({REVIVE_COST} душ)' if dead else '')))
    for bg, key, nm, fill in party_rows:
        key.color = GOLD if on else C('#605050')


# --- катсцены
class Cine:
    active = False
    shots = []
    i = 0
    t = 0.0
    on_end = None
    skippable = True


cine = Cine()


def play_cine(shots, on_end=None, skippable=True):
    cine.active = True
    cine.shots = shots
    cine.i = 0
    cine.t = 0
    cine.on_end = on_end
    cine.skippable = skippable
    cine.prev_state = game.state
    game.state = 'cine'
    hud.enabled = False
    boss_root.visible = False
    bar_top.animate_y(.45, duration=.4, curve=curve.out_cubic)
    bar_bot.animate_y(-.45, duration=.4, curve=curve.out_cubic)
    cine_skip.enabled = skippable
    grab_mouse(False)
    _shot_start()


def _shot_start():
    sh = cine.shots[cine.i]
    if sh.get('fx'):
        sh['fx']()
    txt = sh.get('text', '')
    if isinstance(txt, tuple):
        who, line = txt
        nm, col = SPEAKERS[who]
        cine_text.text = f'{nm}:  {line}'
        cine_text.color = col
    else:
        cine_text.text = txt
        cine_text.color = C('#f4e8e0')
    cine_text.enabled = bool(txt)
    if txt:
        cine_text.alpha = 0
        cine_text.animate_color(Color(cine_text.color[0], cine_text.color[1], cine_text.color[2], 1), duration=.5)


def end_cine():
    if not cine.active:
        return
    cine.active = False
    cine_text.enabled = False
    cine_skip.enabled = False
    cine_title.enabled = False
    bar_top.animate_y(.62, duration=.4)
    bar_bot.animate_y(-.62, duration=.4)
    boss_root.visible = True
    game.state = 'play'
    hud.enabled = True
    grab_mouse(True)
    cam.pivot = None
    if cine.on_end:
        f = cine.on_end
        cine.on_end = None
        f()


def update_cine(dt):
    sh = cine.shots[cine.i]
    cine.t += dt
    k = smooth(min(1, cine.t / sh['dur']))
    cf, ct = sh['cam']
    lf, lt = sh['look']
    cf, ct, lf, lt = (v() if callable(v) else v for v in (cf, ct, lf, lt))
    camera.position = lerp(Vec3(cf), Vec3(ct), k)
    aim_camera(lerp(Vec3(lf), Vec3(lt), k))
    if sh.get('tick'):
        sh['tick'](dt, cine.t)
    if sh.get('shake'):
        camera.position += Vec3(random.uniform(-1, 1), random.uniform(-1, 1), random.uniform(-1, 1)) * sh['shake']
    if cine.t >= sh['dur']:
        cine.i += 1
        cine.t = 0
        if cine.i >= len(cine.shots):
            end_cine()
        else:
            _shot_start()


def falling_rocks():
    for i in range(14):
        p = Vec3(random.uniform(-8, 8), 6.5, random.uniform(-dungeon.d / 2 + 2, 4))
        r = Entity(model='diamond', position=p, scale=random.uniform(.25, .7), texture='floor_stone', color=C('#a09088'),
                   rotation=(random.uniform(0, 90), random.uniform(0, 90), 0))
        r.shader = world_shader()
        r.animate_y(.2, duration=random.uniform(.5, 1.2), delay=random.uniform(0, 1.5), curve=curve.in_quad)
        destroy(r, delay=6)
    for i in range(30):
        burst(Vec3(random.uniform(-8, 8), random.uniform(4, 6.5), random.uniform(-dungeon.d / 2 + 2, 4)), 1,
              C('#806a60'), 1, .12, 2.5, grav=2)
    sfx('door', 1, .6)
    sfx('drum', .8, .6)


def walk_in(dt, t):
    player.move_amt = 1
    player.run += dt * 9
    player.position += Vec3(0, 0, 1) * dt * 2.2
    player.rotation_y = 0
    player.animate_body(dt)


def prologue():
    d = dungeon.d
    z0 = -d / 2
    player.position = Vec3(0, 0, z0 + 1.2)
    me = player.KIND
    line = ('hana', 'Рэн ушёл с последней экспедицией. Я найду его.') if me == 'kaze' else \
           ('samurai', 'Я выжил один. Я дойду до дна и уничтожу источник проклятия.')
    hero_pos = lambda: player.position
    shots = [
        dict(dur=5.5, cam=(Vec3(0, 5, z0 + 2), Vec3(0, 3.6, z0 + 10)), look=(Vec3(0, 3, z0 + 20), Vec3(0, 2, d / 2)),
             text='Века назад монахи нашли под землёй древнее святилище'),
        dict(dur=5.5, cam=(Vec3(-6, 1.4, z0 + 4), Vec3(-3, 1.8, z0 + 3)), look=(Vec3(-4.2, 1.6, z0 + 2.5), Vec3(4.2, 1.6, z0 + 2.5)),
             text='Его построили, чтобы запереть тех, кто вернулся из мира мёртвых'),
        dict(dur=4.0, cam=(Vec3(0, 6, 0), Vec3(0, 6.2, 2)), look=(Vec3(0, 0, 6), Vec3(0, 0, 8)),
             text='Легенда забылась. Вход — тоже'),
        dict(dur=4.5, cam=(Vec3(3, 2.4, z0 + 6), Vec3(2, 2.6, z0 + 8)), look=(Vec3(0, 3, z0), Vec3(0, 3.5, z0)),
             text='Пока землетрясение не открыло его снова', fx=falling_rocks, shake=.18),
        dict(dur=5.0, cam=(Vec3(5, 1.2, -2), Vec3(1, 1.6, -4)), look=(Vec3(4, .2, 2), Vec3(-2, .4, 3)),
             text='Экспедиции спускались одна за другой. Почти никто не вернулся'),
        dict(dur=4.5, cam=(Vec3(0, 2.4, 6), Vec3(0, 2.2, 3)), look=(Vec3(0, 2, 14), Vec3(0, 2.2, 16)),
             text='А те, кто вернулся, уже не были вполне людьми'),
        dict(dur=5.5, cam=(lambda: hero_pos() + Vec3(.9, 1.5, 4.5), lambda: hero_pos() + Vec3(.6, 1.6, 3.2)),
             look=(lambda: hero_pos() + Vec3(0, 1.5, 0), lambda: hero_pos() + Vec3(0, 1.6, 0)),
             text=line, tick=walk_in),
        dict(dur=3.2, cam=(lambda: hero_pos() + Vec3(0, 3, -5), lambda: hero_pos() + Vec3(0, 3.4, -6)),
             look=(lambda: hero_pos() + Vec3(0, 1.4, 6), lambda: hero_pos() + Vec3(0, 1.2, 8)),
             text='', fx=lambda: show_title_card()),
    ]

    def done():
        player.position = Vec3(0, 0, -dungeon.d / 2 + 2.5)
        player.move_amt = 0
        story.on_room(0, 0)
    play_cine(shots, done)


def show_title_card():
    cine_title.text = 'БЕЗДНА ПРОКЛЯТЫХ'
    cine_title.enabled = True
    cine_title.alpha = 0
    cine_title.animate_color(Color(BLOOD[0], BLOOD[1], BLOOD[2], 1), duration=.8)
    sfx('drum', .9, .8)


def start_meeting():
    """Встреча героев в большом зале: напарник уже бьётся с демонами"""
    c = make_companion(Vec3(0, 0, 4))
    c.h.rotation_y = 180
    me = player.KIND
    if me == 'kaze':
        lines = [('samurai', 'Назад! Здесь не место для... веера.'), ('hana', 'Скажи это демонам у тебя за спиной.')]
    else:
        lines = [('hana', 'Ты из экспедиции? Где остальные? Где Рэн?'), ('samurai', 'Мертвы. Или хуже. Отойди — они идут.')]
    other = lambda: c.h.position

    def swing(dt, t):
        h = c.h
        if not h.action:
            h.start(random.choice(('L1', 'L2', 'L4')), quiet=True)
        h.tick_action(dt)
        h.y = 0
        h.animate_body(dt)

    def idle(dt, t):
        c.h.move_amt = 0
        c.h.animate_body(dt)
        player.animate_body(dt)

    shots = [
        dict(dur=3.4, cam=(lambda: other() + Vec3(2.5, 1.6, -3.5), lambda: other() + Vec3(1.6, 1.5, -2.6)),
             look=(lambda: other() + Vec3(0, 1.3, 0), lambda: other() + Vec3(0, 1.4, 0)), text=lines[0], tick=swing),
        dict(dur=3.4, cam=(lambda: player.position + Vec3(-1.4, 1.6, 2.6), lambda: player.position + Vec3(-1, 1.6, 2.2)),
             look=(lambda: player.position + Vec3(0, 1.4, 0), lambda: player.position + Vec3(0, 1.5, 0)),
             text=lines[1], tick=idle),
    ]

    def done():
        story.met = True
        c.h.action = None
        burst(c.h.position + Vec3(0, 1, 0), 24, C('#2a1a2a'), 4, .25, .9, grav=-1)
        c.h.enabled = False
        if me == 'kaze':
            story.say('samurai', 'Демоны замешкались рядом с тобой. Почему?')
            story.say('hana', 'Не знаю. И тебе я тоже пока не верю.')
            story.say('samurai', 'Иди первой. Я буду рядом, в тенях. Встретишь стража — зови.')
        else:
            story.say('hana', 'Одному тут не выжить. Пойдём вместе — до дна.')
            story.say('samurai', 'Демоны замешкались рядом с тобой. Ты знаешь почему?')
            story.say('hana', 'Нет. Иди вперёд, я пойду следом, тенями.')
            story.say('hana', 'Встретишь стража — позови. Вдвоём справимся.')
    play_cine(shots, done)


# --- финал: выбор у печати
choice_root = Entity(parent=camera.ui, enabled=False)
ui_quad(parent=choice_root, scale=(4, 2), color=C('#050208', .8), z=.1)
Text(parent=choice_root, text='ПЕЧАТЬ', origin=(0, 0), y=.33, scale=3.2, color=GOLD)
choice_info = Text(parent=choice_root, text='', origin=(0, .5), y=.25, scale=1.0, color=C('#e8dcd4'))
Text(parent=choice_root, text='1 — РАЗРУШИТЬ ПЕЧАТЬ', origin=(0, 0), position=(-.3, -.2), scale=1.3, color=C('#ff7a6a'))
Text(parent=choice_root, text='души обретут покой,\nно демоны выйдут наверх', origin=(0, .5), position=(-.3, -.25),
     scale=.85, color=C('#c0a0a0'))
Text(parent=choice_root, text='2 — ВОССТАНОВИТЬ ПЕЧАТЬ', origin=(0, 0), position=(.3, -.2), scale=1.3, color=C('#8affd0'))
Text(parent=choice_root, text='Бездна закроется,\nно кто-то останется внизу', origin=(0, .5), position=(.3, -.25),
     scale=.85, color=C('#a0c0b8'))
ending_text = Text(parent=camera.ui, text='', origin=(0, 0), y=0, scale=1.25, color=C('#f0e4dc'), z=-.3, enabled=False)


def start_choice():
    game.state = 'choice'
    hud.enabled = False
    boss_root.enabled = False
    grab_mouse(False)
    choice_info.text = ('Печать трещит. Сквозь неё слышны тысячи голосов — голоса людей,\n'
                        'которые когда-то хотели победить смерть. Среди них — голос Рэна.\n'
                        'Чтобы замкнуть её снова, кто-то из рода Сирасаги или Кагэ должен остаться здесь.')
    choice_root.enabled = True
    play_track('bgm')


ENDINGS = {
    ('break', 'kaze'): [
        'Харуказэ ударила веером по последнему камню. Печать рассыпалась светом.',
        'Тысячи душ поднялись вверх — впервые за столетия они могли уйти.',
        'Среди них Харуказэ узнала голос Рэна. Он сказал: «Спасибо, сестра».',
        'Но вместе с душами наверх потянулось и то, что веками было демонами.',
        'Асахи вынул меч. «Значит, наверху будем драться вместе».'],
    ('break', 'samurai'): [
        'Асахи разрубил печать — ту самую, что строили его предки.',
        'Души поднялись к свету. Харуказэ плакала: среди них был Рэн, и он был свободен.',
        'Но голод, державший их столько веков, тоже вышел наружу.',
        'Асахи наконец вспомнил, кто он. Род Кагэ создал эту тюрьму — роду Кагэ и отвечать.',
        'Вдвоём они поднялись наверх, навстречу первой ночи нового мира.'],
    ('seal', 'kaze'): [
        'Харуказэ встала в центр печати. Кровь Сирасаги вспомнила слова, которых она никогда не учила.',
        'Камни сомкнулись. Голоса затихли. Последним затих голос Рэна — спокойный, без страха.',
        '«Иди», — сказала она Асахи. «Кто-то должен помнить, что мы были людьми».',
        'Асахи поднялся наверх один. Выход больше не был запечатан.',
        'С тех пор каждую ночь он слышит её голос под землёй. Она не зовёт его — она поёт.'],
    ('seal', 'samurai'): [
        'Асахи положил клинок в центр печати — так же, как когда-то его предок.',
        'Он вспомнил всё: имя, род, клятву. «Камень будет держать, пока жив наш род».',
        'Харуказэ держала его за руку, пока печать не забрала его целиком.',
        'Наверху она вышла одна. Рэна она так и не нашла — но голоса под землёй стихли.',
        'Иногда, проходя мимо старых храмов, Харуказэ слышит шаги. Ровные, как шаг часового.'],
}


def choose_ending(kind):
    choice_root.enabled = False
    game.state = 'ending'
    game.ending = kind
    lines = ENDINGS[(kind, player.KIND)]
    game.ending_lines = lines
    game.ending_t = 0
    game.ending_i = -1
    ending_text.enabled = True
    sfx('victory', .8, .8 if kind == 'seal' else 1.0)
    if kind == 'break':
        white.color = C('#fff4ef', 1)
        white.animate_color(C('#fff4ef', 0), duration=2.0)
        for r in range(6):
            invoke(shockring, flat(player.position), 30, GOLD, 1.2, delay=r * .25)
    else:
        for r in range(6):
            invoke(shockring, flat(player.position), 4 + r * 3, C('#8affd0', .9), .8, delay=r * .2)


def update_ending(dt):
    game.ending_t -= dt
    if game.ending_t <= 0:
        game.ending_i += 1
        if game.ending_i >= len(game.ending_lines):
            ending_text.enabled = False
            game.victory()
            return
        ending_text.text = fit_text(game.ending_lines[game.ending_i], 1.25, 1.25)
        ending_text.alpha = 0
        ending_text.animate_color(Color(.94, .9, .86, 1), duration=.8)
        game.ending_t = 5.0
    a = game.clock * .08
    tgt = player.position + Vec3(0, 1.4, 0)
    camera.position = tgt + Vec3(math.sin(a) * 9, 4 + math.sin(a * .7), math.cos(a) * 9)
    aim_camera(tgt)


def update_lanterns(dt):
    for l in dungeon.lanterns:
        lan, t, pos = l
        l[1] -= dt
        if l[1] <= 0:
            on = not lan.enabled
            lan.enabled = on
            l[1] = random.uniform(1.5, 3) if on else random.uniform(3, 8)
            if on and player is not None and dist2d(player.position, pos) < 12:
                sfx('shriek', .12, .5)



# =====================================================================
# ГОЛОВОЛОМКИ: врата к логову стража запечатаны, пока загадка не решена
# =====================================================================
TONES = [.8, 1.0, 1.19, 1.33, 1.5, 1.78]
RUNE_COLS = [C('#ff5a4a'), C('#5fe8c8'), C('#ffd060'), C('#b080ff'), C('#80b0ff'), C('#ff80c0')]
RUNE_ICONS = ['icon_sword', 'icon_wave', 'icon_moon', 'icon_swirl', 'icon_feather', 'icon_fan']


def plog(*a):
    """Журнал загадок рядом с игрой — чтобы разобрать, если что-то не сработало"""
    try:
        with open(os.path.join(HERE, 'puzzle_log.txt'), 'a', encoding='utf-8') as f:
            f.write(f'[{game.clock:8.2f}] ' + ' '.join(str(x) for x in a) + '\n')
    except Exception:
        pass


class Puzzle:
    kind = ''
    hint = ''
    verb = 'коснуться'
    REACH = 3.0

    def __init__(self, R, d):
        self.root = Entity(parent=R)
        self.cz = d / 2 - 7.5
        self.nodes = []          # (позиция, индекс)
        self.solved = False
        self.active = False
        self.t = 0
        self.marker = glow_entity(Entity(parent=R, model='diamond', scale=(.25, .4, .25), color=C('#ffd060', .9),
                                         enabled=False))
        self.press_cd = 0
        self.finishing = False

    def blockers(self):
        return [(p[0], p[2], .7) for p, i in self.nodes]

    def activate(self):
        self.active = True
        plog('activate', self.kind, 'nodes', len(self.nodes), 'player', tuple(round(v, 1) for v in player.position))
        banner('ПЕЧАТЬ НА ВРАТАХ', GOLD, 'подойди к золотой метке и жми F: ' + self.verb)
        story.say('samurai' if player.KIND == 'samurai' else 'hana', self.hint)
        sfx('door', .6, 1.3)

    def nearest(self, pos, any_state=False):
        if self.solved or self.finishing or (not self.active and not any_state):
            return None
        best, bd = None, self.REACH
        for p, i in self.nodes:
            dd = dist2d(p, pos)
            if dd < bd:
                best, bd = i, dd
        return best

    def node_pos(self, i):
        for p, k in self.nodes:
            if k == i:
                return p
        return None

    def try_press(self, pos, how):
        """Нажатие F или удар рядом с загадкой"""
        i = self.nearest(pos)
        plog('press', how, 'kind', self.kind, 'active', self.active, 'solved', self.solved, 'nearest', i,
             'player', tuple(round(v, 1) for v in pos), 'mode', getattr(self, 'mode', '-'))
        if i is None or self.press_cd > 0:
            return False
        self.press_cd = .25
        self.press(i)
        return True

    def update_marker(self, pos):
        self.press_cd = max(0, self.press_cd - time.dt)
        i = self.nearest(pos)
        if i is None:
            self.marker.enabled = False
            return
        p = self.node_pos(i)
        self.marker.enabled = True
        self.marker.position = Vec3(p[0], 2.6 + math.sin(game.clock * 4) * .12, p[2])
        self.marker.rotation_y += 120 * time.dt

    def label(self, i):
        return f'F — {self.verb}'

    def finish(self):
        self.solved = True
        self.marker.enabled = False
        plog('solved', self.kind)
        sfx('victory', .6, 1.2)
        shockring(Vec3(0, 0, self.cz), 9, GOLD, .7)
        burst(Vec3(0, 1.5, self.cz), 40, GOLD, 7, .12, .9, grav=0, glow=True)
        banner('ПЕЧАТЬ СНЯТА', GOLD)
        dungeon.open_gate()

    def tick(self, dt):
        pass

    def press(self, i):
        pass


class SimonPuzzle(Puzzle):
    """Руны вспыхивают по порядку — повтори. Ошибка будит демонов"""
    kind = 'simon'
    verb = 'коснуться руны'

    def __init__(self, R, d, n, length, speed, rnd):
        super().__init__(R, d)
        self.n, self.length, self.speed = n, length, speed
        self.hint = f'Руны вспыхивают по порядку. Повторить {length} касаний — и печать падёт. Гонг повторит узор'
        self.runes = []
        for i in range(n):
            x = (i - (n - 1) / 2) * 2.4
            z = self.cz + 1.2 - abs(i - (n - 1) / 2) * .5
            part(self.root, model='rbox', position=(x, .9, z), scale=(.9, 1.8, .55), texture='floor_stone', color=C('#9a8a84'))
            part(self.root, model='rbox', position=(x, .1, z), scale=(1.2, .2, .8), texture='floor_stone', color=C('#7a6a64'))
            g = glow_entity(Entity(parent=self.root, model='quad', texture=RUNE_ICONS[i], position=(x, 1.1, z - .3),
                                   scale=.65, color=Color(RUNE_COLS[i][0], RUNE_COLS[i][1], RUNE_COLS[i][2], .22),
                                   double_sided=True))
            self.runes.append(g)
            self.nodes.append((Vec3(x, 0, z), i))
        gx, gz = 0, self.cz - 3.2      # гонг: повторить узор
        part(self.root, model='rbox', position=(gx - .8, 1.1, gz), scale=(.15, 2.2, .15), texture='wood', color=WHITE)
        part(self.root, model='rbox', position=(gx + .8, 1.1, gz), scale=(.15, 2.2, .15), texture='wood', color=WHITE)
        part(self.root, model='rbox', position=(gx, 2.2, gz), scale=(1.9, .15, .15), texture='wood', color=WHITE)
        self.gong = part(self.root, model='circle', position=(gx, 1.3, gz), scale=1.1, color=C('#c89040'),
                         double_sided=True)
        self.nodes.append((Vec3(gx, 0, gz), 'gong'))
        self.seq = [rnd.randrange(n) for _ in range(length)]
        self.mode = 'idle'
        self.step = 0
        self.pos = 0
        self.mistakes = 0

    def label(self, i):
        return 'F — ударить в гонг (повторить узор)' if i == 'gong' else 'F — коснуться руны'

    def activate(self):
        super().activate()
        self.show(1.4)

    def show(self, delay=.6):
        self.mode = 'show'
        self.step = -1
        self.t = -delay
        self.pos = 0

    def light(self, i, on, col=None):
        c = col or RUNE_COLS[i]
        self.runes[i].color = Color(c[0], c[1], c[2], 1 if on else .22)
        self.runes[i].scale = .85 if on else .65

    def tick(self, dt):
        if self.mode != 'show':
            for i in range(self.n):
                r = self.runes[i]
                if r.scale_x > .66:
                    r.scale = max(.65, r.scale_x - dt * 1.2)
                    if r.scale_x <= .66:
                        self.light(i, False)
            return
        self.t += dt
        on_time = self.speed * .7
        k = int(self.t // self.speed) if self.t >= 0 else -1
        if k != self.step:
            if 0 <= self.step < len(self.seq):
                self.light(self.seq[self.step], False)
            self.step = k
            if 0 <= k < len(self.seq):
                self.light(self.seq[k], True)
                sfx('orb', .7, TONES[self.seq[k]])
        if 0 <= k < len(self.seq) and self.t - k * self.speed > on_time:
            self.light(self.seq[k], False)
        if k >= len(self.seq):
            self.mode = 'input'
            self.pos = 0
            popup_number(Vec3(0, 2.5, self.cz), 'твой черёд', GOLD)

    def press(self, i):
        if i == 'gong':
            sfx('drum', .6, 1.4)
            burst(Vec3(0, 1.3, self.cz - 3.2), 10, C('#ffd080'), 3, .08, .4, grav=0, glow=True)
            self.show(.3)
            return
        if self.mode != 'input':
            popup_number(Vec3(0, 2.5, self.cz), 'дождись конца узора', BONE)
            return
        plog('simon expect', self.seq[self.pos], 'got', i, 'pos', self.pos, '/', len(self.seq))
        if i == self.seq[self.pos]:
            self.light(i, True)
            sfx('orb', .7, TONES[i])
            self.pos += 1
            if self.pos >= len(self.seq):
                self.mode = 'done'
                self.finish()
        else:
            self.mistakes += 1
            for k in range(self.n):
                self.light(k, True, C('#ff2020'))
            sfx('hurt', .6, .7)
            game.shake = max(game.shake, .3)
            popup_number(Vec3(0, 2.5, self.cz), 'неверно — демоны проснулись', BLOOD)
            pool = LEVELS[dungeon.level]['pool']
            for k in range(2):
                a = random.uniform(0, math.tau)
                dungeon.spawn_enemy(pool[0], flat(player.position) + Vec3(math.sin(a), 0, math.cos(a)) * 6)
            self.mode = 'wait'
            invoke(self.show, 1.0, delay=1.4)

    def auto_solve(self):
        if self.mode == 'input':
            for i in list(self.seq[self.pos:]):
                self.press(i)


class StatuePuzzle(Puzzle):
    """Статуи-стражи должны смотреть на печать. У связанных поворачиваются и соседи"""
    kind = 'statues'
    verb = 'повернуть статую'

    def __init__(self, R, d, n, linked, rnd):
        super().__init__(R, d)
        self.n, self.linked = n, linked
        self.hint = ('Стражи должны смотреть на печать. ' +
                     ('Они связаны: поворачиваешь одного — поворачиваются и соседи' if linked else 'Поверни каждого'))
        cz = self.cz - .5
        glow_entity(Entity(parent=self.root, model='circle', rotation_x=90, position=(0, .04, cz), scale=3,
                           color=C('#e0b45a', .35), double_sided=True))
        self.seal = glow_entity(Entity(parent=self.root, model='quad', texture='icon_moon', rotation_x=90,
                                       position=(0, .06, cz), scale=1.8, color=C('#e0b45a', .6), double_sided=True))
        self.statues, self.base_angle, self.eyes = [], [], []
        self.face = [0] * n
        for i in range(n):
            a = 180 + (i - (n - 1) / 2) * (300 / max(1, n))
            r = math.radians(a)
            p = Vec3(math.sin(r) * 4.3, 0, cz + math.cos(r) * 4.3)
            part(self.root, model='rbox', position=(p[0], .25, p[2]), scale=(1.1, .5, 1.1), texture='floor_stone',
                 color=C('#8a7a74'))
            st = Entity(parent=self.root, position=(p[0], .5, p[2]))
            part(st, model='rbox', y=.6, scale=(.6, 1.2, .5), texture='floor_stone', color=C('#b0a098'))
            part(st, model='skull', y=1.45, scale=(.5, .55, .5), texture='floor_stone', color=C('#b0a098'))
            eye = glow_entity(Entity(parent=st, model='cube', position=(0, 1.5, .26), scale=(.32, .06, .04),
                                     color=C('#ff4040')))
            toward = heading_of(Vec3(0, 0, cz) - p)
            self.base_angle.append(toward)
            self.statues.append(st)
            self.eyes.append(eye)
            self.nodes.append((p, i))
        presses = []
        while all(f == 0 for f in self.face):
            presses = [rnd.randrange(n) for _ in range(n + (2 if linked else 0))]
            self.face = [0] * n
            for i in presses:
                self._turn(i, animate=False)
        self.gen = presses
        for i in range(n):
            self._pose(i, animate=False)

    def _turn(self, i, animate=True):
        ids = [i] + ([(i - 1) % self.n, (i + 1) % self.n] if self.linked and self.n > 2 else [])
        for k in ids:
            self.face[k] = (self.face[k] + 1) % 4
            self._pose(k, animate)

    def _pose(self, k, animate=True):
        target = self.base_angle[k] + self.face[k] * 90
        st = self.statues[k]
        if animate:
            st.animate_rotation_y(target, duration=.3, curve=curve.out_back)
        else:
            st.rotation_y = target
        self.eyes[k].color = C('#ffd060') if self.face[k] == 0 else C('#ff4040')

    def press(self, i):
        self._turn(i)
        sfx('clang', .5, .8 + .1 * i)
        if all(f == 0 for f in self.face):
            self.finishing = True
            invoke(self.finish, delay=.35)

    def auto_solve(self):
        for i in reversed(self.gen):
            for _ in range(3):
                if not self.solved and self.active and not self.finishing:
                    self.press(i)


class LanternPuzzle(Puzzle):
    """Фонари по кругу: касание переключает фонарь и двух соседей. Зажги все"""
    kind = 'lanterns'
    verb = 'коснуться фонаря'

    def __init__(self, R, d, n, rnd):
        super().__init__(R, d)
        self.n = n
        self.hint = 'Каждый фонарь зажигает и гасит соседей. Нужно, чтобы горели все'
        cz = self.cz - .5
        self.lit = [True] * n
        self.flames = []
        for i in range(n):
            r = math.radians(i / n * 360 + 90)
            p = Vec3(math.cos(r) * 4.2, 0, cz + math.sin(r) * 4.2)
            part(self.root, model='rbox', position=(p[0], .5, p[2]), scale=(.35, 1.0, .35), texture='floor_stone',
                 color=C('#9a8a84'))
            part(self.root, model='rbox', position=(p[0], 1.15, p[2]), scale=(.7, .3, .7), texture='floor_stone',
                 color=C('#9a8a84'))
            f = glow_entity(Entity(parent=self.root, model='orb', position=(p[0], 1.15, p[2]), scale=(.45, .25, .45),
                                   color=C('#ffb040')))
            self.flames.append(f)
            self.nodes.append((p, i))
        presses = []
        while all(self.lit):
            presses = rnd.sample(range(n), max(2, n // 2))
            self.lit = [True] * n
            for i in presses:
                self._toggle(i, show=False)
        self.gen = presses
        for i in range(n):
            self._show(i)

    def _toggle(self, i, show=True):
        for k in (i, (i - 1) % self.n, (i + 1) % self.n):
            self.lit[k] = not self.lit[k]
            if show:
                self._show(k)

    def _show(self, k):
        self.flames[k].color = C('#ffb040') if self.lit[k] else C('#201418')
        self.flames[k].scale = (.45, .25, .45) if self.lit[k] else (.3, .15, .3)

    def press(self, i):
        self._toggle(i)
        sfx('orb', .5, .9 + .08 * i)
        burst(self.nodes[i][0] + Vec3(0, 1.3, 0), 6, C('#ffb040'), 2, .08, .4, grav=-2, glow=True)
        if all(self.lit):
            self.finishing = True
            invoke(self.finish, delay=.35)

    def auto_solve(self):
        for i in list(self.gen):
            if self.active and not self.solved and not self.finishing:
                self.press(i)


def make_puzzle(level, R, d, rnd):
    kinds = [
        lambda: SimonPuzzle(R, d, 4, 3, .8, rnd),
        lambda: StatuePuzzle(R, d, 4, False, rnd),
        lambda: LanternPuzzle(R, d, 5, rnd),
        lambda: SimonPuzzle(R, d, 5, 5, .65, rnd),
        lambda: StatuePuzzle(R, d, 5, True, rnd),
        lambda: LanternPuzzle(R, d, 7, rnd),
        lambda: SimonPuzzle(R, d, 6, 7, .5, rnd),
        lambda: StatuePuzzle(R, d, 6, True, rnd),
    ]
    return kinds[min(level, len(kinds) - 1)]()


# =====================================================================
# ИГРА
# =====================================================================
HEROES = [Samurai, Kaze]


class Game:
    state = 'title'
    paused = False
    hitstop = 0.0
    shake = 0.0
    clock = 0.0
    kills = 0
    best = 0
    slowmo = 0.0
    seed = 0
    flames = []
    diff_i = 1
    diff = DIFFS[1][1]
    hero_i = 0
    ambient_mode = 'embers'
    level_start_kills = 0
    souls = 0
    level_start_souls = 0
    heals_here = 0
    switch_cd = 0.0
    cam_blend = 0.0

    # ---------- чекпоинты: после каждого стража, сохраняются между запусками
    def save_checkpoint(self, level):
        try:
            import json
            with open(SAVE_FILE, 'w', encoding='utf-8') as f:
                json.dump(dict(level=level, hero=self.hero_i, diff=self.diff_i, souls=self.souls, kills=self.kills),
                          f)
        except Exception:
            pass

    def load_checkpoint(self):
        try:
            import json
            with open(SAVE_FILE, encoding='utf-8') as f:
                d = json.load(f)
            if 0 < int(d['level']) < len(LEVELS):
                return d
        except Exception:
            pass
        return None

    def clear_checkpoint(self):
        try:
            os.remove(SAVE_FILE)
        except Exception:
            pass

    def new_game(self, from_pause=False):
        """Новая игра с первого яруса. Если есть чекпоинт — сперва спрашиваем: второе нажатие подтверждает"""
        d = self.load_checkpoint()
        if d and time_now() - getattr(self, 'new_confirm', -99) > 4:
            self.new_confirm = time_now()
            banner('НАЧАТЬ ЗАНОВО?', GOLD, f'чекпоинт на ярусе {int(d["level"]) + 1} удалится  ·  нажми ещё раз',
                   z=-.35)
            sfx('door', .4, 1.4)
            return
        self.new_confirm = -99
        self.clear_checkpoint()
        if from_pause:
            self.paused = False
            pause_root.enabled = False
        self.start(0)

    def continue_save(self):
        d = self.load_checkpoint()
        if not d or self.state != 'select':
            return
        self.hero_i = int(d.get('hero', 0)) % len(HEROES)
        self.set_diff(int(d.get('diff', self.diff_i)) % len(DIFFS))
        self.souls = int(d.get('souls', 0))
        self.kills = int(d.get('kills', 0))
        self.start(int(d['level']), keep_kills=True)

    def refresh_continue(self):
        d = self.load_checkpoint()
        cont_root.enabled = d is not None
        if d:
            set_text(cont_info, f'ярус {int(d["level"]) + 1}  ·  {HEROES[int(d.get("hero", 0)) % len(HEROES)].NAME.lower()}'
                                f'  ·  {d.get("souls", 0)} душ')

    def heal_cost(self):
        return HEAL_COST          # всегда 100 душ, на любом уровне и сколько угодно раз

    def load_best(self):
        try:
            with open(BEST_FILE) as f:
                self.best = int(f.read().strip() or 0)
        except Exception:
            self.best = 0

    def save_best(self):
        try:
            with open(BEST_FILE, 'w') as f:
                f.write(str(self.best))
        except Exception:
            pass

    # ---------- выбор героя
    def to_select(self):
        global player
        self.state = 'select'
        title_root.enabled = False
        over_root.enabled = False
        pause_root.enabled = False
        boss_root.enabled = False
        hud.enabled = False
        select_root.enabled = True
        grab_mouse(False)
        play_track('bgm')
        if player is not None:
            player.enabled = False
        drop_companion()
        story.reset()
        prompt.enabled = False
        if dungeon.level != 0 or dungeon.room != 0 or self.showroom_dirty:
            self.enter_room(0, 0, intro=False)
            self.showroom_dirty = False
        for e in enemies[:]:
            if gone(e):
                continue
            destroy(e)
        enemies.clear()
        for i, h in enumerate(previews):
            h.enabled = True
            h.position = Vec3(-1.1 + i * 2.2, 0, 3)
            h.rotation_y = 180
        sel_spot.enabled = True
        self.pick_hero(0)
        self.set_diff(self.diff_i)
        self.sel_snap = True
        self.refresh_continue()

    def pick_hero(self, step):
        self.hero_i = (self.hero_i + step) % len(HEROES)
        H = HEROES[self.hero_i]
        # имя: если длинное — уменьшаем, чтобы влезло в панель
        sc = 2.4
        while sc > 1.2 and text_w(H.NAME, sc) > SEL_TW:
            sc -= .1
        sel_name.scale = sc
        sel_name.text = H.NAME
        sel_name.color = H.FX_GLOW if H.KIND == 'kaze' else BLOOD
        y = SEL_TOP - text_h('x', sc) * .95
        sel_title.y = y
        sel_title.text = fit_text(H.TITLE, SEL_TW, sel_title.scale_x)
        y -= text_h(sel_title.text, sel_title.scale_x) + .012
        sel_desc.y = y
        sel_desc.text = fit_text(H.DESC, SEL_TW, sel_desc.scale_x)
        y -= text_h(sel_desc.text, sel_desc.scale_x) + .03
        for (lbl, f, bg), (nm, v) in zip(sel_bars, H.STATS):
            lbl.text = nm
            lbl.y = f.y = bg.y = y
            f.scale_x = .34 * v
            f.color = Color(H.FX1[0], H.FX1[1], H.FX1[2], 1)
            y -= .03
        y -= .006
        sel_moves_head.y = y
        y -= text_h('x', sel_moves_head.scale_x) + .004
        sel_moves.y = y
        lines = []
        for k, v in H.MOVES:
            lines.append(fit_text(f'{k}  —  {v}', SEL_TW, sel_moves.scale_x).replace('\n', '\n      '))
        sel_moves.text = '\n'.join(lines)
        for i, (b, fr, ic, nm, mark) in enumerate(hero_cards):
            on = i == self.hero_i
            ui_set_border(fr, BRONZE_HI if on else BRONZE)
            mark.enabled = on
            nm.color = GOLD_T if on else MUTED
            ic.color = GOLD_T if on else MUTED
            b.color = C('#1a2030', .9) if on else C('#0c0e13', .86)
        if step:
            sfx('slash', .4, 1.3)

    def set_diff(self, i):
        self.diff_i = i
        self.diff = DIFFS[i][1]
        for k in range(len(DIFFS)):
            b, t, fr = ui_buttons[f'diff{k}']
            b.color = BTN_RED if k == i else BTN
            t.color = GOLD_T if k == i else TXT
            ui_set_border(fr, BRONZE_HI if k == i else BRONZE)

    # ---------- забег
    def enter_room(self, level, room, intro=True):
        self.flames = []
        if room == 0:
            self.heals_here = 0
        dungeon.build(level, room)
        dungeon.transit = False
        if player is not None:
            player.position = Vec3(0, 0, -dungeon.d / 2 + 2.5)
            player.rotation_y = 0
            player.action = None
            camera.position = player.position + Vec3(0, 3, -6)
        cam.yaw = 0
        cam.pivot = None
        if player is not None and companion[0] is not None:
            companion[0].place(player.position + Vec3(1.6, 0, -.5))
        L = LEVELS[level]
        room_text.text = f'{level + 1}. {L["name"]}'
        wave_text.text = 'ЛОГОВО ВЛАДЫКИ' if dungeon.boss_room else f'зал {room + 1} из {ROOMS_PER_LEVEL - 1}'
        if intro and room == 0:
            banner(f'ЯРУС {level + 1} ИЗ {len(LEVELS)}', BLOOD, L['name'].lower() + '  ·  здесь: ' + L['foes'])
        if intro and player is not None and not (level == 0 and room == 0 and getattr(self, 'intro', False)):
            story.on_room(level, room)

    def start(self, level=0, keep_kills=False):
        global player
        if player is not None:
            destroy(player)
        drop_companion()
        story.reset()
        player = HEROES[self.hero_i]()
        self.intro = (level == 0 and not keep_kills)
        for h in previews:
            h.enabled = False
        sel_spot.enabled = False
        if level == 0 and not keep_kills:
            self.kills = 0
            self.souls = 0
        self.level_start_kills = self.kills
        self.level_start_souls = self.souls
        self.state = 'play'
        self.paused = False
        self.showroom_dirty = True
        for r in (title_root, over_root, pause_root, boss_root, select_root):
            r.enabled = False
        hud.enabled = True
        diff_lbl.text = DIFFS[self.diff_i][0].lower()
        grab_mouse(True)
        cam.yaw = 0
        cam.pitch = 14
        cam.pivot = None
        self.seed = random.randint(0, 9999)
        if level > 0:
            story.met = True
            make_companion(Vec3(1.5, 0, -10)).h.enabled = False
        apply_hero_ui(player)
        self.switch_cd = 0
        self.enter_room(level, 0)
        if self.intro:
            prologue()

    def advance(self):
        lvl, room = dungeon.level, dungeon.room + 1
        if room >= ROOMS_PER_LEVEL:
            lvl, room = lvl + 1, 0
            self.level_start_kills = self.kills
            self.level_start_souls = self.souls
        if lvl >= len(LEVELS):
            self.victory()
            return
        fader.animate_color(C('#000000', 1), duration=.35)

        def swap():
            self.enter_room(lvl, room)
            fader.animate_color(C('#000000', 0), duration=.45)
        invoke(swap, delay=.4)

    def boss_down(self, boss):
        sfx('victory', .9)
        last = dungeon.level == len(LEVELS) - 1
        banner('СТРАЖ ПОВЕРЖЕН', GOLD, 'печать открыта' if last else 'путь вглубь открыт')
        if not last:
            self.save_checkpoint(dungeon.level + 1)
            invoke(popup_number, player.position + Vec3(0, 2.8, 0), 'чекпоинт сохранён', GOLD, delay=1.2)
        if dungeon.level == 0 and companion[0] is not None and story.met:
            invoke(banner, 'СМЕНА ГЕРОЕВ ОТКРЫТА', GOLD, '1 / 2 / Tab — менять героя можно в любой момент', delay=2.6)
        self.slowmo = 1.5
        invoke(switch_back_to_main, delay=1.4)
        if last:
            invoke(start_choice, delay=3.0)
        player.hp = min(player.max_hp, player.hp + int(player.max_hp * .4))
        for e in enemies[:]:
            if gone(e):
                continue
            e.die()

    def finish_screen(self, title, col, info, hint):
        if self.kills > self.best:
            self.best = self.kills
            self.save_best()
        over_title.text = title
        over_title.color = col
        over_info.text = info
        over_hint.text = hint
        over_root.enabled = True
        hud.enabled = False
        boss_root.enabled = False
        grab_mouse(False)

    def victory(self):
        self.state = 'victory'
        self.clear_checkpoint()
        title = 'ПЕЧАТЬ РАЗРУШЕНА' if getattr(self, 'ending', '') == 'break' else 'ПЕЧАТЬ ВОССТАНОВЛЕНА'
        self.finish_screen(title, GOLD,
                           f'Бездна пройдена  ·  {DIFFS[self.diff_i][0].lower()}  ·  изгнано демонов: {self.kills}'
                           f'  ·  рекорд: {self.best}', 'ЛКМ или Enter — к выбору героя')
        sfx('victory', 1)

    def game_over(self):
        self.state = 'over'
        fell = 'ПАЛА' if player.KIND == 'kaze' else 'ПАЛ'
        rv = (f'Пробел — воскреснуть за {REVIVE_COST} душ   ·   ' if self.souls >= REVIVE_COST else
              f'для воскрешения нужно {REVIVE_COST} душ (есть {self.souls})   ·   ')
        self.finish_screen(f'{player.NAME} {fell}', BLOOD,
                           f'{dungeon.level + 1}. {LEVELS[dungeon.level]["name"]}  ·  изгнано демонов: {self.kills}'
                           f'  ·  рекорд: {self.best}',
                           rv + 'Enter — заново ярус   ·   R — к выбору героя')
        burst(player.position + Vec3(0, 1, 0), 40, BLOOD, 7, .15, 1)
        player.enabled = False

    def revive(self):
        """Воскрешение на месте за души: половина здоровья, неуязвимость и взрыв, отталкивающий демонов"""
        if self.state != 'over' or self.souls < REVIVE_COST or player is None:
            return
        self.souls -= REVIVE_COST
        self.state = 'play'
        over_root.enabled = False
        hud.enabled = True
        if dungeon.boss_room and not dungeon.cleared and any(e.boss for e in enemies):
            boss_root.enabled = True
        grab_mouse(True)
        player.enabled = True
        player.hp = int(player.max_hp * .6)
        player.inv = 3.0
        player.action = None
        player.hurt_t = 0
        if companion[0] is not None and companion[0].h.hp <= 0:
            companion[0].h.hp = int(companion[0].h.max_hp * .3)
        c = Vec3(player.x, 0, player.z)
        for e in enemies[:]:
            if gone(e):
                continue
            v = flat(e.position) - c
            if v.length() < 6:
                e.take(int(40 * (1 + .3 * dungeon.level)), False, (v.normalized() if v.length() > .01 else
                                                                    Vec3(0, 0, 1)) * 9)
        for e in [p for p in fireballs[:]]:
            try:
                if dist2d(e.position, c) < 8:
                    fireballs.remove(e)
                    destroy(e)
            except Exception:
                pass
        shockring(c, 7, GOLD, .5)
        shockring(c, 4.5, player.FX1, .4)
        burst(c + Vec3(0, 1, 0), 40, C('#ffe0a0'), 7, .12, .9, grav=-2, glow=True)
        add_flash(c + Vec3(0, 1.5, 0), (1, .85, .5), 12, .6)
        banner('ВОСКРЕШЕНИЕ', GOLD, f'-{REVIVE_COST} душ')
        sfx('orb', .9, .6)
        game.shake = .5

    def toggle_pause(self):
        self.paused = not self.paused
        pause_root.enabled = self.paused
        grab_mouse(not self.paused)


game = Game()
game.showroom_dirty = False
game.load_best()
dungeon = Dungeon()
previews = [H() for H in HEROES]
for h in previews:
    h.enabled = False
make_hero_cards()
sel_spot = glow_entity(Entity(model='circle', rotation_x=90, scale=1.9, color=C('#ff4040', .35), double_sided=True,
                              enabled=False))
title_best.text = f'рекорд: {game.best}' if game.best else ''
game.enter_room(0, 0, intro=False)
room_text.text = ''
hud.enabled = False
# =====================================================================
# ЗАСТАВКА: ВРАТА В ПОДЗЕМЕЛЬЕ — по нажатию створки распахиваются и камера влетает внутрь
# =====================================================================
G0 = Vec3(0, 0, -90)
GATE = dict(state='idle', t=0.0)


def build_gate():
    R = Entity(position=G0)
    GATE['root'] = R
    stone = dict(texture='wall_brick', color=C('#8a7a78'))
    # земля и скалы вокруг входа
    part(R, model='cube', position=(0, -.1, 8), scale=(46, .2, 60), texture='floor_stone', color=C('#9a8a88'),
         texture_scale=(12, 15))
    for side in (-1, 1):
        part(R, model='cube', position=(side * 11.6, 6, 1.2), scale=(16, 14, 3), texture_scale=(6, 5), **stone)
        part(R, model='cube', position=(side * 20, 9, 6), rotation_y=side * 25, scale=(10, 20, 4), texture='lava_rock',
             color=C('#5a4a4a'), texture_scale=(3, 6))
    part(R, model='cube', position=(0, 11.5, 1.2), scale=(8, 5, 3), texture_scale=(3, 2), **stone)
    # арка: колонны, перекладина, рогатый череп-страж над входом
    for side in (-1, 1):
        part(R, model='rbox', position=(side * 3.6, 4.4, 0), scale=(1.6, 8.8, 1.9), texture='obsidian',
             color=C('#b0a0a0'), texture_scale=(1, 4))
        part(R, model='rbox', position=(side * 3.6, .35, 0), scale=(2.1, .7, 2.3), texture='obsidian', color=WHITE)
        chain(R, 7, .45, .32, .08, (-14, 0, -22 * side), 'horn', WHITE, first_rot=(0, 0, -50 * side))[0].position = \
            (side * 1.6, 9.9, -.6)
    part(R, model='rbox', position=(0, 9.1, 0), scale=(9.4, 1.5, 2.2), texture='obsidian', color=C('#c0b0b0'))
    part(R, model='skull', position=(0, 9.5, -1.0), scale=(1.5, 1.7, 1.4), texture='skin_bone', color=C('#d8ccc0'))
    for x in (-.3, .3):
        glow_entity(Entity(parent=R, model='orb', position=(x, 9.75, -1.66), scale=(.26, .18, .1),
                           color=C('#ff3a20')))
    # створки: шарниры по краям проёма, дерево, железные полосы и заклёпки
    GATE['leaves'] = []
    for side in (-1, 1):
        pv = Entity(parent=R, position=(side * 2.8, 0, 0))
        w = Entity(parent=pv)
        part(w, model='rbox', position=(-side * 1.4, 3.85, 0), scale=(2.8, 7.7, .38), texture='wood',
             color=C('#6a4636'), texture_scale=(1, 3))
        for y in (1.1, 3.85, 6.6):
            part(w, model='rbox', position=(-side * 1.4, y, -.2), scale=(2.84, .22, .1), texture='metal', color=WHITE)
            for k in range(5):
                part(w, model='orb', position=(-side * (.3 + k * .55), y, -.27), scale=.12, texture='metal',
                     color=C('#d0b080'))
        part(w, model='rbox', position=(-side * .25, 3.85, -.22), scale=(.18, 7.6, .1), texture='metal', color=WHITE)
        ring = part(w, model='circle', position=(-side * .55, 3.2, -.26), scale=.45, texture='metal',
                    color=C('#c0a070'), double_sided=True)
        GATE['leaves'].append((pv, side))
    # печать на стыке створок
    GATE['seal'] = glow_entity(Entity(parent=R, model='quad', texture='decal_ring', position=(0, 4.3, -.3),
                                      scale=3.6, color=C('#ff3020', .85), double_sided=True))
    GATE['seal2'] = glow_entity(Entity(parent=R, model='quad', texture='icon_moon', position=(0, 4.3, -.31),
                                       scale=1.6, color=C('#ff6040', .9), double_sided=True))
    # проход внутрь: стены, потолок, факелы и багровый свет в глубине
    for side in (-1, 1):
        part(R, model='cube', position=(side * 3.4, 4, 17), scale=(1, 8, 32), texture_scale=(12, 3), **stone)
    part(R, model='cube', position=(0, 8.2, 17), scale=(7.8, .5, 32), texture='wall_brick', color=C('#5a4a48'),
         texture_scale=(3, 12))
    n0 = len(LT.torches)
    for k, z in enumerate((5, 12, 19, 26)):
        side = -1 if k % 2 == 0 else 1
        dungeon.make_torch(R, Vec3(side * 2.75, 3.0, z), (1.0, .4, .16), side)
    GATE['deep'] = glow_entity(Entity(parent=R, model='quad', texture='glow', position=(0, 3.5, 32), scale=14,
                                      color=C('#ff2010', .7)))
    for side in (-1, 1):
        dungeon.make_brazier(R, Vec3(side * 5.6, 0, -2.2), (1.0, .45, .18))
    for t in LT.torches[n0:]:            # факелы строились в координатах ворот — переводим в мировые
        t[0] = t[0] + G0
    LT.torches.append([G0 + Vec3(0, 3.5, 14), (2.2, .35, .15), 18, 0])
    GATE['inner'] = LT.torches[-1]
    # летающие глаза сторожат вход
    GATE['eyes'] = []
    for cls, pos, h in ((WingedDemon, Vec3(-3.4, 0, -3.0), 4.4), (KarasuTengu, Vec3(3.8, 0, -2.4), 5.4)):
        e = cls(G0 + pos, 0)
        e.rotation_y = 180
        e.y = h
        e.base_y = h
        enemies.append(e)
        GATE['eyes'].append(e)


build_gate()
CAM_GATE = G0 + Vec3(0, 2.6, -13.5)
camera.position = CAM_GATE


def open_gate_intro():
    if GATE['state'] == 'idle':
        GATE['state'] = 'opening'
        GATE['t'] = 0.0
        sfx('door', .9, .7)
        sfx('roar', .5, .6)
        game.shake = .25
        for side in (-1, 1):
            burst(G0 + Vec3(side * 1.4, .3, -.4), 14, C('#6a5a50'), 3, .2, .9, grav=-1)
    elif GATE['state'] == 'opening' and GATE['t'] > .3:
        GATE['t'] = max(GATE['t'], 1.75)        # повторное нажатие — сразу внутрь


def update_gate(dt):
    for e in GATE['eyes']:
        if e.enabled:
            e.y = e.base_y + math.sin(game.clock * 1.6 + e.base_y) * .25
    st = GATE['state']
    if st == 'idle':
        k = game.clock
        pos = CAM_GATE + Vec3(math.sin(k * .25) * .8, math.sin(k * .4) * .15, 0)
        camera.position = lerp(camera.position, pos, min(1, dt * 2))
        aim_camera(G0 + Vec3(0, 4.2, 0))
        return
    GATE['t'] += dt
    t = GATE['t']
    # створки распахиваются внутрь
    u = smooth(min(1, t / 1.25))
    for pv, side in GATE['leaves']:
        pv.rotation_y = side * 102 * u ** 1.3
    a = max(0, 1 - t / .5)
    GATE['seal'].alpha = .85 * a
    GATE['seal2'].alpha = .9 * a
    inner = GATE['inner']
    inner[1] = (2.2 + 2.5 * u, .35 + .4 * u, .15)
    if t < .1:
        add_flash(G0 + Vec3(0, 4, 1), (1, .3, .15), 12, .6)
    # резкий пролёт внутрь
    r = max(0.0, (t - .95) / .85)
    if r > 0:
        title_root.enabled = False
        rr = r ** 2.4
        camera.position = lerp(CAM_GATE, G0 + Vec3(0, 2.4, 26), rr) + Vec3(random.uniform(-1, 1),
                                                                         random.uniform(-1, 1), 0) * .06 * r
        camera.fov = 70 + 32 * rr
        aim_camera(camera.position + Vec3(0, -.1, 5))
        if random.random() < .6:
            burst(camera.position + Vec3(random.uniform(-3, 3), random.uniform(-2, 2), 6), 1, C('#ff5a30'), 9, .07,
                  .3, grav=0, glow=True)
    else:
        camera.position = lerp(camera.position, CAM_GATE + Vec3(0, 0, -.3 * u), min(1, dt * 3)) + \
            Vec3(random.uniform(-1, 1), random.uniform(-1, 1), 0) * game.shake * .15
        game.shake = max(0, game.shake - dt * .3)
        aim_camera(G0 + Vec3(0, 4.2 - 1.2 * u, 0))
    if t > 1.62 and fader.alpha < .99:
        fader.alpha = min(1, (t - 1.62) / .18)
    if t > 1.85 and GATE['state'] != 'done':
        GATE['state'] = 'done'
        camera.fov = 70
        GATE['root'].enabled = False
        game.to_select()
        fader.alpha = 1
        fader.animate_color(C('#000000', 0), duration=.6)


# ---------- атмосфера: угольки, светлячки, снег, лепестки
AMBIENT = {
    'embers': (C('#ff4a3d'), 1),
    'fireflies': (C('#d8ff8a'), 0),
    'snow': (C('#f4f8ff'), -1),
    'petals': (C('#ff6a80'), -1),
    'spores': (C('#b080ff'), 0),
}
ambient = []
for _ in range(90):
    q = glow_entity(Entity(model='quad', texture='glow', billboard=True, scale=.12))
    ambient.append([q, random.uniform(.4, 1.2), random.uniform(0, 6)])


def update_ambient(dt):
    col, up = AMBIENT.get(game.ambient_mode, AMBIENT['embers'])
    center = player.position if (player is not None and player.enabled) else camera.position
    for a in ambient:
        q, sp, ph = a
        q.color = Color(col[0], col[1], col[2], .45 + .45 * math.sin(game.clock * 2 + ph) ** 2)
        if up == 1:
            q.y += sp * dt
            q.x += math.sin(game.clock + ph) * dt * .4
            q.scale = .1
        elif up == 0:
            q.position += Vec3(math.sin(game.clock * .7 + ph), math.sin(game.clock * 1.3 + ph) * .3,
                               math.cos(game.clock * .9 + ph)) * dt * .8
            q.scale = .14
        else:
            q.y -= sp * dt * (1.2 if game.ambient_mode == 'snow' else .7)
            q.x += math.sin(game.clock * 1.5 + ph) * dt * .8
            q.scale = .09 if game.ambient_mode == 'snow' else .13
        if q.y > 8 or q.y < 0 or dist2d(q.position, center) > 22:
            q.position = center + Vec3(random.uniform(-20, 20), random.uniform(.2, 7.5) if up == 0 else
                                       (0.1 if up == 1 else 7.5), random.uniform(-20, 20))


def update_flames(dt):
    for f1, f2, halo, seed in game.flames:
        k = 1 + .15 * math.sin(game.clock * 11 + seed) + .08 * math.sin(game.clock * 23 + seed * 2)
        f1.scale = 1.0 * k
        f2.scale = .42 * k
        halo.scale = 3.2 * (.92 + .08 * k)


def update_select(dt):
    H = previews[game.hero_i]
    for i, h in enumerate(previews):
        h.move_amt = 0
        target = 180 + (math.sin(game.clock * .6) * 12 if i == game.hero_i else 0)
        h.rotation_y = lerp_angle(h.rotation_y, target, min(1, dt * 3))
        h.animate_body(dt)
    # общий план: оба героя в зале правее панели, выбранный под светом
    sel_spot.position = Vec3(H.x, .03, H.z)
    sel_spot.scale = 1.9 + .08 * math.sin(game.clock * 3)
    sel_spot.color = Color(H.FX_GLOW[0], H.FX_GLOW[1], H.FX_GLOW[2], .35)
    mid = Vec3(sum(h.x for h in previews) / len(previews), 0, 3)
    # герои — в свободной части экрана между панелью слева и краем справа.
    # FOV в Ursina горизонтальный: на расстоянии D в одном метре AR / (1.4·D) экранных единиц
    k = .19
    D = AR / (1.4 * k)
    sx = ((-EDGE + SEL_W) + EDGE) / 2
    shift = Vec3(-sx / k, 0, 0)
    want = mid + shift + Vec3(0, 1.35, -D)
    if getattr(game, 'sel_snap', False):
        camera.position = want
        game.sel_snap = False
    camera.position = lerp(camera.position, want, min(1, dt * 4))
    aim_camera(mid + shift + Vec3(0, 1.12, 0))


def update():
    real_dt = time.dt
    game.clock += real_dt
    update_flames(real_dt)
    update_ambient(real_dt)

    if game.state == 'title':
        title_hint.alpha = .55 + .45 * math.sin(game.clock * 4)
        for e in enemies:
            e.phase += real_dt
            e.anim(real_dt)
        update_gate(real_dt)
        update_particles(real_dt)
        update_lights(real_dt)
        return
    if game.state == 'select':
        update_select(real_dt)
        update_lights(real_dt)
        return
    update_lanterns(real_dt)
    if game.state == 'cine':
        update_particles(real_dt)
        update_cine(real_dt)
        if companion[0] is not None and companion[0].h.enabled:
            companion[0].h.animate_body(real_dt)
        update_lights(real_dt)
        return
    if game.state in ('read', 'choice'):
        update_lights(real_dt)
        return
    if game.state == 'ending':
        update_particles(real_dt)
        update_ending(real_dt)
        update_lights(real_dt)
        return
    if game.state in ('over', 'victory'):
        update_particles(real_dt)
        update_camera(real_dt)
        update_lights(real_dt)
        return
    if game.paused:
        return

    dt = real_dt
    if game.slowmo > 0:
        game.slowmo -= real_dt
        dt = real_dt * .3

    update_particles(dt)

    if ult.active:
        update_ult(real_dt)
        apply_shake(real_dt)
        for o in orbs[:]:
            o.tick(dt)
        update_lights(real_dt)
        return

    if game.hitstop > 0:
        game.hitstop -= real_dt
        update_camera(real_dt)
        apply_shake(real_dt)
        update_lights(real_dt)
        return

    player.tick(dt)
    game.switch_cd = max(0.0, game.switch_cd - real_dt)
    story.update(real_dt)
    t = nearest_tablet()
    pzl = dungeon.puzzle
    pz = pzl.nearest(player.position) if pzl is not None else None
    early = pzl is not None and not pzl.active and not pzl.solved and pzl.nearest(player.position, True) is not None
    if pzl is not None:
        pzl.update_marker(player.position)
    prompt.enabled = t is not None or pz is not None or early
    if pz is not None:
        set_text(prompt, pzl.label(pz))
    elif early:
        set_text(prompt, 'печать спит — сначала одолей демонов в зале')
    elif t is not None:
        set_text(prompt, 'F — прочитать надпись' if t.kind == 'stone' else 'F — прочитать записку')
    for e in enemies[:]:
        if gone(e):
            continue
        e.tick(dt)
    for lst in (orbs, waves, fireballs, hazards):
        for o in lst[:]:
            o.tick(dt)
    dungeon.tick(dt)

    update_camera(real_dt)
    apply_shake(real_dt)
    update_lights(real_dt)
    update_hud(real_dt)


RANKS = [(100, 'SSS'), (75, 'SS'), (50, 'S'), (35, 'A'), (20, 'B'), (10, 'C'), (5, 'D')]


def update_hud(dt=0):
    f = max(0, player.hp) / player.max_hp
    hp_fill.scale_x = HPW * f
    hp_lag.scale_x = max(HPW * f, hp_lag.scale_x - dt * .25)
    hp_fill.color = C('#d7263a') if f > .3 else Color(1, .2 + .2 * math.sin(game.clock * 10), .2, 1)
    set_text(hp_text, f'{int(max(0, player.hp))} / {player.max_hp}')
    energy_fill.scale_x = HPW * player.energy / 100
    set_text(kills_text, str(game.kills))
    if player.combo >= 3:
        set_text(combo_text, f'{player.combo} ударов')
        set_text(rank_text, next((r for n, r in RANKS if player.combo >= n), ''))
    else:
        set_text(combo_text, '')
        set_text(rank_text, '')
    left = len(dungeon.waves) - dungeon.wave_i
    if not dungeon.boss_room:
        pzl = dungeon.puzzle
        if pzl is not None and pzl.active and not pzl.solved and not dungeon.cleared:
            status = 'загадка: ' + {'simon': 'повтори узор рун', 'statues': 'поверни стражей к печати',
                                    'lanterns': 'зажги все фонари'}[pzl.kind]
        else:
            status = 'путь открыт' if dungeon.cleared else f'демонов: {len(enemies)}  ·  волн впереди: {left}'
        set_text(wave_text, f'зал {dungeon.room + 1} из {ROOMS_PER_LEVEL - 1}  ·  ' + status)
    btn_attack.update(0, 1)
    btn_heavy.update(player.heavy_cd, 1.0)
    btn_skill.update(player.skill_cd, player.SKILL_CD)
    btn_range.root.enabled = bool(player.RANGED_CD)
    if player.RANGED_CD:
        btn_range.update(player.range_cd, player.RANGED_CD)
    btn_dash.update(player.dash_cd, .65)
    btn_ult.update(0, 1, player.energy / 100, glow=player.energy >= 100)
    cost = game.heal_cost()
    btn_heal.update(player.heal_cd, HEAL_CD, min(1, game.souls / cost), glow=game.souls >= cost and
                    player.heal_cd <= 0 and player.hp < player.max_hp * .5)
    if game.souls < cost and player.heal_cd <= 0:
        btn_heal.icon.alpha = .35
    set_text(heal_cost, f'{cost} душ')
    set_text(souls_text, f'души: {game.souls}')
    minimap.update()
    update_party()


def input(key):
    if key == 'f11':
        window.fullscreen = not window.fullscreen
        return
    if key == 'f10':
        application.quit()
        return
    if key == 'f9':
        set_graphics(not GFX['safe'])
        banner('ПРОСТАЯ ГРАФИКА' if GFX['safe'] else 'ФАКЕЛЬНАЯ ГРАФИКА', BONE)
        return
    if game.state == 'title':
        if key in ('enter', 'left mouse down', 'space'):
            open_gate_intro()
        return
    if game.state == 'select':
        if key in ('a', 'left arrow'):
            game.pick_hero(-1)
        elif key in ('d', 'right arrow'):
            game.pick_hero(1)
        elif key in ('1', '2', '3'):
            game.set_diff(int(key) - 1)
        elif key == 'enter':
            game.new_game()
        elif key == 'c':
            game.continue_save()
        return
    if game.state == 'cine':
        if key in ('space', 'enter', 'escape', 'left mouse down') and cine.skippable:
            end_cine()
        return
    if game.state == 'read':
        if key in ('f', 'enter', 'escape', 'left mouse down', 'space'):
            close_tablet()
        return
    if game.state == 'choice':
        if key == '1':
            choose_ending('break')
        elif key == '2':
            choose_ending('seal')
        return
    if game.state == 'ending':
        if key in ('space', 'enter', 'left mouse down'):
            game.ending_t = 0
        return
    if game.state == 'victory':
        if key in ('enter', 'left mouse down'):
            game.to_select()
        return
    if game.state == 'over':
        if key == 'space':
            game.revive()
        elif key == 'enter':
            game.kills = game.level_start_kills
            game.souls = game.level_start_souls
            game.start(dungeon.level, keep_kills=True)
        elif key == 'r':
            game.to_select()
        return
    if key == 'escape':
        if not ult.active:
            game.toggle_pause()
        return
    if game.paused:
        if key == 'm':
            game.paused = False
            game.to_select()
        elif key == 'n':
            game.new_game(from_pause=True)
        return
    if ult.active:
        return
    if key == 'scroll up':
        cam.want_dist = max(3.0, cam.want_dist - .5)
    elif key == 'scroll down':
        cam.want_dist = min(9.0, cam.want_dist + .5)
    elif key == 'left mouse down':
        player.press_light()
    elif key == 'right mouse down':
        player.press_heavy()
    elif key == 'e':
        player.skill()
    elif key == 'r':
        player.ranged()
    elif key == 'q':
        start_ult()
    elif key == 'h':
        player.heal()
    elif key in ('1', '2', 'tab'):
        want = {'1': 0, '2': 1}.get(key)
        cur = 0 if player.KIND == HEROES[game.hero_i].KIND else 1
        if want is None or want != cur:
            switch_hero()
    elif key == 'f':
        if dungeon.puzzle is not None and dungeon.puzzle.try_press(player.position, 'F'):
            return
        t = nearest_tablet()
        if t is not None:
            open_tablet(t)
    elif key in ('shift', 'left shift', 'right shift'):
        player.dash()
    elif key == 'space':
        player.jump()


update_lights(0)

# Ursina ищет update/input в модуле, который был главным при его загрузке.
# При запуске через CrimsonBlade.exe это лаунчер, поэтому передаём функции туда
try:
    import ursina.main as _um
    _um.__main__.update = update
    _um.__main__.input = input
except Exception:
    pass

app.run()
