@echo off
chcp 65001 >nul
cd /d "%~dp0"

rem Ищем настоящий Python: сначала лаунчер py, потом python (не заглушку из Store)
set PY=
where py >nul 2>nul && set PY=py
if not defined PY (
  python -c "import sys" >nul 2>nul && set PY=python
)
if not defined PY (
  echo Python не найден. Поставь его с python.org и отметь "Add python.exe to PATH"
  pause
  exit /b
)

%PY% -m pip install -r requirements.txt
%PY% game.py
pause
