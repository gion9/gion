"""Аниме-модели героев: гладкие формы, cel-shading и контур

Всё собирается кодом: тела вращения, пряди волос вдоль кривых, ткань-оболочки.
Вся геометрия одного сустава сливается в один меш с цветами вершин,
поэтому на героя выходит ~60 сущностей вместо сотни кубиков.
Скелет (суставы и их позиции) тот же, что в game.py, так что все анимации работают
"""
import math
from ursina import Entity, Mesh, Vec4, Color
from ursina.shader import Shader

TAU = math.tau


# =====================================================================
# шейдеры: двухтоновый cel-shading и контур «вывернутой оболочкой»
# =====================================================================
TOON_VERT = '''#version 140
uniform mat4 p3d_ModelViewProjectionMatrix;
uniform mat4 p3d_ModelMatrix;
in vec4 p3d_Vertex;
in vec3 p3d_Normal;
in vec4 p3d_Color;
out vec4 vcol;
out vec3 wpos;
out vec3 wnorm;
void main() {
    gl_Position = p3d_ModelViewProjectionMatrix * p3d_Vertex;
    vcol = p3d_Color;
    wpos = (p3d_ModelMatrix * p3d_Vertex).xyz;
    wnorm = mat3(p3d_ModelMatrix) * p3d_Normal;
}
'''

TOON_FRAG = '''#version 140
uniform vec4 p3d_ColorScale;
in vec4 vcol;
in vec3 wpos;
in vec3 wnorm;
out vec4 frag;
uniform vec4 L0; uniform vec4 L1; uniform vec4 L2; uniform vec4 L3;
uniform vec4 L4; uniform vec4 L5; uniform vec4 L6; uniform vec4 L7;
uniform vec4 K0; uniform vec4 K1; uniform vec4 K2; uniform vec4 K3;
uniform vec4 K4; uniform vec4 K5; uniform vec4 K6; uniform vec4 K7;
uniform vec4 sky_dir;
uniform vec4 sky_col;
uniform vec4 amb_col;
uniform vec4 cam_pos;
uniform vec4 fog_col;
uniform vec4 fog_range;
uniform vec4 toon_rim;

float band(float x) { return smoothstep(0.0, 0.05, x); }

vec3 pl(vec4 L, vec4 K, vec3 n) {
    if (L.w <= 0.0) return vec3(0.0);
    vec3 d = L.xyz - wpos;
    float dist = length(d);
    float att = clamp(1.0 - dist / L.w, 0.0, 1.0);
    att = att * att;
    return K.rgb * att * band(dot(n, d / max(dist, 0.001)) + 0.2);
}

void main() {
    vec4 base = p3d_ColorScale * vcol;
    vec3 n = wnorm;
    float nl = length(n);
    n = nl > 0.0001 ? n / nl : vec3(0.0, 1.0, 0.0);
    if (!gl_FrontFacing) n = -n;
    vec3 lit = sky_col.rgb * band(dot(n, -sky_dir.xyz) + 0.15);
    lit += pl(L0, K0, n) + pl(L1, K1, n) + pl(L2, K2, n) + pl(L3, K3, n);
    lit += pl(L4, K4, n) + pl(L5, K5, n) + pl(L6, K6, n) + pl(L7, K7, n);
    float lum = max(lit.r, max(lit.g, lit.b));
    float tone = smoothstep(0.11, 0.15, lum);
    vec3 hue = lit / max(lum, 0.001);
    vec3 shade = base.rgb * vec3(0.46, 0.38, 0.54) * (0.85 + amb_col.rgb * 1.5);
    vec3 light = base.rgb * mix(vec3(1.0), hue, 0.28) * (0.95 + 0.2 * clamp(lum - 0.15, 0.0, 1.0));
    vec3 col = mix(shade, light, tone);
    vec3 v = normalize(cam_pos.xyz - wpos);
    float rim = smoothstep(0.6, 0.66, 1.0 - max(dot(n, v), 0.0));
    col += rim * toon_rim.rgb * toon_rim.w * (0.45 + 0.55 * tone);
    float f = smoothstep(fog_range.x, fog_range.y, length(cam_pos.xyz - wpos));
    col = mix(col, fog_col.rgb, f * 0.85);
    frag = vec4(col, base.a);
}
'''

LINE_VERT = '''#version 140
uniform mat4 p3d_ModelViewMatrix;
uniform mat4 p3d_ProjectionMatrix;
uniform mat3 p3d_NormalMatrix;
uniform vec4 line_width;
in vec4 p3d_Vertex;
in vec3 p3d_Normal;
in vec4 p3d_Color;
out vec4 vcol;
out float depth;
void main() {
    vec4 vp = p3d_ModelViewMatrix * p3d_Vertex;
    vec3 vn = normalize(p3d_NormalMatrix * p3d_Normal);
    float d = max(-vp.z, 0.5);
    vp.xyz += vn * line_width.x * clamp(d, 1.5, 30.0);
    gl_Position = p3d_ProjectionMatrix * vp;
    vcol = p3d_Color;
    depth = d;
}
'''

LINE_FRAG = '''#version 140
in vec4 vcol;
in float depth;
out vec4 frag;
uniform vec4 fog_col;
uniform vec4 fog_range;
void main() {
    vec3 col = mix(vec3(0.035, 0.012, 0.02), vcol.rgb * 0.28, 0.45);
    float f = smoothstep(fog_range.x, fog_range.y, depth);
    frag = vec4(mix(col, fog_col.rgb, f * 0.85), 1.0);
}
'''

FLAT_VERT = '''#version 140
uniform mat4 p3d_ModelViewProjectionMatrix;
uniform mat4 p3d_ModelViewMatrix;
in vec4 p3d_Vertex;
in vec4 p3d_Color;
out vec4 vcol;
out float depth;
void main() {
    gl_Position = p3d_ModelViewProjectionMatrix * p3d_Vertex;
    vcol = p3d_Color;
    depth = -(p3d_ModelViewMatrix * p3d_Vertex).z;
}
'''

FLAT_FRAG = '''#version 140
uniform vec4 p3d_ColorScale;
uniform vec4 fog_col;
uniform vec4 fog_range;
in vec4 vcol;
in float depth;
out vec4 frag;
void main() {
    vec4 c = vcol * p3d_ColorScale;
    float f = smoothstep(fog_range.x, fog_range.y, depth);
    frag = vec4(mix(c.rgb, fog_col.rgb, f * 0.85), c.a);
}
'''

_DEF = {'toon_rim': Vec4(1, .3, .25, .5), 'line_width': Vec4(.0017, 0, 0, 0)}

TOON = Shader(name='toon_shader', language=Shader.GLSL, vertex=TOON_VERT, fragment=TOON_FRAG,
              default_input=dict(_DEF))
LINE = Shader(name='line_shader', language=Shader.GLSL, vertex=LINE_VERT, fragment=LINE_FRAG,
              default_input=dict(_DEF))
FLAT = Shader(name='flat_shader', language=Shader.GLSL, vertex=FLAT_VERT, fragment=FLAT_FRAG,
              default_input=dict(_DEF))

STATE = {'safe': False, 'fallback': None}
TOON_ENTS, LINE_ENTS = [], []


def set_safe(safe, fallback=None):
    """F9: запасной режим — штатный шейдер, без контуров"""
    STATE['safe'] = safe
    if fallback is not None:
        STATE['fallback'] = fallback
    for lst in (TOON_ENTS, LINE_ENTS):
        alive = [e for e in lst if not _dead(e)]
        lst[:] = alive
    for e in TOON_ENTS:
        e.shader = STATE['fallback'] if (safe and STATE['fallback']) else TOON
    for e in LINE_ENTS:
        e.enabled = not safe


def _dead(e):
    try:
        return e.is_empty()
    except Exception:
        return True


# =====================================================================
# векторы на кортежах
# =====================================================================
def add(a, b): return (a[0] + b[0], a[1] + b[1], a[2] + b[2])
def sub(a, b): return (a[0] - b[0], a[1] - b[1], a[2] - b[2])
def mul(a, s): return (a[0] * s, a[1] * s, a[2] * s)
def dot(a, b): return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]
def cross(a, b): return (a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0])
def length(a): return math.sqrt(dot(a, a))
def lerp(a, b, k): return a + (b - a) * k
def lerp3(a, b, k): return (lerp(a[0], b[0], k), lerp(a[1], b[1], k), lerp(a[2], b[2], k))


def norm(a):
    ln = length(a)
    return (0.0, 1.0, 0.0) if ln < 1e-9 else (a[0] / ln, a[1] / ln, a[2] / ln)


def spow(x, p):
    return math.copysign(abs(x) ** p, x)


def hexc(h):
    h = h.lstrip('#')
    return (int(h[0:2], 16) / 255, int(h[2:4], 16) / 255, int(h[4:6], 16) / 255)


def rot(v, r):
    """Поворот как у Entity в Ursina: сначала крен (z), потом тангаж (x), потом курс (y)"""
    x, y, z = v
    if r[2]:
        a = math.radians(r[2]); c, s = math.cos(a), math.sin(a)
        x, y = x * c + y * s, -x * s + y * c
    if r[0]:
        a = math.radians(r[0]); c, s = math.cos(a), math.sin(a)
        y, z = y * c - z * s, y * s + z * c
    if r[1]:
        a = math.radians(r[1]); c, s = math.cos(a), math.sin(a)
        x, z = x * c + z * s, -x * s + z * c
    return (x, y, z)


def bez(p0, p1, p2, p3, n):
    out = []
    for i in range(n + 1):
        t = i / n
        u = 1 - t
        out.append(add(add(mul(p0, u * u * u), mul(p1, 3 * u * u * t)), add(mul(p2, 3 * u * t * t), mul(p3, t * t * t))))
    return out


# =====================================================================
# сырая геометрия: вершины, нормали, цвета, треугольники (наружу против часовой)
# =====================================================================
class Raw:
    def __init__(self):
        self.v, self.n, self.c, self.t = [], [], [], []

    def vert(self, p, col):
        self.v.append(p)
        self.c.append(col)
        return len(self.v) - 1

    def tri(self, a, b, c, hint):
        cr = cross(sub(self.v[b], self.v[a]), sub(self.v[c], self.v[a]))
        if abs(cr[0]) + abs(cr[1]) + abs(cr[2]) < 1e-12:
            return
        if dot(cr, hint) < 0:
            b, c = c, b
        self.t.append((a, b, c))

    def quad(self, a, b, c, d, hint):
        self.tri(a, b, c, hint)
        self.tri(b, d, c, hint)

    def smooth(self):
        acc = [[0.0, 0.0, 0.0] for _ in self.v]
        for a, b, c in self.t:
            cr = cross(sub(self.v[b], self.v[a]), sub(self.v[c], self.v[a]))
            for i in (a, b, c):
                acc[i][0] += cr[0]; acc[i][1] += cr[1]; acc[i][2] += cr[2]
        self.n = [norm(tuple(a)) for a in acc]
        return self


def _col_fn(col):
    if callable(col):
        return col
    return lambda *a: col


def loft(rings, nu=16, col=(1, 1, 1), wave=None, caps=(True, True)):
    """Тело вращения: кольца (y, rx, rz[, cx, cz, e]). col(j, a) или цвет"""
    cf = _col_fn(col)
    R = Raw()
    rows, centers = [], []
    for j, rg in enumerate(rings):
        y, rx, rz = rg[0], rg[1], rg[2]
        cx = rg[3] if len(rg) > 3 else 0.0
        cz = rg[4] if len(rg) > 4 else 0.0
        e = rg[5] if len(rg) > 5 else 2.0
        centers.append((cx, y, cz))
        row = []
        for i in range(nu):
            a = TAU * i / nu
            s, c = math.sin(a), math.cos(a)
            k = 1 + wave[0] * math.cos(wave[1] * a) if wave else 1
            p = (cx + rx * k * spow(s, 2 / e), y, cz + rz * k * spow(c, 2 / e))
            row.append(R.vert(p, cf(j, a)))
        rows.append(row)
    for j in range(len(rows) - 1):
        for i in range(nu):
            a, b = rows[j][i], rows[j][(i + 1) % nu]
            c, d = rows[j + 1][i], rows[j + 1][(i + 1) % nu]
            mid = lerp3(centers[j], centers[j + 1], .5)
            hint = sub(lerp3(R.v[a], R.v[d], .5), mid)
            R.quad(a, b, c, d, hint)
    for end, nb, on in ((0, 1, caps[0]), (len(rows) - 1, len(rows) - 2, caps[1])):
        if not on:
            continue
        hint = sub(centers[end], centers[nb])
        ctr = R.vert(centers[end], cf(end, 0))
        for i in range(nu):
            R.tri(ctr, rows[end][i], rows[end][(i + 1) % nu], hint)
    return R.smooth()


def blob(rx, ry, rz, nu=14, nv=9, col=(1, 1, 1), e=2.0):
    rings = []
    for j in range(nv + 1):
        ph = math.pi * j / nv
        k = math.sin(ph)
        rings.append((-ry * math.cos(ph), max(rx * k, 1e-4), max(rz * k, 1e-4), 0, 0, e))
    return loft(rings, nu, col, caps=(False, False))


def shell(rings, thick, nu=24, a0=0.0, a1=360.0, col_out=(1, 1, 1), col_in=None, wave=None):
    """Тонкая ткань с толщиной: кольца (y, rx, rz[, cx, cz]), дуга a0..a1 (0° = спереди, +x справа)"""
    cfo = _col_fn(col_out)
    cfi = _col_fn(col_in if col_in is not None else col_out)
    full = (a1 - a0) >= 359.9
    ncol = nu if full else nu + 1
    R = Raw()
    out, inn, centers = [], [], []

    def pt(rg, a, dr):
        y, rx, rz = rg[0], rg[1], rg[2]
        cx = rg[3] if len(rg) > 3 else 0.0
        cz = rg[4] if len(rg) > 4 else 0.0
        tilt = rg[5] if len(rg) > 5 else 0.0
        k = 1 + wave[0] * math.cos(wave[1] * a) if wave else 1
        return (cx + (rx * k - dr) * math.sin(a), y + tilt * math.cos(a), cz + (rz * k - dr) * math.cos(a))

    for j, rg in enumerate(rings):
        centers.append((rg[3] if len(rg) > 3 else 0.0, rg[0], rg[4] if len(rg) > 4 else 0.0))
        ro, ri = [], []
        for i in range(ncol):
            a = math.radians(a0 + (a1 - a0) * i / (nu if full else nu))
            ro.append(R.vert(pt(rg, a, 0), cfo(j, a)))
            ri.append(R.vert(pt(rg, a, thick), cfi(j, a)))
        out.append(ro)
        inn.append(ri)
    nj = len(rings)
    rng = range(ncol) if full else range(ncol - 1)
    for j in range(nj - 1):
        mid = lerp3(centers[j], centers[j + 1], .5)
        for i in rng:
            i2 = (i + 1) % ncol
            a, b, c, d = out[j][i], out[j][i2], out[j + 1][i], out[j + 1][i2]
            R.quad(a, b, c, d, sub(lerp3(R.v[a], R.v[d], .5), mid))
            a, b, c, d = inn[j][i], inn[j][i2], inn[j + 1][i], inn[j + 1][i2]
            R.quad(a, b, c, d, sub(mid, lerp3(R.v[a], R.v[d], .5)))
    for end, nb in ((0, 1), (nj - 1, nj - 2)):
        hint = sub(centers[end], centers[nb])
        for i in rng:
            i2 = (i + 1) % ncol
            R.quad(out[end][i], out[end][i2], inn[end][i], inn[end][i2], hint)
    if not full:
        for i, sgn in ((0, -1), (ncol - 1, 1)):
            for j in range(nj - 1):
                a = math.radians(a0 if i == 0 else a1)
                tang = (math.cos(a) * sgn, 0, -math.sin(a) * sgn)
                R.quad(out[j][i], out[j + 1][i], inn[j][i], inn[j + 1][i], tang)
    return R.smooth()


def sweep(pts, rad, up, nu=8, col=(1, 1, 1), caps=(True, True)):
    """Трубка вдоль кривой. rad(s) -> (полуширина, полутолщина). up — куда смотрит «плоская» сторона"""
    cf = _col_fn(col)
    R = Raw()
    n = len(pts)
    T = []
    for i in range(n):
        T.append(norm(sub(pts[min(n - 1, i + 1)], pts[max(0, i - 1)])))
    N = norm(sub(up, mul(T[0], dot(up, T[0]))))
    rows = []
    for i in range(n):
        if i:
            N = sub(N, mul(T[i], dot(N, T[i])))
            N = norm(N)
        B = norm(cross(T[i], N))
        s = i / (n - 1)
        w, d = rad(s)
        row = []
        for k in range(nu):
            a = TAU * k / nu
            p = add(pts[i], add(mul(B, w * math.sin(a)), mul(N, d * math.cos(a))))
            row.append(R.vert(p, cf(s, a)))
        rows.append(row)
    for i in range(n - 1):
        for k in range(nu):
            a, b = rows[i][k], rows[i][(k + 1) % nu]
            c, d = rows[i + 1][k], rows[i + 1][(k + 1) % nu]
            hint = sub(lerp3(R.v[a], R.v[d], .5), lerp3(pts[i], pts[i + 1], .5))
            R.quad(a, b, c, d, hint)
    for end, on, sgn in ((0, caps[0], -1), (n - 1, caps[1], 1)):
        if not on:
            continue
        ctr = R.vert(pts[end], cf(end / (n - 1), 0))
        for k in range(nu):
            R.tri(ctr, rows[end][k], rows[end][(k + 1) % nu], mul(T[end], sgn))
    return R.smooth()


def ring(r, tube, y=0.0, nu=24, nv=6, col=(1, 1, 1), squash=1.0):
    """Тор в плоскости XZ"""
    pts = [(math.sin(TAU * i / nu) * r, y, math.cos(TAU * i / nu) * r) for i in range(nu + 1)]
    return sweep(pts, lambda s: (tube, tube * squash), (0, 1, 0), nv, col, caps=(False, False))


def slab(poly, thick, col=(1, 1, 1), center=None):
    """Плоская пластина из выпуклого многоугольника в плоскости XY, толщина по Z"""
    cf = _col_fn(col)
    R = Raw()
    cx = center if center else (sum(p[0] for p in poly) / len(poly), sum(p[1] for p in poly) / len(poly))
    for sz in (1, -1):
        c0 = R.vert((cx[0], cx[1], thick * sz), cf(cx[0], cx[1]))
        ids = [R.vert((p[0], p[1], thick * sz), cf(p[0], p[1])) for p in poly]
        for i in range(len(poly) - 1):
            R.tri(c0, ids[i], ids[i + 1], (0, 0, sz))
        if sz == 1:
            top = ids
        else:
            bot = ids
    for i in range(len(poly) - 1):
        p, q = poly[i], poly[i + 1]
        hint = (q[1] - p[1], -(q[0] - p[0]), 0)
        if dot(hint, (p[0] - cx[0], p[1] - cx[1], 0)) < 0:
            hint = mul(hint, -1)
        R.quad(top[i], top[i + 1], bot[i], bot[i + 1], hint)
    return R.smooth()


# =====================================================================
# сборка: вся геометрия сустава -> один меш
# =====================================================================
class Geo:
    GROUPS = ('ink', 'soft', 'glow')

    def __init__(self):
        self.g = {k: Raw() for k in self.GROUPS}

    def add(self, raw, col=None, grp='ink', pos=(0, 0, 0), r=(0, 0, 0), s=1.0, mirror=False):
        dst = self.g[grp]
        if not isinstance(s, tuple):
            s = (s, s, s)
        if mirror:
            s = (-s[0], s[1], s[2])
        flip = (s[0] * s[1] * s[2]) < 0
        base = len(dst.v)
        for p, nrm, c in zip(raw.v, raw.n, raw.c):
            q = add(rot((p[0] * s[0], p[1] * s[1], p[2] * s[2]), r), pos)
            nn = norm(rot((nrm[0] / s[0], nrm[1] / s[1], nrm[2] / s[2]), r))
            dst.v.append(q)
            dst.n.append(nn)
            cc = col if col is not None else c
            dst.c.append(cc)
        for a, b, c in raw.t:
            dst.t.append((base + a, base + c, base + b) if flip else (base + a, base + b, base + c))
        return self


def _mesh(raw):
    # в Ursina лицевая сторона — когда векторное произведение смотрит внутрь: переворачиваем
    cols = [Color(c[0], c[1], c[2], 1) for c in raw.c]
    return Mesh(vertices=list(raw.v), triangles=[(a, c, b) for a, b, c in raw.t], normals=list(raw.n),
                colors=cols, mode='triangle')


CACHE = {}


def dress(joint, key, fn, rim=(1, .3, .25, .5)):
    """Вешает на сустав готовую геометрию. fn() -> Geo, результат кэшируется на класс героя"""
    if key not in CACHE:
        CACHE[key] = fn()
    geo = CACHE[key]
    out = []
    for grp in Geo.GROUPS:
        raw = geo.g[grp]
        if not raw.t:
            continue
        e = Entity(parent=joint, model=_mesh(raw))
        if grp == 'glow':
            e.shader = FLAT
        else:
            e.shader = STATE['fallback'] if (STATE['safe'] and STATE['fallback']) else TOON
            e.set_shader_input('toon_rim', Vec4(*rim))
            TOON_ENTS.append(e)
        out.append(e)
        if grp == 'ink':
            ln = Entity(parent=joint, model=_mesh(raw))
            ln.shader = LINE
            try:
                from panda3d.core import CullFaceAttrib
                ln.setAttrib(CullFaceAttrib.makeReverse())
            except Exception:
                pass
            ln.enabled = not STATE['safe']
            LINE_ENTS.append(ln)
            out.append(ln)
    return out


# =====================================================================
# лицо и голова
# =====================================================================
class Head:
    """Аниме-голова. Кольца (y, rx, rz, cz), y от подбородка вверх. Знает свою поверхность для глаз и волос"""

    def __init__(self, rings, cap):
        self.rings = rings
        self.cap = cap

    @staticmethod
    def _at(rings, y):
        if y <= rings[0][0]:
            return rings[0][1:]
        for i in range(len(rings) - 1):
            a, b = rings[i], rings[i + 1]
            if y <= b[0]:
                k = (y - a[0]) / (b[0] - a[0])
                return tuple(lerp(a[m], b[m], k) for m in (1, 2, 3))
        return rings[-1][1:]

    def surf_z(self, x, y):
        rx, rz, cz = self._at(self.rings, y)
        q = 1 - (x / max(rx, 1e-4)) ** 2
        return cz + rz * math.sqrt(max(0.0, q))

    def surf_n(self, x, y):
        e = .002
        dzdx = (self.surf_z(x + e, y) - self.surf_z(x - e, y)) / (2 * e)
        dzdy = (self.surf_z(x, y + e) - self.surf_z(x, y - e)) / (2 * e)
        return norm((-dzdx, -dzdy, 1))

    def around(self, theta, y, off, use_cap=True):
        """Точка снаружи головы/причёски: theta=0 спереди, 90 справа (+x)"""
        a = math.radians(theta)
        s, c = math.sin(a), math.cos(a)
        best = None
        for rings in ((self.rings, self.cap) if use_cap else (self.rings,)):
            yy = min(max(y, rings[0][0]), rings[-1][0])
            rx, rz, cz = self._at(rings, yy)
            p = (rx * s, y, cz + rz * c)
            r = p[0] * s + p[2] * c
            if best is None or r > best[1]:
                best = (p, r)
        p = best[0]
        return add(p, (s * off, 0, c * off)), (s, 0, c)

    def mesh(self, col, nu=22):
        return loft([(y, rx, rz, 0, cz) for y, rx, rz, cz in self.rings], nu, col)

    def cap_mesh(self, col, nu=22):
        return loft([(y, rx, rz, 0, cz) for y, rx, rz, cz in self.cap], nu, col)

    # --- нарисованное на лице
    def decal(self, pts2d, off, col, center=None):
        """Выпуклый многоугольник (или звёздный от center), прижатый к лицу"""
        cf = _col_fn(col)
        R = Raw()
        cx = center or (sum(p[0] for p in pts2d) / len(pts2d), sum(p[1] for p in pts2d) / len(pts2d))

        def P(x, y):
            nrm = self.surf_n(x, y)
            return add((x, y, self.surf_z(x, y)), mul(nrm, off)), nrm

        p0, n0 = P(*cx)
        c0 = R.vert(p0, cf(cx[0], cx[1]))
        ids = []
        for x, y in pts2d:
            p, _ = P(x, y)
            ids.append(R.vert(p, cf(x, y)))
        for i in range(len(ids)):
            R.tri(c0, ids[i], ids[(i + 1) % len(ids)], n0)
        R.n = [self.surf_n(p[0], p[1]) for p in R.v]
        return R

    def stroke(self, pts2d, widths, off, col):
        """Мазок кистью: линия переменной толщины по лицу"""
        cf = _col_fn(col)
        R = Raw()
        n = len(pts2d)
        L, Rr = [], []
        for i, (x, y) in enumerate(pts2d):
            a = pts2d[max(0, i - 1)]
            b = pts2d[min(n - 1, i + 1)]
            tx, ty = b[0] - a[0], b[1] - a[1]
            ln = math.hypot(tx, ty) or 1
            nx, ny = -ty / ln, tx / ln
            w = widths(i / (n - 1)) if callable(widths) else widths
            for side, lst in ((1, L), (-1, Rr)):
                px, py = x + nx * w * side * .5, y + ny * w * side * .5
                nrm = self.surf_n(px, py)
                lst.append(R.vert(add((px, py, self.surf_z(px, py)), mul(nrm, off)), cf(i / (n - 1), side)))
        for i in range(n - 1):
            hint = self.surf_n(*pts2d[i])
            R.quad(L[i], L[i + 1], Rr[i], Rr[i + 1], hint)
        R.n = [self.surf_n(p[0], p[1]) for p in R.v]
        return R


def ellipse_pts(cx, cy, rx, ry, n=20, clip=None):
    pts = []
    for i in range(n):
        a = TAU * i / n
        x, y = cx + rx * math.cos(a), cy + ry * math.sin(a)
        if clip:
            lo, hi = clip(x)
            y = min(max(y, lo), hi)
        pts.append((x, y))
    return pts


def add_eye(geo, hd, side, ex, ey, w, h, tilt, iris_top, iris_bot, lash, sclera=(.93, .88, .88), iris_r=.42,
            lash_w=(.004, .008), flick=.012, lower=True, glow_iris=True, highlight=True, lid_h=None):
    """Аниме-глаз: белок, радужка с градиентом, зрачок, блики, жирная линия век"""
    sx = side

    def top(u):   # u: -1 внутренний угол, +1 внешний
        return ey + h * .55 * max(0.0, 1 - u * u) ** .55 + tilt * u

    def bot(u):
        return ey - h * .45 * max(0.0, 1 - u * u) ** .9 + tilt * u - .002 * u

    def X(u):
        return ex + sx * u * w / 2

    us = [-1 + 2 * i / 16 for i in range(17)]
    poly = [(X(u), top(u)) for u in us] + [(X(u), bot(u)) for u in reversed(us[1:-1])]
    geo.add(hd.decal(poly, .0012, sclera), grp='soft')

    def clip(x):
        u = max(-1.0, min(1.0, (x - ex) * sx / (w / 2)))
        return bot(u) + .0006, top(u) - .0006

    icx, icy = ex + sx * w * .02, ey - h * .02
    irx, iry = w * iris_r * .5 * 1.0, h * .62
    ymin, ymax = icy - iry, icy + iry
    icol = lambda x, y: lerp3(iris_bot, iris_top, max(0.0, min(1.0, (y - ymin) / (ymax - ymin))) ** 1.2)
    geo.add(hd.decal(ellipse_pts(icx, icy, irx, iry, 22, clip), .0022, icol, center=(icx, icy)),
            grp='glow' if glow_iris else 'soft')
    geo.add(hd.decal(ellipse_pts(icx, icy + h * .05, irx * .42, iry * .5, 14, clip), .0029,
                     lerp3(iris_top, (0, 0, 0), .55)), grp='glow' if glow_iris else 'soft')
    if highlight:
        geo.add(hd.decal(ellipse_pts(icx - sx * irx * .35, icy + iry * .38, irx * .3, iry * .22, 10), .0036,
                         (1, 1, 1)), grp='glow')
        geo.add(hd.decal(ellipse_pts(icx + sx * irx * .3, icy - iry * .45, irx * .15, iry * .1, 8), .0036,
                         (1, .95, .92)), grp='glow')
    # верхнее веко: толще к внешнему углу, с «хвостиком»
    lus = [-1.05 + 2.15 * i / 18 for i in range(19)]
    pts = [(X(u), top(u) + .0015) for u in lus]
    pts.append((X(1.1) + sx * flick * .8, top(1.0) + flick * .35))
    geo.add(hd.stroke(pts, lambda s: lerp(lash_w[0], lash_w[1], s ** 1.3) * (1 - max(0, s - .93) * 9), .0042, lash),
            grp='soft')
    if lower:
        lus = [.15 + .9 * i / 8 for i in range(9)]
        geo.add(hd.stroke([(X(u), bot(u) - .0008) for u in lus], lambda s: .0012 + .0012 * s, .0038,
                          lerp3(lash, sclera, .25)), grp='soft')
    if lid_h:
        # складка века над глазом
        lus = [-.4 + 1.3 * i / 8 for i in range(9)]
        geo.add(hd.stroke([(X(u), top(u) + lid_h) for u in lus], .0011, .0016, lerp3(lash, (1, .8, .7), .45)),
                grp='soft')


# =====================================================================
# волосы
# =====================================================================
def lock(hd, theta, y0, y1, w, th, dtheta=0.0, off0=.006, off1=.02, flick=0.0, n=10, col0=(0, 0, 0),
         col1=(0, 0, 0), curl=0.0, sag=0.0, tip=None):
    """Прядь, лежащая по форме головы: от корня (theta, y0) вниз до y1. tip — свободный хвост (dx, dy, dz)"""
    pts = []
    out0 = None
    for i in range(n + 1):
        s = i / n
        y = lerp(y0, y1, s)
        p, o = hd.around(theta + dtheta * s ** 1.3, y, lerp(off0, off1, s * s))
        if out0 is None:
            out0 = o
        p = add(p, mul(o, flick * s ** 4))
        p = add(p, (0, curl * s ** 3, 0))
        p = add(p, (0, -sag * math.sin(math.pi * s), 0))
        pts.append(p)
    if tip:
        a = pts[-1]
        pts = pts[:-1] + bez(a, add(a, mul(tip, .4)), add(a, mul(tip, .8)), add(a, tip), 4)
    rad = lambda s: (w * (1 - s) ** .75 * (.85 + .3 * math.sin(math.pi * min(1, s * 1.6))) + .0008,
                     th * (1 - s) ** .6 + .0008)
    cf = lambda s, a: lerp3(col0, col1, s ** 1.4)
    return sweep(pts, rad, out0, 7, cf)


def free_lock(pts, w, th, up, col0, col1, nu=7):
    rad = lambda s: (w * (1 - s) ** .7 * (.9 + .25 * math.sin(math.pi * min(1, s * 1.5))) + .0008,
                     th * (1 - s) ** .55 + .0008)
    return sweep(pts, rad, up, nu, lambda s, a: lerp3(col0, col1, s ** 1.3))


# =====================================================================
# общие куски тела
# =====================================================================
def limb(y0, y1, r0, r1, col, depth=1.0, bulge=0.0, nu=14, z_off=0.0, rings=7):
    rr = []
    for j in range(rings + 1):
        s = j / rings
        r = lerp(r0, r1, s) * (1 + bulge * math.sin(math.pi * min(1, s * 1.3)))
        rr.append((lerp(y0, y1, s), r, r * depth, 0, z_off * math.sin(math.pi * s)))
    # круглые торцы
    rr = [(y0 + (r0 * .55 if y0 > y1 else -r0 * .55), r0 * .45, r0 * .45 * depth)] + rr + \
         [(y1 - (r1 * .55 if y0 > y1 else -r1 * .55), r1 * .45, r1 * .45 * depth)]
    return loft(rr, nu, col)


def foot(col, sole=None, L=.2, W=.07, H=.07):
    """Ступня/обувь: носок смотрит в +z"""
    cf = col if sole is None else (lambda j, a: sole if j <= 1 else col)
    pts = []
    rr = [(-H * .5, W * .45, L * .42, 0, L * .2, 3), (-H * .38, W * .5, L * .5, 0, L * .2, 3),
          (-H * .1, W * .5, L * .48, 0, L * .17, 3), (H * .2, W * .42, L * .34, 0, L * .06, 2.5),
          (H * .45, W * .3, L * .2, 0, -L * .05, 2.2), (H * .55, W * .1, L * .08, 0, -L * .06, 2)]
    return loft(rr, 16, cf)


def hand(col, fist=True, W=.05):
    if fist:
        return loft([(-.05, W * .3, W * .45), (-.045, W * .55, W * .62, 0, 0, 3), (-.02, W * .6, W * .68, 0, .003, 3),
                     (.015, W * .55, W * .6, 0, 0, 3), (.03, W * .35, W * .38)], 14, col)
    return loft([(-.07, W * .1, W * .1), (-.06, W * .38, W * .2, 0, 0, 3), (-.03, W * .5, W * .28, 0, 0, 3),
                 (0, W * .52, W * .3, 0, 0, 3), (.02, W * .35, W * .3)], 14, col)


# =====================================================================
# САМУРАЙ — «Багровый ронин»
# =====================================================================
S_SKIN = hexc('#f3d2c1')
S_SKIN_SH = hexc('#e0ad9c')
S_HAIR0 = hexc('#141019')
S_HAIR1 = hexc('#6a1220')
S_EYE_T = hexc('#b3260f')
S_EYE_B = hexc('#ffc64a')
S_LASH = hexc('#1a0a10')
S_BLACK = hexc('#1b161e')
S_KIMONO = hexc('#2a2130')
S_RED = hexc('#b8141f')
S_RED_D = hexc('#6e0d16')
S_GOLD = hexc('#e2b45c')
S_WHITE = hexc('#ece4e0')
S_HAKAMA = hexc('#2e2230')
S_LAC = hexc('#5a0c14')
S_STEEL = hexc('#e6e8ee')

S_HEAD = Head(
    rings=[(-.004, .012, .012, .05), (.012, .036, .03, .048), (.035, .062, .058, .034), (.07, .088, .088, .02),
           (.105, .1, .1, .012), (.145, .106, .108, .002), (.185, .11, .116, -.008), (.225, .108, .118, -.016),
           (.26, .096, .107, -.02), (.285, .07, .08, -.022), (.3, .028, .034, -.022)],
    cap=[(.015, .066, .07, -.045), (.075, .112, .1, -.034), (.135, .123, .125, -.05), (.19, .128, .14, -.014),
         (.245, .123, .138, -.018), (.285, .1, .114, -.022), (.315, .056, .07, -.022), (.33, .004, .004, -.022)])


def samurai_head():
    g = Geo()
    hd = S_HEAD
    skin = lambda j, a: lerp3(S_SKIN, S_SKIN_SH, .35 if j <= 1 else 0)
    g.add(hd.mesh(skin))
    for sd in (-1, 1):
        g.add(blob(.014, .03, .022, col=S_SKIN), pos=(.104 * sd, .125, -.004), r=(0, 0, -10 * sd))
    # глаза: узкие, хищные, внешний угол вверх
    for sd in (-1, 1):
        add_eye(g, hd, sd, .047 * sd, .118, .05, .026, .005, S_EYE_T, S_EYE_B, S_LASH, iris_r=.5,
                lash_w=(.0035, .0075), flick=.01, lid_h=.0075)
        # брови: резкие, к переносице ниже
        g.add(hd.stroke([(sd * .02, .147), (sd * .045, .156), (sd * .072, .158)],
                        lambda s: .0065 * (1 - s * .6), .0016, S_LASH), grp='soft')
    g.add(hd.stroke([(.0, .085), (.006, .074), (.0, .07)], lambda s: .0022 * (1 - s), .0015, S_SKIN_SH), grp='soft')
    g.add(hd.stroke([(-.012, .043), (0, .041), (.013, .044)], .0024, .0016, hexc('#8a3a3a')), grp='soft')
    # шрам через переносицу
    g.add(hd.stroke([(-.032, .1), (0, .094), (.036, .086)], lambda s: .0028 * math.sin(math.pi * s) + .0006, .0016,
                    hexc('#c0545a')), grp='soft')
    # причёска
    hc = lambda j, a: S_HAIR0
    g.add(hd.cap_mesh(hc))
    H0, H1 = S_HAIR0, S_HAIR1
    # чёлка: острые пряди над глазами
    for th, y0, y1, w, dth, fl in ((-34, .27, .14, .03, -12, .0), (-16, .28, .118, .032, -8, .0),
                                   (2, .285, .102, .028, 4, .0), (18, .28, .125, .03, 10, .0),
                                   (36, .27, .145, .028, 14, .0), (-50, .26, .12, .026, -6, .01),
                                   (52, .26, .12, .026, 6, .01), (-8, .29, .16, .036, -20, .01),
                                   (26, .29, .16, .034, 22, .01)):
        g.add(lock(hd, th, y0, y1, w, .011, dtheta=dth, off0=.012, off1=.022, flick=fl, col0=H0, col1=H1))
    # пряди у лица до скул
    for sd in (-1, 1):
        g.add(lock(hd, 68 * sd, .25, -.02, .026, .011, dtheta=10 * sd, off0=.012, off1=.03, flick=.012,
                   col0=H0, col1=H1))
        g.add(lock(hd, 84 * sd, .24, .03, .028, .012, dtheta=8 * sd, off0=.015, off1=.035, flick=.02,
                   col0=H0, col1=H1))
    # растрёпанный объём сзади и с боков
    for i, th in enumerate(range(100, 261, 20)):
        y1 = .0 if 130 <= th <= 230 else .04
        g.add(lock(hd, th, .3, y1, .045, .016, dtheta=(-8 if th < 180 else 8), off0=.012, off1=.045,
                   flick=.05, col0=H0, col1=H1))
    for th in (130, 160, 200, 230):
        g.add(lock(hd, th, .32, .12, .04, .014, dtheta=0, off0=.014, off1=.05, flick=.06, col0=H0, col1=H1))
    for th in (-120, 120, -150, 150, 180):
        g.add(lock(hd, th, .33, .2, .04, .016, off0=.02, off1=.05, flick=.05, col0=H0, col1=H1))
    # торчащие пряди на макушке
    for th, ln, tp in ((-35, .1, (-.04, .05, -.07)), (35, .1, (.04, .05, -.07)), (-90, .08, (-.07, .03, -.03)),
                       (90, .08, (.07, .03, -.03)), (0, .06, (0, .06, -.08)), (-150, .07, (-.04, .02, -.08)),
                       (150, .07, (.04, .02, -.08))):
        a, o = hd.around(th, .305, .004)
        pts = bez(a, add(a, (tp[0] * .3, .03, tp[2] * .3 + .01)), add(a, (tp[0] * .7, tp[1], tp[2] * .7)),
                  add(a, tp), 8)
        g.add(free_lock(pts, .03, .012, o, H0, lerp3(H0, H1, .6)))
    # хатимаки: алая повязка поверх волос, узел сзади
    band = []
    for i in range(41):
        th = -180 + 360 * i / 40
        p, o = hd.around(th, .228 + .012 * math.cos(math.radians(th)), .03)
        band.append(p)
    g.add(sweep(band, lambda s: (.017, .005), (0, 0, 1), 8, S_RED, caps=(False, False)))
    gold = []
    for i in range(41):
        th = -180 + 360 * i / 40
        p, o = hd.around(th, .228 + .012 * math.cos(math.radians(th)), .034)
        gold.append(p)
    g.add(sweep(gold, lambda s: (.002, .0035), (0, 1, 0), 6, S_GOLD, caps=(False, False)), grp='soft')
    knot, o = hd.around(180, .22, .04)
    g.add(blob(.02, .016, .014, col=S_RED), pos=knot)
    for sd in (-1, 1):
        a = knot
        pts = bez(a, add(a, (.03 * sd, -.04, -.03)), add(a, (.05 * sd, -.12, -.06)), add(a, (.07 * sd, -.24, -.05)), 10)
        g.add(free_lock(pts, .016, .004, (0, 0, -1), S_RED, S_RED_D))
    # высокий хвост: основание и шнур (сам хвост — цепочка self.hair)
    base, o = hd.around(180, .25, .0)
    g.add(blob(.034, .03, .034, col=S_HAIR0), pos=add(base, (0, 0, -.01)))
    g.add(ring(.026, .007, col=S_GOLD), pos=add(base, (0, 0, -.035)), r=(-60, 0, 0))
    return g


def samurai_tail_seg(i, n):
    """Сегмент хвоста: пучок прядей вдоль +y"""
    g = Geo()
    k0, k1 = i / n, (i + 1) / n
    H0 = lerp3(S_HAIR0, S_HAIR1, k0 * .8)
    H1 = lerp3(S_HAIR0, S_HAIR1, min(1, k1 * .9 + .1))
    R0 = .036 * (1 - k0 * .55)
    L = .13 if i < n - 1 else .17
    for j in range(6):
        a = TAU * j / 6 + i * .5
        dx, dz = math.sin(a), math.cos(a)
        last = i == n - 1
        p0 = (dx * R0 * .4, -.01, dz * R0 * .4)
        p3 = (dx * R0 * (.5 if last else .4) + dx * .01, L, dz * R0 * .4)
        pts = bez(p0, add(p0, (dx * R0 * .5, L * .35, dz * R0 * .5)), add(p3, (dx * R0 * .3, -L * .3, dz * R0 * .3)),
                  p3, 6)
        w = R0 * .9
        rad = (lambda s, w=w: (w * (1 - s) ** .9 + .001, w * .45 * (1 - s) ** .7 + .001)) if last else \
              (lambda s, w=w: (w * (1 - .35 * s), w * .45 * (1 - .3 * s)))
        g.add(sweep(pts, rad, (dx, 0, dz), 7, lambda s, a_, H0=H0, H1=H1: lerp3(H0, H1, s)))
    return g


def samurai_torso():
    g = Geo()
    # тело под кимоно
    body = [(-.02, .14, .105), (.06, .15, .11), (.18, .165, .118, 0, .006), (.3, .185, .125, 0, .01),
            (.4, .205, .12, 0, .006), (.48, .2, .112), (.555, .165, .092), (.6, .085, .07)]
    g.add(loft(body, 20, S_KIMONO))
    # шея
    g.add(limb(.5, .74, .057, .052, S_SKIN, depth=1.05, rings=4))
    # ворот: белый нижний и алый верхний слой, запах налево
    for sd, colr, off, wdt in ((1, S_WHITE, .006, .022), (-1, S_WHITE, .006, .022), (1, S_RED, .014, .018),
                               (-1, S_RED, .014, .018)):
        pts = []
        for k in range(12):
            s = k / 11
            y = lerp(.56, .1, s)
            x = sd * lerp(.06, -.03, s ** .8)
            z = lerp(.04, .11, min(1, s * 2.5)) + off
            pts.append((x, y, z + .005 * math.sin(math.pi * s)))
        g.add(free_lock(pts, wdt, .005, (0, 0, 1), colr, colr, 6) if False else
              sweep(pts, lambda s, w=wdt: (w, .004), (0, 0, 1), 6, colr))
    # лакированная кираса на груди с золотой кромкой
    cuir = [(.2, .17, .122, 0, .02), (.28, .185, .13, 0, .025), (.36, .2, .132, 0, .024), (.415, .204, .127, 0, .019),
            (.43, .205, .125, 0, .018)]
    g.add(shell(cuir, .012, 22, -62, 62, lambda j, a: S_GOLD if j >= 4 else S_LAC))
    for y in (.27, .34):
        pts = [(math.sin(math.radians(a)) * .192, y, math.cos(math.radians(a)) * .135 + .025) for a in range(-55, 56, 10)]
        g.add(sweep(pts, lambda s: (.004, .003), (0, 1, 0), 6, S_RED_D), grp='soft')
    # хаори: чёрный, открыт спереди, к подолу разгорается алым
    def haori_col(j, a):
        k = j / 6
        flame = .5 + .5 * math.sin(a * 5 + 1.3)
        return lerp3(S_BLACK, S_RED_D, max(0.0, min(1.0, (k - .7) * 2.0 + flame * .2 * (k > .65))))
    haori = [(.55, .16, .095), (.5, .215, .13), (.4, .222, .14), (.25, .21, .14), (.1, .2, .14), (-.05, .215, .16),
             (-.16, .235, .18)]
    g.add(shell(haori, .012, 30, 38, 322, haori_col, S_RED_D))
    # шарф вокруг шеи
    g.add(ring(.08, .03, y=.585, col=S_RED, squash=.85), pos=(0, 0, -.005), s=(1.12, 1, 1))
    # пучок шарфа сзади — откуда растёт хвост self.scarf
    g.add(blob(.06, .04, .035, col=S_RED), pos=(0, .55, -.14))
    return g


def samurai_scarf_seg(i, n):
    g = Geo()
    w0 = .13 - i * .014
    w1 = .13 - (i + 1) * .014
    k = i / n
    col = lambda s, a: lerp3(S_RED, S_RED_D, k + s / n)
    pts = [(0, 0, .02), (0, .0, -.12), (0, 0, -.26)]
    last = i == n - 1
    rad = (lambda s: (lerp(w0, w1 * .2, s ** .7), .006)) if last else (lambda s: (lerp(w0, w1, s), .006))
    g.add(sweep(pts, rad, (0, 1, 0), 8, col))
    return g


def samurai_hips():
    g = Geo()
    # оби
    g.add(loft([(-.07, .17, .13), (-.06, .175, .135), (.06, .175, .135), (.07, .165, .125)], 22, S_RED))
    g.add(ring(.176, .007, y=.0, col=S_GOLD, squash=.8), s=(1, 1, .77))
    g.add(blob(.035, .03, .02, col=S_RED), pos=(.06, -.01, .135))
    for sd in (-1, 1):
        pts = bez((.06, -.02, .14), (.07 + .01 * sd, -.06, .15), (.06 + .03 * sd, -.12, .15), (.06 + .03 * sd, -.17, .14), 6)
        g.add(free_lock(pts, .014, .003, (0, 0, 1), S_RED, S_RED_D))
    # верх хакамы — мост между ногами
    g.add(shell([(-.05, .172, .132), (-.13, .19, .15), (-.22, .2, .16)], .01, 26,
                col_out=lambda j, a: lerp3(S_HAKAMA, S_BLACK, .35 * (math.cos(a * 8) * .5 + .5)), wave=(.03, 8)))
    # сая катаны: слева, рукоятью вперёд
    def saya_line(t):
        return (-.21 + .01 * t, -.04 + .2 * (1 - t) - .22 * t, .2 - .9 * t)
    pts = [saya_line(i / 12) for i in range(13)]
    g.add(sweep(pts, lambda s: (.022, .016), (1, 0, 0), 10, lambda s, a: S_GOLD if s < .06 else (
        S_RED_D if s > .95 else S_LAC)))
    for s in (.25, .5):
        g.add(ring(.024, .005, col=S_GOLD), pos=saya_line(s), r=(-77, 0, 0))
    # вакидзаси справа
    pts = [(.2, -.02 + .1 * (1 - i / 8) - .12 * (i / 8), .2 - .55 * (i / 8)) for i in range(9)]
    g.add(sweep(pts[:3], lambda s: (.017, .015), (1, 0, 0), 8, lambda s, a: S_RED if int(s * 6) % 2 else S_BLACK))
    g.add(sweep(pts[2:], lambda s: (.018, .013), (1, 0, 0), 8, S_LAC))
    g.add(ring(.024, .006, col=S_GOLD), pos=pts[2], r=(-70, 0, 0))
    return g


def samurai_thigh():
    g = Geo()
    pleat = lambda j, a: lerp3(S_HAKAMA, S_BLACK, .45 * (math.cos(a * 6) * .5 + .5))
    g.add(shell([(.03, .095, .1), (-.12, .118, .122), (-.3, .128, .132), (-.5, .133, .137), (-.56, .134, .138)], .01, 22,
                col_out=pleat, col_in=S_BLACK, wave=(.03, 6)))
    g.add(limb(0, -.46, .085, .065, S_BLACK))
    return g


def samurai_shin():
    g = Geo()
    pleat = lambda j, a: lerp3(S_HAKAMA, S_BLACK, .45 * (math.cos(a * 6) * .5 + .5))
    g.add(shell([(.07, .118, .122), (-.05, .126, .13), (-.1, .138, .142), (-.24, .14, .145), (-.3, .128, .132)], .01, 22,
                col_out=pleat, col_in=S_BLACK, wave=(.03, 6)))
    g.add(limb(.02, -.4, .06, .045, S_BLACK))
    # сапоги с алой обмоткой
    g.add(loft([(-.24, .052, .055), (-.3, .056, .06), (-.38, .052, .057), (-.42, .055, .06)], 16, S_BLACK))
    for y in (-.27, -.33):
        g.add(ring(.058, .006, y=y, col=S_RED, squash=.7))
    g.add(foot(S_BLACK, hexc('#3a2a30'), L=.22, W=.078, H=.08), pos=(0, -.44, .045))
    return g


def samurai_upper_arm(side):
    g = Geo()
    g.add(blob(.066, .066, .064, col=S_KIMONO), pos=(0, -.03, 0))
    g.add(limb(-.03, -.3, .058, .05, S_KIMONO))
    if side > 0:
        # рукав подвязан тасуки — рука открыта для меча
        g.add(ring(.064, .009, y=-.1, col=S_RED, squash=.8))
        g.add(shell([(.04, .07, .07), (-.03, .078, .08), (-.085, .084, .088, 0, -.004, .012),
                     (-.095, .083, .087, 0, -.005, .012)], .009, 18, col_out=lambda j, a: S_RED if j >= 3 else S_BLACK,
                    col_in=S_RED_D))
    else:
        # широкий рукав хаори: чёрный, алая подкладка, подол горит
        rows = [(.04, .07, .07), (-.04, .074, .076), (-.13, .085, .092, 0, -.006, .01), (-.24, .1, .118, 0, -.022, .03),
                (-.33, .108, .14, 0, -.04, .05), (-.4, .106, .148, 0, -.05, .065), (-.41, .104, .147, 0, -.05, .066)]
        g.add(shell(rows, .009, 24, col_out=lambda j, a: S_RED if j >= 6 else lerp3(S_BLACK, S_RED_D, max(0, (j - 2) / 3) ** 1.5),
                    col_in=S_RED_D))
        # содэ — лакированный наплечник с золотой кромкой
        sode = [(.07, .092, .095, -.012, 0), (0, .104, .108, -.018, 0), (-.08, .113, .116, -.024, 0),
                (-.135, .118, .12, -.029, 0), (-.15, .12, .121, -.03, 0)]
        g.add(shell(sode, .012, 18, -150, -30, lambda j, a: S_GOLD if j >= 4 else S_LAC, S_BLACK))
        for y in (-.02, -.08):
            pts = [(math.sin(math.radians(a)) * .118 - .02, y, math.cos(math.radians(a)) * .116) for a in range(-145, -34, 10)]
            g.add(sweep(pts, lambda s: (.003, .003), (0, 1, 0), 6, S_RED), grp='soft')
    return g


def samurai_forearm(side):
    g = Geo()
    g.add(limb(0, -.27, .05, .042, S_BLACK, bulge=.12))
    # котэ: лакированный наруч
    g.add(shell([(-.05, .056, .056), (-.15, .053, .053), (-.235, .047, .047), (-.25, .046, .046)], .008, 16, -80, 80,
                lambda j, a: S_GOLD if j >= 3 else S_LAC, S_BLACK))
    g.add(ring(.045, .006, y=-.255, col=S_RED, squash=.8))
    return g


def samurai_hand(side, katana=False):
    g = Geo()
    if katana:
        # кулак сжимает рукоять (рукоять идёт вдоль +z после поворота кисти)
        g.add(hand(S_BLACK, True, .062), r=(-88, 0, 0))
        # цука: ромбовая обмотка
        g.add(sweep([(0, 0, -.13), (0, 0, .14)], lambda s: (.021, .017), (0, 1, 0), 10,
                    lambda s, a: S_RED if (int(s * 14) + (1 if math.cos(a) > 0 else 0)) % 2 else S_BLACK))
        g.add(blob(.023, .02, .016, col=S_GOLD), pos=(0, 0, -.14))
        # цуба
        g.add(loft([(-.008, .055, .065, 0, 0, 3), (.008, .055, .065, 0, 0, 3)], 18, S_GOLD), pos=(0, 0, .15),
              r=(90, 0, 0))
        g.add(ring(.02, .007, col=S_GOLD), pos=(0, 0, .165), r=(90, 0, 0))
    else:
        g.add(hand(S_BLACK, True, .058))
    return g


def samurai_blade():
    g = Geo()
    pts = []
    for i in range(21):
        s = i / 20
        pts.append((0, .03 * s * s, .17 + 1.2 * s))
    rad = lambda s: (.0085 * (1 - max(0, s - .9) * 6), .034 * (1 - max(0, s - .88) * 7.5) + .002)
    g.add(sweep(pts, rad, (0, 1, 0), 8, lambda s, a: S_STEEL if math.cos(a) > -.3 else hexc('#9aa0b0')))
    # хамон: светящаяся кромка
    edge = [(0, .03 * (i / 20) ** 2 - .033 * (1 - max(0, i / 20 - .88) * 7.5), .17 + 1.2 * i / 20) for i in range(21)]
    g.add(sweep(edge, lambda s: (.0025, .004 * (1 - s * .7)), (0, 1, 0), 6, (1, .97, .95)), grp='glow')
    return g


def build_samurai(h):
    """Тот же скелет, что был у кубического самурая — все позы и приёмы работают без изменений"""
    from ursina import Entity as E
    K = 'samurai'
    rim = (1, .28, .2, .55)
    h.body = E(parent=h)
    h.hips = E(parent=h.body, y=.98)
    dress(h.hips, K + 'hips', samurai_hips, rim)
    h.legs = {}
    for side, name in ((-1, 'l'), (1, 'r')):
        hip = E(parent=h.hips, x=.13 * side, y=-.04)
        dress(hip, K + 'thigh', samurai_thigh, rim)
        knee = E(parent=hip, y=-.46)
        dress(knee, K + 'shin', samurai_shin, rim)
        h.legs[name] = (hip, knee)
    h.torso = E(parent=h.hips, y=.05)
    dress(h.torso, K + 'torso', samurai_torso, rim)
    h.head = E(parent=h.torso, y=.68)
    hg = E(parent=h.head, y=-0.02)   # голова чуть ниже: шея короче, скелет прежний
    dress(hg, K + 'head', samurai_head, rim)
    h.eyes = []
    # хвост волос
    h.hair = []
    base, o = S_HEAD.around(180, .25, -.01)
    par = E(parent=hg, position=base, rotation_x=-150)
    n = 4
    for i in range(n):
        dress(par, K + f'tail{i}', lambda i=i: samurai_tail_seg(i, n), rim)
        h.hair.append(par)
        par = E(parent=par, y=.12)
    # шарф
    h.scarf = []
    par = E(parent=h.torso, position=(0, .56, -.17))
    for i in range(6):
        dress(par, K + f'scarf{i}', lambda i=i: samurai_scarf_seg(i, 6), rim)
        h.scarf.append(par)
        par = E(parent=par, z=-.24)
    h.arms = {}
    for side, name in ((-1, 'l'), (1, 'r')):
        sh = E(parent=h.torso, position=(.27 * side, .48, 0))
        dress(sh, K + f'upper{name}', lambda side=side: samurai_upper_arm(side), rim)
        el = E(parent=sh, y=-.3)
        dress(el, K + 'fore', lambda side=side: samurai_forearm(side), rim)
        wr = E(parent=el, y=-.3)
        if name == 'r':
            dress(wr, K + 'handr', lambda: samurai_hand(1, True), rim)
            h.blade = E(parent=wr)
            dress(h.blade, K + 'blade', samurai_blade, (1, .5, .45, .9))
        else:
            dress(wr, K + 'handl', lambda: samurai_hand(-1), rim)
        h.arms[name] = (sh, el, wr)
    return h


# =====================================================================
# ХАНА — «Танцующая с ветром»
# =====================================================================
K_SKIN = hexc('#f8dccd')
K_SKIN_SH = hexc('#eab5a3')
K_HAIR0 = hexc('#120d18')
K_HAIR1 = hexc('#1d5a57')
K_EYE_T = hexc('#0e6f6a')
K_EYE_B = hexc('#8affe2')
K_LASH = hexc('#1a0c14')
K_SILK = hexc('#f2ece8')
K_SILK_SH = hexc('#d9cfd0')
K_RED = hexc('#d0182a')
K_RED_D = hexc('#7a0e1a')
K_BLACK = hexc('#18131c')
K_LAC = hexc('#2a1018')
K_GOLD = hexc('#e8bd62')
K_JADE = hexc('#6fffd8')

K_HEAD = Head(
    rings=[(-.003, .012, .012, .046), (.012, .034, .028, .044), (.035, .058, .055, .032), (.068, .082, .082, .019),
           (.1, .094, .095, .012), (.14, .1, .103, .003), (.18, .104, .11, -.006), (.215, .102, .112, -.014),
           (.248, .091, .102, -.018), (.272, .066, .076, -.02), (.286, .026, .032, -.02)],
    cap=[(.0, .06, .064, -.042), (.07, .106, .096, -.03), (.13, .116, .118, -.046), (.18, .12, .132, -.012),
         (.232, .116, .13, -.016), (.27, .095, .108, -.02), (.3, .052, .066, -.02), (.314, .004, .004, -.02)])


def kaze_head():
    g = Geo()
    hd = K_HEAD
    g.add(hd.mesh(lambda j, a: lerp3(K_SKIN, K_SKIN_SH, .35 if j <= 1 else 0)))
    for sd in (-1, 1):
        g.add(blob(.013, .027, .02, col=K_SKIN), pos=(.096 * sd, .118, -.004), r=(0, 0, -10 * sd))
    # большие глаза, мягкий разрез, бирюза светится
    for sd in (-1, 1):
        add_eye(g, hd, sd, .044 * sd, .112, .052, .036, .003, K_EYE_T, K_EYE_B, K_LASH, iris_r=.56,
                lash_w=(.003, .0085), flick=.014, lid_h=.008)
        g.add(hd.stroke([(sd * .024, .148), (sd * .048, .153), (sd * .07, .149)], lambda s: .0035 * (1 - s * .5),
                        .0016, hexc('#3a2028')), grp='soft')
        # алые стрелки у внешнего угла
        g.add(hd.stroke([(sd * .068, .124), (sd * .079, .13)], lambda s: .003 * (1 - s), .0046, K_RED), grp='soft')
    g.add(hd.stroke([(.0, .078), (.004, .07)], lambda s: .0016 * (1 - s), .0015, K_SKIN_SH), grp='soft')
    g.add(hd.stroke([(-.009, .042), (0, .04), (.009, .042)], .002, .0016, hexc('#c0505a')), grp='soft')
    # румянец
    for sd in (-1, 1):
        g.add(hd.decal(ellipse_pts(sd * .056, .086, .014, .006, 12), .0008, hexc('#f4b0a8')), grp='soft')
    # причёска
    g.add(hd.cap_mesh(lambda j, a: K_HAIR0))
    H0, H1 = K_HAIR0, K_HAIR1
    # прямая чёлка с острыми кончиками
    for th, y0, y1, w, dth in ((-38, .26, .15, .03, -6), (-22, .27, .138, .03, -4), (-7, .275, .13, .03, -1),
                               (8, .275, .132, .03, 2), (23, .27, .14, .03, 5), (38, .26, .152, .028, 7),
                               (-14, .28, .16, .034, -14), (15, .28, .16, .034, 14)):
        g.add(lock(hd, th, y0, y1, w, .01, dtheta=dth, off0=.011, off1=.018, col0=H0, col1=lerp3(H0, H1, .3)))
    # длинные пряди у лица до груди
    for sd in (-1, 1):
        a, _ = hd.around(70 * sd, .2, .018)
        pts = bez(a, add(a, (.012 * sd, -.1, .01)), add(a, (.022 * sd, -.2, .03)), add(a, (.015 * sd, -.33, .03)), 12)
        g.add(free_lock(pts, .022, .008, (sd, 0, .3), H0, H1))
        a, _ = hd.around(56 * sd, .22, .016)
        pts = bez(a, add(a, (.01 * sd, -.06, .012)), add(a, (.015 * sd, -.11, .02)), add(a, (.01 * sd, -.16, .02)), 8)
        g.add(free_lock(pts, .018, .007, (sd, 0, .4), H0, lerp3(H0, H1, .5)))
    # гладкий затылок
    for th in range(95, 266, 17):
        g.add(lock(hd, th, .29, .02, .04, .012, dtheta=(-6 if th < 180 else 6), off0=.008, off1=.02, flick=.0,
                   col0=H0, col1=lerp3(H0, H1, .4)))
    for th in (-130, 130, -160, 160, 180, -100, 100):
        g.add(lock(hd, th, .31, .15, .04, .012, dtheta=(8 if th < 0 else -8), off0=.01, off1=.016, col0=H0, col1=H0))
    # высокий хвост: основание, алая лента, кандзаси
    base, o = hd.around(180, .25, .0)
    g.add(blob(.038, .032, .036, col=K_HAIR0), pos=add(base, (0, .01, -.01)))
    g.add(ring(.03, .009, col=K_RED), pos=add(base, (0, .01, -.035)), r=(-55, 0, 0))
    for sd in (-1, 1):
        a = add(base, (0, .01, -.04))
        pts = bez(a, add(a, (.04 * sd, .01, -.02)), add(a, (.07 * sd, -.04, -.03)), add(a, (.08 * sd, -.11, -.02)), 8)
        g.add(free_lock(pts, .014, .003, (0, 0, -1), K_RED, K_RED_D))
    pin0 = add(base, (.02, .03, .0))
    g.add(sweep([pin0, add(pin0, (.06, .07, .02))], lambda s: (.004, .004), (0, 0, 1), 6, K_GOLD))
    g.add(blob(.014, .014, .014, col=K_JADE), grp='glow', pos=add(pin0, (.066, .077, .022)))
    for k in range(5):
        a = TAU * k / 5
        g.add(blob(.012, .006, .016, col=K_RED), pos=add(pin0, (.064 + math.cos(a) * .016, .06 + math.sin(a) * .016, .03)),
              r=(0, 0, math.degrees(a)))
    return g


def kaze_tail_seg(i, n):
    g = Geo()
    k0, k1 = i / n, (i + 1) / n
    H0 = lerp3(K_HAIR0, K_HAIR1, max(0, k0 - .3) * 1.1)
    H1 = lerp3(K_HAIR0, K_HAIR1, max(0, k1 - .2) * 1.1)
    R0 = .042 * (1 - k0 * .5)
    last = i == n - 1
    L = .12 if not last else .2
    for j in range(7):
        a = TAU * j / 7 + i * .4
        dx, dz = math.sin(a), math.cos(a)
        p0 = (dx * R0 * .35, -.012, dz * R0 * .35)
        p3 = (dx * R0 * .35, L, dz * R0 * .35)
        pts = bez(p0, add(p0, (dx * R0 * .5, L * .35, dz * R0 * .5)), add(p3, (dx * R0 * .5, -L * .35, dz * R0 * .5)),
                  p3, 6)
        w = R0 * .85
        rad = (lambda s, w=w: (w * (1 - s) ** .85 + .001, w * .42 * (1 - s) ** .6 + .001)) if last else \
              (lambda s, w=w: (w * (1 - .3 * s), w * .42))
        g.add(sweep(pts, rad, (dx, 0, dz), 7, lambda s, a_, H0=H0, H1=H1: lerp3(H0, H1, s)))
    return g


def kaze_torso():
    g = Geo()
    body = [(-.02, .1, .08), (.06, .104, .08), (.16, .118, .088), (.26, .132, .1, 0, .01), (.33, .14, .1, 0, .012),
            (.4, .15, .088, 0, .004), (.45, .135, .078), (.51, .07, .055)]
    g.add(loft(body, 20, lambda j, a: K_SILK if j > 1 else K_SILK_SH))
    g.add(limb(.44, .66, .043, .039, K_SKIN, rings=4))
    # алый запах ворота
    for sd in (1, -1):
        pts = []
        for k in range(12):
            s = k / 11
            y = lerp(.48, .14, s)
            x = sd * lerp(.045, -.03, s ** .8)
            z = lerp(.035, .1, min(1, s * 2.2)) + .006
            pts.append((x, y, z))
        g.add(sweep(pts, lambda s: (.016, .004), (0, 0, 1), 6, K_RED))
    # широкий оби с золотым шнуром
    g.add(loft([(.0, .108, .085), (.01, .112, .09), (.14, .122, .096), (.15, .118, .092)], 22, K_RED))
    g.add(ring(.117, .005, y=.075, col=K_GOLD, squash=.8), s=(1, 1, .8))
    g.add(blob(.02, .02, .012, col=K_JADE), grp='glow', pos=(0, .075, .1))
    # бант сзади
    for sd in (-1, 1):
        pts = [(0, .08, -.1)]
        for k in range(1, 15):
            a = math.pi * k / 14
            pts.append((sd * (.02 + .08 * math.sin(a)), .08 + .05 * math.sin(a * 2) * .5 + .04 * math.sin(a),
                        -.11 - .03 * math.sin(a)))
        pts.append((0, .08, -.1))
        g.add(sweep(pts, lambda s: (.022, .006), (0, 0, -1), 6, K_RED))
    g.add(blob(.026, .024, .018, col=K_RED_D), pos=(0, .08, -.105))
    # лакированный наплечник слева
    g.add(shell([(.5, .06, .07, -.19, 0), (.46, .085, .09, -.19, 0), (.41, .094, .099, -.2, 0), (.4, .095, .1, -.2, 0)],
                .01, 16, -175, -5, lambda j, a: K_GOLD if j >= 3 else K_LAC, K_BLACK))
    return g


def kaze_ribbon_seg(i, n):
    g = Geo()
    for sd in (-1, 1):
        k = i / n
        w0 = .034 - i * .004
        w1 = .034 - (i + 1) * .004
        last = i == n - 1
        pts = [(sd * .05, 0, .0), (sd * (.05 + .006), 0, -.08), (sd * .05, 0, -.17)]
        rad = (lambda s: (lerp(w0, .003, s), .004)) if last else (lambda s: (lerp(w0, w1, s), .004))
        g.add(sweep(pts, rad, (0, 1, 0), 6, lambda s, a: lerp3(K_RED, K_RED_D, k + s / n)))
    return g


def kaze_hips():
    g = Geo()
    g.add(shell([(.04, .11, .086), (-.04, .132, .108), (-.12, .15, .125)], .008, 28,
                col_out=lambda j, a: lerp3(K_RED, K_RED_D, .4 * (math.cos(a * 8) * .5 + .5)), col_in=K_RED_D,
                wave=(.04, 8)))
    g.add(loft([(-.06, .1, .08), (.04, .108, .084)], 18, K_BLACK))
    return g


def kaze_thigh():
    g = Geo()
    g.add(limb(.02, -.45, .068, .046, K_BLACK, bulge=.08))
    pleat = lambda j, a: K_SILK if j >= 4 else lerp3(K_RED, K_RED_D, .55 * (math.cos(a * 5) * .5 + .5))
    g.add(shell([(.05, .085, .09), (-.08, .112, .118), (-.2, .138, .145), (-.27, .152, .16), (-.285, .155, .163)],
                .008, 25, col_out=pleat, col_in=K_RED_D, wave=(.06, 5)))
    return g


def kaze_shin():
    g = Geo()
    g.add(limb(.03, -.4, .047, .03, K_BLACK, bulge=.12))
    g.add(shell([(-.04, .052, .052), (-.055, .052, .052), (-.18, .05, .05), (-.33, .038, .038)], .007, 14, -70, 70,
                lambda j, a: K_GOLD if j == 0 else K_LAC, K_BLACK))
    g.add(ring(.04, .006, y=-.35, col=K_GOLD))
    g.add(foot(K_BLACK, K_RED_D, L=.18, W=.06, H=.065), pos=(0, -.43, .04))
    return g


def kaze_upper_arm(side):
    g = Geo()
    g.add(blob(.05, .05, .05, col=K_SILK), pos=(0, -.025, 0))
    g.add(limb(-.02, -.27, .043, .036, K_SILK))
    rows = [(.02, .054, .054), (-.06, .058, .06), (-.15, .068, .08, 0, -.008, .01), (-.25, .084, .108, 0, -.024, .03),
            (-.33, .094, .13, 0, -.04, .05), (-.345, .094, .132, 0, -.042, .052), (-.355, .093, .132, 0, -.043, .053)]
    g.add(shell(rows, .007, 24, col_out=lambda j, a: K_RED if j >= 5 else (K_SILK if j < 3 else K_SILK_SH),
                col_in=K_RED))
    return g


def kaze_forearm(side):
    g = Geo()
    g.add(limb(0, -.26, .036, .03, K_SKIN, bulge=.08))
    g.add(shell([(-.06, .042, .042), (-.072, .042, .042), (-.15, .04, .04), (-.24, .034, .034)], .007, 14, -90, 90,
                lambda j, a: K_GOLD if j == 0 else K_LAC, K_BLACK))
    g.add(ring(.033, .005, y=-.245, col=K_GOLD))
    return g


def kaze_hand():
    g = Geo()
    g.add(hand(K_SKIN, True, .048))
    return g


def kaze_fan():
    """Боевой веер: сектор вдоль -y, бумага от белого к бирюзе, алые спицы"""
    g = Geo()
    r, a0, a1, segs = .46, -78, 78, 20
    poly = [(0.0, 0.0)]
    for i in range(segs + 1):
        a = math.radians(a0 + (a1 - a0) * i / segs)
        poly.append((math.sin(a) * r, -math.cos(a) * r))
    poly.append((0.0, 0.0))

    def col(x, y):
        d = math.hypot(x, y) / r
        if d > .93:
            return K_RED
        return lerp3(K_SILK, hexc('#5fe8c8'), max(0.0, (d - .45) / .5) ** 1.4)
    pl = [(0.0, -.06)] + [p for p in poly[1:-1]]
    g.add(slab(pl + [pl[0]], .006, col, center=(0, -.25)))
    for i in range(0, segs + 1, 4):
        a = math.radians(a0 + (a1 - a0) * i / segs)
        pts = [(math.sin(a) * .03, -math.cos(a) * .03, .0), (math.sin(a) * r * .97, -math.cos(a) * r * .97, .0)]
        g.add(sweep(pts, lambda s: (.007, .009), (0, 0, 1), 6, K_LAC), grp='soft')
    g.add(sweep([(0, .03, 0), (0, -.06, 0)], lambda s: (.016, .016), (0, 0, 1), 8, K_RED))
    g.add(ring(.012, .004, col=K_GOLD), pos=(0, .03, 0), r=(90, 0, 0))
    return g


def build_kaze(h):
    from ursina import Entity as E
    K = 'kaze'
    rim = (.3, 1, .85, .45)
    h.body = E(parent=h)
    h.hips = E(parent=h.body, y=.95)
    dress(h.hips, K + 'hips', kaze_hips, rim)
    h.legs = {}
    for side, name in ((-1, 'l'), (1, 'r')):
        hip = E(parent=h.hips, x=.09 * side, y=-.04)
        dress(hip, K + 'thigh', kaze_thigh, rim)
        knee = E(parent=hip, y=-.45)
        dress(knee, K + 'shin', kaze_shin, rim)
        h.legs[name] = (hip, knee)
    h.torso = E(parent=h.hips, y=.06)
    dress(h.torso, K + 'torso', kaze_torso, rim)
    h.head = E(parent=h.torso, y=.62)
    hg = E(parent=h.head, y=-0.028)   # голова чуть ниже: шея короче, скелет прежний
    dress(hg, K + 'head', kaze_head, rim)
    h.eyes = []
    h.hair = []
    base, o = K_HEAD.around(180, .255, -.025)
    par = E(parent=hg, position=add(base, (0, .01, 0)), rotation_x=-150)
    n = 6
    for i in range(n):
        dress(par, K + f'tail{i}', lambda i=i: kaze_tail_seg(i, n), rim)
        h.hair.append(par)
        par = E(parent=par, y=.11)
    h.scarf = []
    par = E(parent=h.torso, position=(0, .07, -.12))
    for i in range(4):
        dress(par, K + f'rib{i}', lambda i=i: kaze_ribbon_seg(i, 4), rim)
        h.scarf.append(par)
        par = E(parent=par, z=-.16)
    h.arms = {}
    h.fans = []
    for side, name in ((-1, 'l'), (1, 'r')):
        sh = E(parent=h.torso, position=(.2 * side, .44, 0))
        dress(sh, K + 'upper', lambda side=side: kaze_upper_arm(side), rim)
        el = E(parent=sh, y=-.27)
        dress(el, K + 'fore', lambda side=side: kaze_forearm(side), rim)
        wr = E(parent=el, y=-.26)
        dress(wr, K + 'hand', kaze_hand, rim)
        fan = E(parent=wr, y=-.05)
        dress(fan, K + 'fan', kaze_fan, rim)
        h.fans.append(fan)
        h.arms[name] = (sh, el, wr)
    return h


# =====================================================================
# ЖИВОЕ ЛИЦО: веки, брови и рот — отдельные кусочки, которые двигает игра
# =====================================================================
def _part_entity(parent, raw, pivot, rim=(1, .3, .25, .4), grp='soft'):
    """Кусочек лица отдельной сущностью: вершины сдвинуты так, что pivot — его начало координат"""
    from ursina import Entity as E
    g = Geo()
    g.add(raw, pos=(-pivot[0], -pivot[1], -pivot[2]), grp=grp)
    e = E(parent=parent, position=pivot, model=_mesh(g.g[grp]))
    if grp == 'glow':
        e.shader = FLAT
    else:
        e.shader = STATE['fallback'] if (STATE['safe'] and STATE['fallback']) else TOON
        e.set_shader_input('toon_rim', Vec4(*rim))
        TOON_ENTS.append(e)
    return e


def _eye_curves(ex, ey, w, h, tilt, side):
    def top(u):
        return ey + h * .55 * max(0.0, 1 - u * u) ** .55 + tilt * u

    def bot(u):
        return ey - h * .45 * max(0.0, 1 - u * u) ** .9 + tilt * u - .002 * u

    def X(u):
        return ex + side * u * w / 2
    return top, bot, X


def build_face(hg, hd, spec):
    """spec: skin, lash, eyes [(ex, ey, w, h, tilt, side)], brows [(pts, w0, col, side)], mouth dict.
    Возвращает словарь сущностей для анимации"""
    face = {'lids': [], 'brows': [], 'side': []}
    for ex, ey, w, h, tilt, side in spec['eyes']:
        top, bot, X = _eye_curves(ex, ey, w * 1.08, h * 1.15, tilt, side)
        us = [-1 + 2 * i / 16 for i in range(17)]
        poly = [(X(u), top(u) + .001) for u in us] + [(X(u), bot(u) - .0012) for u in reversed(us[1:-1])]
        R = hd.decal(poly, .0039, spec['skin'], center=(ex, ey))
        # линия ресниц на нижнем краю закрытого века
        lash = hd.stroke([(X(u), bot(u)) for u in [-1 + 2 * i / 12 for i in range(13)]],
                         lambda s: .0016 + .0016 * math.sin(math.pi * s), .0043, spec['lash'])
        g = Geo()
        g.add(R, grp='soft')
        g.add(lash, grp='soft')
        py = top(0) + .001
        pivot = (ex, py, hd.surf_z(ex, py))
        e = _part_entity(hg, g.g['soft'], pivot)
        e.scale_y = .02
        face['lids'].append(e)
        face['side'].append(side)
    for pts, w0, col, side in spec['brows']:
        cx = sum(p[0] for p in pts) / len(pts)
        cy = sum(p[1] for p in pts) / len(pts)
        R = hd.stroke(pts, lambda s, w0=w0: w0 * (1 - s * .45) + .0006, .0022, col)
        e = _part_entity(hg, R, (cx, cy, hd.surf_z(cx, cy)))
        e.base_y = e.y
        face['brows'].append((e, side))
    m = spec['mouth']
    mx, my, mw = m['x'], m['y'], m['w']
    # верхняя губа / линия рта
    line = hd.stroke([(mx - mw / 2, my + .001), (mx - mw / 4, my - .0005), (mx, my), (mx + mw / 4, my - .0005),
                      (mx + mw / 2, my + .001)], lambda s: m['line_w'] * (.55 + .45 * math.sin(math.pi * s)), .0019,
                     m['line'])
    face['mouth_line'] = _part_entity(hg, line, (mx, my, hd.surf_z(mx, my)))
    # улыбка: уголки вверх
    sm = hd.stroke([(mx - mw * .55, my + .006), (mx - mw * .28, my - .0015), (mx, my - .003),
                    (mx + mw * .28, my - .0015), (mx + mw * .55, my + .006)],
                   lambda s: m['line_w'] * (.5 + .5 * math.sin(math.pi * s)), .0019, m['line'])
    face['mouth_smile'] = _part_entity(hg, sm, (mx, my, hd.surf_z(mx, my)))
    face['mouth_smile'].enabled = False
    # открытый рот: тёмный овал с полоской зубов, растёт вниз от линии рта
    ow, oh = mw * .42, m.get('open_h', .014)
    oval = hd.decal(ellipse_pts(mx, my - oh * .5, ow, oh * .5, 16), .0017,
                    lambda x, y: lerp3(m['inside'], (0.0, 0.0, 0.0), .3), center=(mx, my - oh * .5))
    teeth = hd.decal(ellipse_pts(mx, my - oh * .12, ow * .8, oh * .14, 12), .0019, (0.96, 0.94, 0.92))
    g = Geo()
    g.add(oval, grp='soft')
    g.add(teeth, grp='soft')
    e = _part_entity(hg, g.g['soft'], (mx, my, hd.surf_z(mx, my)))
    e.scale_y = .02
    face['mouth_open'] = e
    # нижняя губа: опускается вместе с челюстью
    lw = m.get('lower_w', mw * .5)
    lip = hd.decal(ellipse_pts(mx, my - .0055, lw * .5, .0032, 14), .0016, m['lip'])
    e = _part_entity(hg, lip, (mx, my - .0055, hd.surf_z(mx, my - .0055)))
    e.base_y = e.y
    face['lower_lip'] = e
    face['mouth_y'] = my
    face['open_h'] = oh
    return face


# =====================================================================
# АСАХИ — по фото: тёмно-каштановая растрёпанная чёлка до бровей, густые прямые брови,
# спокойный тяжёлый взгляд, круглое лицо, чёрный пуховик, часы на левой руке
# =====================================================================
A_SKIN = hexc('#ecc4a6')
A_SKIN_SH = hexc('#d29a7f')
A_HAIR0 = hexc('#1a110d')
A_HAIR1 = hexc('#47301f')
A_IRIS_T = hexc('#24130b')
A_IRIS_B = hexc('#6e4b33')
A_LASH = hexc('#140b08')
A_BROW = hexc('#160d09')
A_JACKET = hexc('#15161b')
A_JACKET_HI = hexc('#30323b')
A_ZIP = hexc('#5c5e66')
A_PANTS = hexc('#1d1d24')

A_HEAD = Head(
    rings=[(-.004, .014, .013, .05), (.012, .044, .034, .048), (.035, .072, .062, .034), (.07, .097, .09, .02),
           (.105, .107, .101, .012), (.145, .109, .108, .002), (.185, .11, .116, -.008), (.225, .108, .118, -.016),
           (.26, .096, .107, -.02), (.285, .07, .08, -.022), (.3, .028, .034, -.022)],
    cap=[(.015, .066, .07, -.045), (.075, .114, .102, -.034), (.135, .125, .127, -.05), (.19, .131, .143, -.014),
         (.245, .128, .142, -.018), (.29, .106, .12, -.022), (.322, .06, .074, -.022), (.338, .004, .004, -.022)])

ASAHI_FACE = dict(
    skin=A_SKIN, lash=A_LASH,
    eyes=[(.046 * sd, .116, .047, .021, .0015, sd) for sd in (-1, 1)],
    brows=[([(sd * .016, .141), (sd * .04, .147), (sd * .069, .146)], .0098, A_BROW, sd) for sd in (-1, 1)],
    mouth=dict(x=0.0, y=.046, w=.036, line=hexc('#93564d'), line_w=.0027, lip=hexc('#c98a7a'),
               inside=hexc('#4a1418'), open_h=.017, lower_w=.03))


def asahi_head():
    g = Geo()
    hd = A_HEAD
    g.add(hd.mesh(lambda j, a: lerp3(A_SKIN, A_SKIN_SH, .35 if j <= 1 else 0)))
    for sd in (-1, 1):
        g.add(blob(.015, .031, .023, col=A_SKIN), pos=(.108 * sd, .123, -.004), r=(0, 0, -10 * sd))
    for sd in (-1, 1):
        add_eye(g, hd, sd, .046 * sd, .116, .047, .021, .0015, A_IRIS_T, A_IRIS_B, A_LASH, iris_r=.56,
                lash_w=(.003, .0055), flick=.004, glow_iris=False)
    # нос: заметная спинка и кончик, тень у ноздрей
    g.add(hd.stroke([(.005, .1), (.008, .082), (.007, .07)], lambda s: .0026 * (1 - s * .4), .0015, A_SKIN_SH),
          grp='soft')
    g.add(hd.decal(ellipse_pts(0, .064, .013, .0045, 14), .0012, lerp3(A_SKIN, A_SKIN_SH, .6)), grp='soft')
    for sd in (-1, 1):
        g.add(hd.decal(ellipse_pts(sd * .007, .062, .0028, .0016, 8), .0014, hexc('#a8705e')), grp='soft')
    # родинка на щеке
    g.add(hd.decal(ellipse_pts(.036, .086, .0022, .0022, 8), .0013, hexc('#7a4a3a')), grp='soft')
    # причёска: каштановая, густая, чёлка до бровей
    g.add(hd.cap_mesh(lambda j, a: A_HAIR0))
    H0, H1 = A_HAIR0, A_HAIR1
    jit = [.006, -.004, .008, -.002, .004, -.007, .003, .007, -.005, .002, -.006]
    for i, th in enumerate(range(-50, 51, 10)):
        y1 = .168 + jit[i] + (.012 if abs(th) > 35 else 0)
        g.add(lock(hd, th, .3, y1, .03, .012, dtheta=jit[(i + 3) % 11] * 900, off0=.013, off1=.021, flick=.004,
                   col0=H0, col1=H1))
    for th in (-36, -20, -4, 12, 28, 42):
        g.add(lock(hd, th, .325, .2, .034, .013, dtheta=th * .2, off0=.02, off1=.03, flick=.006, col0=H0,
                   col1=lerp3(H0, H1, .6)))
    for sd in (-1, 1):
        for th in (60, 72, 84, 96):
            g.add(lock(hd, th * sd, .28, .14, .03, .011, dtheta=4 * sd, off0=.012, off1=.02, col0=H0, col1=H1))
    for th in range(105, 256, 15):
        g.add(lock(hd, th, .31, .06, .04, .014, dtheta=(-6 if th < 180 else 6), off0=.013, off1=.028, flick=.01,
                   col0=H0, col1=H1))
    # пара непослушных прядей на макушке
    for th, tp in ((-20, (-.03, .045, .02)), (15, (.02, .05, .03)), (160, (.03, .04, -.04)), (-140, (-.03, .035, -.04))):
        a, o = hd.around(th, .315, .004)
        pts = bez(a, add(a, (tp[0] * .3, .02, tp[2] * .3)), add(a, (tp[0] * .7, tp[1], tp[2] * .7)), add(a, tp), 7)
        g.add(free_lock(pts, .022, .009, o, H0, H1))
    return g


def _puffer(g, rings, col, hi, bands):
    """Пуховик: тело + выпуклые стёганые полосы"""
    g.add(loft(rings, 22, col))
    for y in bands:
        rr = Head._at([(r[0], r[1], r[2], r[4] if len(r) > 4 else 0.0) for r in rings], y)
        rx, rz, cz = rr
        pts = [(math.sin(TAU * i / 24) * rx, y, cz + math.cos(TAU * i / 24) * rz) for i in range(25)]
        g.add(sweep(pts, lambda s: (.012, .011), (0, 1, 0), 6, hi, caps=(False, False)))


def asahi_torso():
    g = Geo()
    body = [(-.08, .17, .13), (-.04, .19, .145), (.06, .195, .145), (.18, .2, .14, 0, .006), (.3, .21, .14, 0, .01),
            (.4, .225, .135, 0, .006), (.48, .218, .126), (.55, .18, .104), (.6, .095, .078)]
    _puffer(g, body, A_JACKET, lerp3(A_JACKET, A_JACKET_HI, .6), (.0, .1, .2, .3, .4))
    g.add(limb(.5, .74, .058, .054, A_SKIN, depth=1.05, rings=4))
    # белая футболка у горла и высокий дутый воротник с капюшоном
    g.add(ring(.062, .008, y=.555, col=hexc('#e8e6e2'), squash=.9), s=(1, 1, .95))
    g.add(ring(.088, .032, y=.585, col=A_JACKET, squash=.9), pos=(0, 0, -.006), s=(1.12, 1, 1))
    g.add(blob(.09, .05, .045, col=A_JACKET), pos=(0, .6, -.11))
    # молния
    pts = []
    for k in range(14):
        y = lerp(.56, -.07, k / 13)
        rr = Head._at([(r[0], r[1], r[2], r[4] if len(r) > 4 else 0.0) for r in body], y)
        pts.append((0, y, rr[2] + rr[1] + .013))
    g.add(sweep(pts, lambda s: (.004, .003), (0, 0, 1), 6, A_ZIP), grp='soft')
    # лямка рюкзака через правое плечо
    pts = [(.12, .56, .02), (.15, .5, .12), (.14, .35, .15), (.12, .2, .155)]
    g.add(sweep(bez(*pts, 8), lambda s: (.018, .005), (0, 0, 1), 6, hexc('#0c0c10')))
    return g


def asahi_upper_arm(side):
    g = Geo()
    g.add(blob(.075, .072, .07, col=A_JACKET), pos=(0, -.03, 0))
    g.add(limb(-.03, -.3, .07, .062, A_JACKET))
    for y in (-.1, -.2):
        g.add(ring(.07, .011, y=y, col=lerp3(A_JACKET, A_JACKET_HI, .6)))
    return g


def asahi_forearm(side):
    g = Geo()
    g.add(limb(0, -.25, .062, .05, A_JACKET, bulge=.08))
    g.add(ring(.06, .01, y=-.11, col=lerp3(A_JACKET, A_JACKET_HI, .6)))
    g.add(ring(.05, .012, y=-.235, col=hexc('#0c0c10')))
    g.add(limb(-.24, -.29, .034, .032, A_SKIN, rings=2))
    if side < 0:
        # смарт-часы на левом запястье
        g.add(ring(.036, .007, y=-.265, col=hexc('#0d0d10')))
        g.add(loft([(-.004, .021, .021, 0, 0, 2), (.004, .021, .021, 0, 0, 2)], 18, hexc('#2c2e34')),
              pos=(-.04, -.265, 0), r=(0, 0, 90))
        g.add(loft([(-.003, .016, .016, 0, 0, 2), (.003, .016, .016, 0, 0, 2)], 18, hexc('#050507')),
              pos=(-.044, -.265, 0), r=(0, 0, 90))
    return g


def asahi_hand(side, katana=False):
    g = Geo()
    if katana:
        g.add(hand(A_SKIN, True, .058), r=(-88, 0, 0))
        g.add(sweep([(0, 0, -.13), (0, 0, .14)], lambda s: (.021, .017), (0, 1, 0), 10,
                    lambda s, a: S_RED if (int(s * 14) + (1 if math.cos(a) > 0 else 0)) % 2 else S_BLACK))
        g.add(blob(.023, .02, .016, col=S_GOLD), pos=(0, 0, -.14))
        g.add(loft([(-.008, .055, .065, 0, 0, 3), (.008, .055, .065, 0, 0, 3)], 18, S_GOLD), pos=(0, 0, .15),
              r=(90, 0, 0))
        g.add(ring(.02, .007, col=S_GOLD), pos=(0, 0, .165), r=(90, 0, 0))
    else:
        g.add(hand(A_SKIN, True, .054))
    return g


def asahi_hips():
    g = Geo()
    # низ пуховика и тёмные штаны
    g.add(loft([(-.12, .165, .125), (-.04, .18, .135), (.06, .178, .133)], 22, A_PANTS))
    g.add(ring(.178, .012, y=-.05, col=A_JACKET, squash=.8), s=(1, 1, .76))
    def saya_line(t):
        return (-.21 + .01 * t, -.04 + .2 * (1 - t) - .22 * t, .2 - .9 * t)
    pts = [saya_line(i / 12) for i in range(13)]
    g.add(sweep(pts, lambda s: (.022, .016), (1, 0, 0), 10, lambda s, a: S_GOLD if s < .06 else (
        S_RED_D if s > .95 else S_LAC)))
    return g


def asahi_thigh():
    g = Geo()
    g.add(limb(.03, -.46, .088, .066, A_PANTS))
    return g


def asahi_shin():
    g = Geo()
    g.add(limb(.02, -.4, .064, .05, A_PANTS))
    g.add(loft([(-.3, .056, .06), (-.38, .054, .058), (-.42, .056, .06)], 16, hexc('#101014')))
    g.add(foot(hexc('#18181c'), hexc('#d8d6d0'), L=.23, W=.08, H=.085), pos=(0, -.44, .045))
    return g


def samurai_obi_rope():
    """Золотой шнур поверх оби с узлом и кистью, как на концепте"""
    g = Geo()
    g.add(ring(.18, .008, y=.012, col=S_GOLD, squash=.8), s=(1, 1, .77))
    g.add(ring(.18, .007, y=-.02, col=S_GOLD, squash=.8), s=(1, 1, .77))
    knot = (.07, -.005, .138)
    g.add(blob(.022, .02, .016, col=S_GOLD), pos=knot)
    for dx, ln in ((-.012, .14), (.012, .17)):
        a = add(knot, (dx, -.01, .004))
        g.add(sweep(bez(a, add(a, (0, -.04, .008)), add(a, (dx, -ln * .7, .01)), add(a, (dx * 1.5, -ln, .006)), 6),
                    lambda s: (.0045, .0045), (0, 0, 1), 6, S_GOLD))
        tip = add(a, (dx * 1.5, -ln, .006))
        g.add(loft([(0, .004, .004), (-.012, .013, .011), (-.05, .016, .014), (-.055, .004, .004)], 10,
                   hexc('#c99a48')), pos=tip)
    return g


def asahi_robe_thigh():
    """Хакама + длинные полы хаори до голени: чёрные, к подолу языки алого пламени"""
    g = samurai_thigh()

    def flame(j, a):
        k = j / 5
        lick = .5 + .5 * math.sin(a * 7 + 1.1) * math.sin(a * 3.3)
        return lerp3(S_BLACK, S_RED, max(0.0, min(1.0, (k - .45) * 2.4 + lick * .55 * (k > .4))))
    g.add(shell([(.06, .15, .155), (-.08, .16, .165), (-.22, .17, .175), (-.36, .178, .184), (-.5, .184, .19),
                 (-.56, .185, .191)], .009, 26, 35, 325, flame, S_RED_D, wave=(.03, 7)))
    return g


def asahi_battle_torso():
    g = samurai_torso()
    return g


def build_asahi(h):
    """Асахи по концепту: лицо и причёска по фото, боевой наряд ронина"""
    from ursina import Entity as E
    K = 'samurai'
    rim = (1, .28, .2, .55)
    h.body = E(parent=h)
    h.hips = E(parent=h.body, y=.98)
    dress(h.hips, K + 'hips', samurai_hips, rim)
    dress(h.hips, 'asahi_rope', samurai_obi_rope, rim)
    h.legs = {}
    for side, name in ((-1, 'l'), (1, 'r')):
        hip = E(parent=h.hips, x=.13 * side, y=-.04)
        dress(hip, 'asahi_robe', asahi_robe_thigh, rim)
        knee = E(parent=hip, y=-.46)
        dress(knee, K + 'shin', samurai_shin, rim)
        h.legs[name] = (hip, knee)
    h.torso = E(parent=h.hips, y=.05)
    dress(h.torso, K + 'torso', samurai_torso, rim)
    h.head = E(parent=h.torso, y=.68)
    hg = E(parent=h.head, y=-0.02)
    dress(hg, 'asahi' + 'head', asahi_head, rim)
    h.face = build_face(hg, A_HEAD, ASAHI_FACE)
    h.face['lid_base'] = .2
    h.eyes = []
    h.hair = []
    h.scarf = []
    par = E(parent=h.torso, position=(0, .56, -.17))
    for i in range(6):
        dress(par, K + f'scarf{i}', lambda i=i: samurai_scarf_seg(i, 6), rim)
        h.scarf.append(par)
        par = E(parent=par, z=-.24)
    h.arms = {}
    for side, name in ((-1, 'l'), (1, 'r')):
        sh = E(parent=h.torso, position=(.27 * side, .48, 0))
        dress(sh, K + f'upper{name}', lambda side=side: samurai_upper_arm(side), rim)
        el = E(parent=sh, y=-.3)
        dress(el, K + 'fore', lambda side=side: samurai_forearm(side), rim)
        wr = E(parent=el, y=-.3)
        if name == 'r':
            dress(wr, K + 'handr', lambda: samurai_hand(1, True), rim)
            h.blade = E(parent=wr)
            dress(h.blade, K + 'blade', samurai_blade, (1, .5, .45, .9))
        else:
            dress(wr, K + 'handl', lambda: samurai_hand(-1), rim)
        h.arms[name] = (sh, el, wr)
    return h


# =====================================================================
# ХАРУКАЗЭ — по фото: длинные волнистые каштановые волосы с карамельными концами, шторка-чёлка
# на пробор, тонкие очки в светлой оправе, белый верх и чёрное длинное пальто внакидку
# =====================================================================
H_SKIN = hexc('#f6dac8')
H_SKIN_SH = hexc('#e0b09a')
H_HAIR0 = hexc('#2b1a12')
H_HAIR1 = hexc('#94603c')
H_IRIS_T = hexc('#2a170e')
H_IRIS_B = hexc('#7c5538')
H_LASH = hexc('#150a0a')
H_BROW = hexc('#3a2418')
H_LIP = hexc('#c86e6c')
H_COAT = hexc('#131317')
H_COAT_HI = hexc('#292a31')
H_TOP = hexc('#f1ede8')
H_TOP_SH = hexc('#d8d0cb')
H_GLASS = hexc('#dccaa4')
# та же голова, но волосы у лба отодвинуты назад — виден лоб под пробором
H_HEAD = Head(rings=K_HEAD.rings,
              cap=[(.0, .06, .064, -.042), (.07, .106, .096, -.03), (.13, .116, .112, -.05), (.18, .12, .118, -.03),
                   (.232, .116, .118, -.026), (.27, .095, .104, -.022), (.3, .052, .066, -.02), (.314, .004, .004, -.02)])

HARU_FACE = dict(
    skin=H_SKIN, lash=H_LASH,
    eyes=[(.044 * sd, .112, .05, .03, .002, sd) for sd in (-1, 1)],
    brows=[([(sd * .021, .146), (sd * .046, .153), (sd * .07, .149)], .0036, H_BROW, sd) for sd in (-1, 1)],
    mouth=dict(x=0.0, y=.042, w=.027, line=hexc('#a8484c'), line_w=.0023, lip=H_LIP,
               inside=hexc('#5a1a20'), open_h=.013, lower_w=.028))


def _wavy(a, sd, length, spread, z_end, amp, phase, n=14, start_dir=(0, -1, 0)):
    pts = []
    for i in range(n):
        s = i / (n - 1)
        y = a[1] - length * s
        x = a[0] + sd * spread * s ** 1.2 + amp * math.sin(s * math.pi * 3.0 + phase) * min(1, s * 3)
        z = lerp(a[2], z_end, min(1, s * 1.6))
        pts.append((x, y, z))
    return pts


def haru_head():
    g = Geo()
    hd = H_HEAD
    g.add(hd.mesh(lambda j, a: lerp3(H_SKIN, H_SKIN_SH, .35 if j <= 1 else 0)))
    for sd in (-1, 1):
        g.add(blob(.013, .027, .02, col=H_SKIN), pos=(.096 * sd, .118, -.004), r=(0, 0, -10 * sd))
    for sd in (-1, 1):
        add_eye(g, hd, sd, .044 * sd, .112, .05, .03, .002, H_IRIS_T, H_IRIS_B, H_LASH, iris_r=.55,
                lash_w=(.003, .008), flick=.01, glow_iris=False, lid_h=.007)
    g.add(hd.stroke([(.0, .08), (.004, .07)], lambda s: .0016 * (1 - s), .0015, H_SKIN_SH), grp='soft')
    g.add(hd.decal(ellipse_pts(0, .063, .009, .0033, 12), .0012, lerp3(H_SKIN, H_SKIN_SH, .5)), grp='soft')
    for sd in (-1, 1):
        g.add(hd.decal(ellipse_pts(sd * .056, .084, .014, .006, 12), .0008, hexc('#f2b4aa')), grp='soft')
    # очки: тонкая светлая оправа, перемычка и дужки к ушам
    for sd in (-1, 1):
        cx, cy, rx, ry = sd * .046, .113, .031, .022
        zc = hd.surf_z(cx, cy) + .013
        pts = []
        for i in range(33):
            a = TAU * i / 32
            ca, sa = math.cos(a), math.sin(a)
            # скруглённый прямоугольник
            x = cx + rx * math.copysign(abs(ca) ** .6, ca)
            y = cy + ry * math.copysign(abs(sa) ** .6, sa)
            z = zc - .006 * ((x - cx) / rx) ** 2 * (1 if (x - cx) * sd > 0 else .3)
            pts.append((x, y, z))
        g.add(sweep(pts, lambda s: (.0016, .0016), (0, 0, 1), 6, H_GLASS, caps=(False, False)), grp='soft')
        # лёгкий блик на стекле
        g.add(hd.decal(ellipse_pts(cx - .012 * sd, cy + .01, .006, .0025, 8), .0125, hexc('#ffffff')), grp='glow')
        # дужка
        a0 = (cx + sd * rx, cy + .006, zc - .006)
        e1, _ = hd.around(82 * sd, .122, .006)
        e2, _ = hd.around(100 * sd, .118, .006)
        g.add(sweep(bez(a0, add(a0, (sd * .02, 0, -.01)), add(e1, (0, 0, .015)), e2, 8), lambda s: (.0014, .0014),
                    (0, 1, 0), 5, H_GLASS), grp='soft')
    zb = hd.surf_z(0, .118) + .012
    g.add(sweep(bez((-.015, .118, zb), (-.006, .124, zb + .002), (.006, .124, zb + .002), (.015, .118, zb), 6),
                lambda s: (.0014, .0014), (0, 1, 0), 5, H_GLASS), grp='soft')
    # причёска
    g.add(hd.cap_mesh(lambda j, a: H_HAIR0))
    H0, H1 = H_HAIR0, H_HAIR1
    # шторка-чёлка от пробора, уходит к вискам
    for sd in (-1, 1):
        for th, y1, dth in ((6, .19, 40), (14, .17, 34), (24, .15, 26), (34, .14, 18), (46, .125, 10)):
            g.add(lock(hd, th * sd, .305, y1, .03, .011, dtheta=dth * sd, off0=.011, off1=.024, flick=.006,
                       col0=H0, col1=lerp3(H0, H1, .45)))
    # боковые пряди у лица: длинные волны до груди
    for sd in (-1, 1):
        for k, (th, y0, spread, amp, ph) in enumerate(((62, .2, .03, .012, 0.0), (74, .19, .045, .014, 1.3),
                                                      (88, .2, .055, .013, 2.4), (100, .21, .06, .012, 3.3))):
            a, _ = hd.around(th * sd, y0, .016)
            pts = _wavy(a, sd, .56 - k * .03, spread, .1 if k < 2 else .05, amp, ph)
            g.add(free_lock(pts, .026, .01, (sd, 0, .4), H0, H1, nu=7))
    # объём сзади: волнистая «шторка» до середины спины
    for i, th in enumerate(range(110, 251, 14)):
        a, o = hd.around(th, .23, .016)
        sd = 1 if th < 180 else -1
        pts = _wavy(a, sd, .62, .03, -.17, .014, i * .9)
        g.add(free_lock(pts, .04, .014, o, H0, H1, nu=7))
    for th in range(95, 266, 17):
        g.add(lock(hd, th, .3, .1, .042, .013, dtheta=(-6 if th < 180 else 6), off0=.01, off1=.022, col0=H0,
                   col1=lerp3(H0, H1, .3)))
    return g


def haru_torso():
    g = Geo()
    body = [(-.02, .1, .08), (.06, .104, .08), (.16, .118, .088), (.26, .132, .1, 0, .01), (.33, .14, .1, 0, .012),
            (.4, .15, .088, 0, .004), (.45, .135, .078), (.51, .07, .055)]
    g.add(loft(body, 20, lambda j, a: H_TOP if j > 1 else H_TOP_SH))
    g.add(limb(.44, .66, .043, .039, H_SKIN, rings=4))
    g.add(ring(.05, .006, y=.47, col=H_TOP, squash=.9))
    # чёрное пальто внакидку: открыто спереди, широкие плечи
    coat = [(.5, .12, .085), (.47, .175, .115), (.4, .18, .125), (.3, .165, .13), (.18, .15, .125), (.05, .15, .125),
            (-.04, .158, .13)]
    g.add(shell(coat, .01, 30, 30, 330, lambda j, a: lerp3(H_COAT, H_COAT_HI, .25 if j < 2 else 0), H_COAT_HI))
    for sd in (-1, 1):
        g.add(blob(.07, .045, .07, col=H_COAT), pos=(sd * .14, .46, -.005))
        # лацканы по краю
        pts = []
        for k in range(10):
            y = lerp(.49, -.03, k / 9)
            rr = Head._at([(c[0], c[1], c[2], 0.0) for c in reversed(coat)], y)
            a = math.radians(30 if sd < 0 else 330)
            pts.append((rr[0] * math.sin(a) * .98, y, rr[1] * math.cos(a) + .004))
        g.add(sweep(pts, lambda s: (.009, .004), (0, 0, 1), 6, H_COAT_HI))
    return g


def haru_hips():
    g = Geo()
    g.add(loft([(-.08, .104, .084), (.04, .108, .086)], 18, hexc('#1a1a20')))
    g.add(shell([(.04, .158, .13), (-.06, .17, .14), (-.14, .182, .15)], .01, 28, 30, 330, H_COAT, H_COAT_HI))
    return g


def haru_thigh():
    g = Geo()
    g.add(limb(.02, -.45, .066, .046, hexc('#1a1a20'), bulge=.06))
    # полы пальто до колен
    g.add(shell([(.04, .1, .1), (-.15, .118, .12), (-.32, .13, .132), (-.4, .132, .134)], .008, 22, 40, 320, H_COAT,
                H_COAT_HI))
    return g


def haru_shin():
    g = Geo()
    g.add(limb(.03, -.4, .046, .03, hexc('#1a1a20'), bulge=.1))
    g.add(loft([(-.26, .042, .044), (-.36, .04, .043), (-.42, .042, .046)], 14, hexc('#0e0e12')))
    g.add(foot(hexc('#0e0e12'), hexc('#2a2a30'), L=.18, W=.06, H=.065), pos=(0, -.43, .04))
    return g


def haru_upper_arm(side):
    g = Geo()
    g.add(blob(.05, .05, .05, col=H_TOP), pos=(0, -.025, 0))
    g.add(limb(-.02, -.27, .043, .036, H_TOP))
    # широкий рукав пальто
    rows = [(.02, .06, .06), (-.06, .066, .068), (-.15, .074, .08), (-.24, .082, .094, 0, -.01), (-.29, .084, .098, 0, -.012),
            (-.3, .084, .098, 0, -.012)]
    g.add(shell(rows, .007, 22, col_out=H_COAT, col_in=H_COAT_HI))
    return g


def haru_forearm(side):
    g = Geo()
    g.add(limb(0, -.24, .038, .033, H_TOP, bulge=.06))
    g.add(ring(.034, .006, y=-.235, col=H_TOP_SH))
    g.add(limb(-.235, -.262, .028, .027, H_SKIN, rings=2))
    return g


def haru_hand():
    g = Geo()
    g.add(hand(H_SKIN, True, .046))
    g.add(ring(.012, .002, y=.005, col=hexc('#e8e0d0')), pos=(.01, 0, .015), r=(0, 0, 90))
    return g


def haru_coat_seg(i, n):
    """Подол пальто сзади — цепочка, которая развевается на бегу"""
    g = Geo()
    w0 = .14 - i * .01
    w1 = .14 - (i + 1) * .01
    pts = [(0, 0, .0), (0, -.005, -.08), (0, -.01, -.16)]
    g.add(sweep(pts, lambda s: (lerp(w0, w1, s), .006), (0, 1, 0), 8, H_COAT))
    return g


def haru_hakama_thigh():
    """Длинная алая плиссированная хакама до середины голени"""
    g = Geo()
    g.add(limb(.02, -.45, .068, .046, K_BLACK, bulge=.08))
    pleat = lambda j, a: K_SILK if j == 0 else lerp3(K_RED, K_RED_D, .55 * (math.cos(a * 5) * .5 + .5))
    g.add(shell([(.05, .085, .09), (.02, .09, .095), (-.1, .116, .122), (-.24, .142, .15), (-.36, .158, .166),
                 (-.47, .168, .176), (-.5, .169, .177)], .008, 26, col_out=pleat, col_in=K_RED_D, wave=(.06, 5)))
    return g


def haru_hakama_shin():
    """Низ хакамы у колена + лакированные поножи и сапоги"""
    g = Geo()
    g.add(limb(.03, -.4, .047, .03, K_BLACK, bulge=.12))
    pleat = lambda j, a: lerp3(K_RED, K_RED_D, .55 * (math.cos(a * 5) * .5 + .5))
    g.add(shell([(.06, .15, .156), (-.04, .158, .164), (-.12, .162, .168), (-.14, .162, .168)], .008, 26,
                col_out=pleat, col_in=K_RED_D, wave=(.06, 5)))
    g.add(shell([(-.04, .052, .052), (-.055, .052, .052), (-.18, .05, .05), (-.33, .038, .038)], .007, 14, -70, 70,
                lambda j, a: K_GOLD if j == 0 else K_LAC, K_BLACK))
    g.add(ring(.04, .006, y=-.35, col=K_GOLD))
    g.add(foot(K_BLACK, K_RED_D, L=.18, W=.06, H=.065), pos=(0, -.43, .04))
    return g


def haru_battle_torso():
    """Тот же наряд, но без высокой причёски на голове: длинная алая лента-шарф за плечом"""
    g = kaze_torso()
    pts = [(-.12, .5, -.05), (-.16, .48, -.12), (-.2, .38, -.17), (-.22, .24, -.2)]
    g.add(sweep(bez(*pts, 10), lambda s: (.05 * (1 - s * .3), .006), (0, 0, -1), 8, K_RED))
    return g


def build_haru(h):
    from ursina import Entity as E
    K = 'haru'
    rim = (.85, .8, 1, .4)
    h.body = E(parent=h)
    h.hips = E(parent=h.body, y=.95)
    dress(h.hips, 'kaze' + 'hips', kaze_hips, rim)
    h.legs = {}
    for side, name in ((-1, 'l'), (1, 'r')):
        hip = E(parent=h.hips, x=.09 * side, y=-.04)
        dress(hip, K + 'hthigh', haru_hakama_thigh, rim)
        knee = E(parent=hip, y=-.45)
        dress(knee, K + 'hshin', haru_hakama_shin, rim)
        h.legs[name] = (hip, knee)
    h.torso = E(parent=h.hips, y=.06)
    dress(h.torso, K + 'btorso', haru_battle_torso, rim)
    h.head = E(parent=h.torso, y=.62)
    hg = E(parent=h.head, y=-0.028)
    dress(hg, K + 'head', haru_head, rim)
    h.face = build_face(hg, H_HEAD, HARU_FACE)
    h.face['lid_base'] = .06
    h.eyes = []
    h.hair = []
    h.scarf = []
    par = E(parent=h.torso, position=(0, .07, -.12))
    for i in range(4):
        dress(par, 'kaze' + f'rib{i}', lambda i=i: kaze_ribbon_seg(i, 4), rim)
        h.scarf.append(par)
        par = E(parent=par, z=-.16)
    h.arms = {}
    h.fans = []
    for side, name in ((-1, 'l'), (1, 'r')):
        sh = E(parent=h.torso, position=(.2 * side, .44, 0))
        dress(sh, 'kaze' + 'upper', lambda side=side: kaze_upper_arm(side), rim)
        el = E(parent=sh, y=-.27)
        dress(el, 'kaze' + 'fore', lambda side=side: kaze_forearm(side), rim)
        wr = E(parent=el, y=-.26)
        dress(wr, 'kaze' + 'hand', kaze_hand, rim)
        fan = E(parent=wr, y=-.05)
        dress(fan, 'kaze' + 'fan', kaze_fan, rim)
        h.fans.append(fan)
        h.arms[name] = (sh, el, wr)
    return h

