"""Процедурные текстуры для подземелий, брони и демонов

Пишет PNG без сторонних библиотек (numpy + zlib) в папку textures/
"""
import os
import zlib
import struct
import numpy as np

S = 256
rng = np.random.default_rng(11)


def save_png(path, img):
    img = np.clip(img, 0, 255).astype(np.uint8)
    h, w, c = img.shape
    raw = b''.join(b'\x00' + img[y].tobytes() for y in range(h))

    def chunk(tag, data):
        return struct.pack('>I', len(data)) + tag + data + struct.pack('>I', zlib.crc32(tag + data) & 0xffffffff)
    color_type = 6 if c == 4 else 2
    png = b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', struct.pack('>IIBBBBB', w, h, 8, color_type, 0, 0, 0))
    png += chunk(b'IDAT', zlib.compress(raw, 9)) + chunk(b'IEND', b'')
    with open(path, 'wb') as f:
        f.write(png)


def noise(scale, octaves=4, seed=0):
    """Тайлящийся value-noise"""
    r = np.random.default_rng(seed)
    out = np.zeros((S, S))
    amp, total = 1.0, 0.0
    for o in range(octaves):
        n = scale * 2 ** o
        grid = r.random((n, n))
        xs = np.linspace(0, n, S, endpoint=False)
        i0 = xs.astype(int) % n
        i1 = (i0 + 1) % n
        f = xs - xs.astype(int)
        f = f * f * (3 - 2 * f)
        a = grid[i0][:, i0] * (1 - f)[None, :] + grid[i0][:, i1] * f[None, :]
        b = grid[i1][:, i0] * (1 - f)[None, :] + grid[i1][:, i1] * f[None, :]
        out += (a * (1 - f)[:, None] + b * f[:, None]) * amp
        total += amp
        amp *= .5
    return out / total


def rgb(*c):
    return np.array(c, dtype=float)


def colorize(t, c0, c1):
    return c0[None, None, :] * (1 - t[..., None]) + c1[None, None, :] * t[..., None]


Y, X = np.mgrid[0:S, 0:S]


def tiles(nx, ny, offset_rows=False, mortar=3):
    tw, th = S // nx, S // ny
    row = Y // th
    xx = X + (row % 2) * (tw // 2) * offset_rows
    lx, ly = xx % tw, Y % th
    edge = np.minimum(np.minimum(lx, tw - 1 - lx), np.minimum(ly, th - 1 - ly))
    tile_id = (xx // tw) + row * 31
    return edge, tile_id


def per_tile(tile_id, lo, hi, seed):
    r = np.random.default_rng(seed)
    vals = r.uniform(lo, hi, tile_id.max() + 1)
    return vals[tile_id]


def cracks(seed, n=6, width=1.2):
    r = np.random.default_rng(seed)
    m = np.zeros((S, S))
    for _ in range(n):
        x, y = r.uniform(0, S, 2)
        a = r.uniform(0, 6.28)
        for _ in range(r.integers(40, 120)):
            a += r.normal(0, .35)
            x = (x + np.cos(a) * 1.5) % S
            y = (y + np.sin(a) * 1.5) % S
            d = np.hypot(((X - x + S / 2) % S) - S / 2, ((Y - y + S / 2) % S) - S / 2)
            m = np.maximum(m, np.clip(1 - d / width, 0, 1))
    return m


def floor_stone():
    edge, tid = tiles(4, 4, mortar=3)
    n = noise(8, 5, 1)
    base = colorize(n * .6 + per_tile(tid, .2, .5, 2)[..., None][..., 0] * .8, rgb(38, 30, 32), rgb(92, 80, 80))
    base *= np.clip(edge / 4, .35, 1)[..., None]
    base *= (1 - cracks(3, 7) * .6)[..., None]
    return base


def wall_brick():
    edge, tid = tiles(4, 8, offset_rows=True)
    n = noise(16, 4, 4)
    base = colorize(n * .5 + per_tile(tid, .1, .6, 5) * .5, rgb(34, 22, 24), rgb(84, 58, 56))
    base *= np.clip(edge / 3, .3, 1)[..., None]
    moss = np.clip(noise(4, 3, 6) * 2 - 1.15, 0, 1)
    base = base * (1 - moss[..., None]) + rgb(60, 12, 16) * moss[..., None]
    return base


def lava_rock():
    n = noise(6, 6, 7)
    base = colorize(n, rgb(18, 12, 14), rgb(62, 46, 46))
    c = cracks(8, 9, 1.8)
    glow = np.clip(c * 1.4, 0, 1)
    base = base * (1 - glow[..., None]) + rgb(255, 70, 30) * glow[..., None]
    return base


def wood():
    edge, tid = tiles(1, 6)
    grain = np.sin((X + noise(4, 3, 9) * 60 + per_tile(tid, 0, 100, 10)) * .25) * .5 + .5
    base = colorize(grain * .45 + noise(16, 3, 11) * .35 + per_tile(tid, 0, .25, 12), rgb(30, 14, 12), rgb(96, 50, 34))
    base *= np.clip(edge / 2.5, .3, 1)[..., None]
    return base


def shoji():
    base = colorize(noise(32, 3, 13) * .4 + .5, rgb(150, 120, 110), rgb(215, 190, 175))
    frame = ((X % 64) < 5) | ((Y % 86) < 5)
    base[frame] = rgb(28, 10, 12)
    return base


def lacquer():
    # кодзанэ: ряды лакированных пластин, связанных красным шнуром
    th = 32
    row = Y // th
    ly = Y % th
    lx = (X + (row % 2) * 8) % 16
    plate = np.clip(np.minimum(lx, 15 - lx) / 2, 0, 1) * np.clip((th - ly) / 4, 0, 1)
    shine = np.clip(1 - ly / th, 0, 1) ** 2 * .35
    base = colorize(plate * .6 + shine + noise(32, 3, 14) * .15, rgb(14, 8, 10), rgb(80, 22, 26))
    lace = ((ly > th - 7) & (ly < th - 2) & ((X % 16) < 5)) | (((X % 32) < 3) & (ly < th - 6))
    base[lace] = rgb(170, 20, 30)
    return base


def metal():
    n = noise(16, 5, 15)
    base = colorize(n, rgb(28, 26, 30), rgb(78, 74, 80))
    scratches = np.clip(np.abs(np.sin(X * .9 + noise(8, 2, 16) * 30)) - .97, 0, 1) * 30
    base += scratches[..., None] * 40
    rivets = (((X % 64) - 32) ** 2 + ((Y % 64) - 32) ** 2) < 16
    base[rivets] = rgb(150, 120, 60)
    return base


def cloth():
    weave = (np.sin(X * 1.6) * np.sin(Y * 1.6) * .5 + .5)
    return colorize(weave * .25 + noise(16, 3, 17) * .4, rgb(16, 8, 10), rgb(52, 22, 26))


def skin_dark():
    n = noise(8, 5, 18)
    base = colorize(n, rgb(10, 18, 22), rgb(46, 64, 70))
    veins = cracks(19, 10, 1.0)
    base = base * (1 - veins[..., None] * .7)
    return base


def skin_red():
    n = noise(8, 5, 20)
    base = colorize(n, rgb(70, 8, 10), rgb(190, 50, 36))
    veins = cracks(21, 12, 1.1)
    base = base * (1 - veins[..., None] * .75)
    return base


def skin_bone():
    n = noise(8, 5, 22)
    base = colorize(n, rgb(90, 84, 78), rgb(190, 180, 168))
    return base * (1 - cracks(23, 6, 1.0)[..., None] * .5)


def horn():
    rings = np.sin(Y * .35 + noise(4, 2, 24) * 6) * .5 + .5
    return colorize(rings * .5 + noise(16, 3, 25) * .4, rgb(80, 62, 40), rgb(210, 180, 130))


def membrane():
    n = noise(6, 4, 26)
    base = colorize(n, rgb(8, 20, 24), rgb(30, 60, 64))
    veins = cracks(27, 8, 1.3)
    base = base * (1 - veins[..., None] * .6)
    a = np.full((S, S, 1), 225.0) - veins[..., None] * 40
    return np.concatenate([base, a], axis=2)


def eyeball():
    """Белок демонического глаза: желтоватый, с красными прожилками"""
    n = noise(10, 4, 40)
    base = colorize(n, rgb(170, 150, 120), rgb(235, 222, 196))
    veins = np.maximum(cracks(41, 14, 1.1), cracks(42, 10, .8) * .8)
    red = rgb(150, 10, 18)
    return base * (1 - veins[..., None]) + red * veins[..., None]


def gold():
    n = noise(16, 4, 28)
    return colorize(n, rgb(110, 70, 20), rgb(240, 190, 90))


def radial(power=2.0, invert=False):
    d = np.hypot(X - S / 2 + .5, Y - S / 2 + .5) / (S / 2)
    a = np.clip(1 - d, 0, 1) ** power
    if invert:
        a = np.clip(d - .45, 0, 1) / .55
        a = a ** 1.6
    return a


def glow():
    a = radial(2.2) * 255
    return np.concatenate([np.full((S, S, 3), 255.0), a[..., None]], axis=2)


def shadow():
    a = radial(1.5) * 200
    return np.concatenate([np.zeros((S, S, 3)), a[..., None]], axis=2)


def vignette():
    a = radial(invert=True) * 235
    return np.concatenate([np.zeros((S, S, 3)), a[..., None]], axis=2)


def decal_ring():
    d = np.hypot(X - S / 2 + .5, Y - S / 2 + .5) / (S / 2)
    a = np.clip(1 - np.abs(d - .92) / .08, 0, 1) + np.clip(1 - d, 0, 1) * .35 * (d < 1)
    return np.concatenate([np.full((S, S, 3), 255.0), (np.clip(a, 0, 1) * 255)[..., None]], axis=2)


def moss():
    n = noise(8, 5, 31)
    base = colorize(n, rgb(14, 22, 12), rgb(48, 66, 34))
    leaves = np.clip(noise(32, 2, 32) * 3 - 1.9, 0, 1)
    return base * (1 - leaves[..., None] * .5) + rgb(90, 30, 20) * leaves[..., None] * .5


def bamboo():
    stalk = (X % 32)
    edge = np.minimum(stalk, 31 - stalk)
    shade = np.clip(edge / 6, 0, 1)
    nodes = (np.abs((Y + (X // 32) * 37) % 64 - 32) < 2)
    base = colorize(noise(16, 3, 33) * .5 + shade * .5, rgb(18, 34, 16), rgb(70, 110, 52))
    base[nodes] = base[nodes] * .45
    base *= (.35 + .65 * shade)[..., None]
    return base


def snow():
    n = noise(8, 5, 34)
    base = colorize(n, rgb(150, 160, 178), rgb(232, 236, 245))
    sparkle = (np.random.default_rng(35).random((S, S)) > .995)
    base[sparkle] = rgb(255, 255, 255)
    return base


def ice():
    n = noise(6, 5, 36)
    base = colorize(n, rgb(40, 70, 100), rgb(150, 190, 220))
    c = cracks(37, 10, 1.0)
    return base * (1 - c[..., None] * .2) + rgb(230, 245, 255) * c[..., None] * .6


def obsidian():
    n = noise(8, 5, 38)
    base = colorize(n, rgb(6, 4, 8), rgb(36, 26, 38))
    veins = cracks(39, 9, 1.3)
    return base * (1 - veins[..., None]) + rgb(230, 170, 70) * veins[..., None]


def quilt():
    d = (np.abs(((X + Y) % 32) - 16) < 1.5) | (np.abs(((X - Y) % 32) - 16) < 1.5)
    base = colorize(noise(32, 3, 40) * .4 + .3, rgb(16, 10, 12), rgb(60, 40, 40))
    base[d] = base[d] * .35
    return base


def paper():
    fib = noise(64, 2, 41) * .3 + noise(8, 3, 42) * .2
    base = colorize(fib + .5, rgb(200, 186, 170), rgb(250, 240, 228))
    ribs = (np.abs((np.arctan2(Y - S, X - S / 2 + .5) * 40 / np.pi) % 2 - 1) < .12)
    base[ribs] = rgb(150, 20, 28)
    return base


def silk():
    n = noise(16, 3, 43)
    sheen = np.sin(Y * .08 + noise(4, 2, 44) * 4) * .5 + .5
    return colorize(n * .3 + sheen * .4 + .2, rgb(200, 196, 196), rgb(255, 252, 250))


# ---------------- иконки навыков (белые на прозрачном) ----------------
def _icon(mask):
    a = np.clip(mask, 0, 1) * 255
    return np.concatenate([np.full((S, S, 3), 255.0), a[..., None]], axis=2)


U = (X - S / 2 + .5) / (S / 2)
V = -(Y - S / 2 + .5) / (S / 2)


def _seg(ax, ay, bx, by, w):
    px, py = U - ax, V - ay
    dx, dy = bx - ax, by - ay
    t = np.clip((px * dx + py * dy) / (dx * dx + dy * dy), 0, 1)
    d = np.hypot(px - dx * t, py - dy * t)
    return np.clip((w - d) / .03, 0, 1)


def icon_sword():
    return _icon(_seg(-.6, -.6, .62, .62, .07) + _seg(-.55, -.25, -.25, -.55, .07) + _seg(-.8, -.8, -.6, -.6, .09))


def icon_moon():
    r = np.hypot(U, V)
    r2 = np.hypot(U - .32, V - .22)
    return _icon(np.clip((.72 - r) / .03, 0, 1) * np.clip((r2 - .6) / .03, 0, 1))


def icon_wave():
    m = np.zeros((S, S))
    for k, rr in enumerate((.35, .55, .75)):
        r = np.hypot(U + .5, V)
        ang = np.abs(np.arctan2(V, U + .5))
        m += np.clip((.06 - np.abs(r - rr - .1)) / .03, 0, 1) * (ang < .9)
    return _icon(m)


def icon_dash():
    m = np.zeros((S, S))
    for off in (-.35, .15):
        m += _seg(off - .2, .45, off + .25, 0, .08) + _seg(off + .25, 0, off - .2, -.45, .08)
    return _icon(m)


def icon_heavy():
    return _icon(_seg(-.75, 0, .75, 0, .08) + _seg(.35, .3, .75, 0, .08) + _seg(.35, -.3, .75, 0, .08)
                 + _seg(-.75, .25, -.2, .25, .04) + _seg(-.75, -.25, -.2, -.25, .04))


def icon_swirl():
    r = np.hypot(U, V)
    th = np.arctan2(V, U)
    spiral = np.abs(((r * 9 - th) % (2 * np.pi)) - np.pi) < .55
    return _icon(spiral * (r < .8) * (r > .08) * 1.0)


def icon_fan():
    r = np.hypot(U, V + .55)
    th = np.arctan2(U, V + .55)
    m = (r < 1.05) * (r > .25) * (np.abs(th) < 1.1)
    ribs = (np.abs((th * 6 / np.pi) % 1 - .5) > .42) * (r < 1.0)
    return _icon(m * .55 + ribs * m * .45 + _seg(0, -.55, 0, -.3, .06))


def icon_feather():
    m = _seg(-.55, -.65, .55, .65, .035)
    th_d = np.abs((U - V * 1.0)) / 1.41
    along = (U + V) / 1.41
    vane = (th_d < .28 * np.sqrt(np.clip(1 - (along / .85) ** 2, 0, 1))) * (along > -.6)
    return _icon(m + vane * .8)


def icon_cross():
    return _icon(_seg(-.6, -.6, .6, .6, .08) + _seg(-.6, .6, .6, -.6, .08))


def fur():
    strands = np.sin(X * 1.7 + noise(16, 3, 50) * 20) * .5 + .5
    return colorize(strands * .35 + noise(8, 4, 51) * .5, rgb(70, 46, 30), rgb(190, 150, 110))


def feather():
    v = (Y % 24) / 24.0
    barbs = np.abs(np.sin((X + v * 30) * .8)) * .4
    base = colorize(barbs + noise(16, 3, 52) * .4, rgb(8, 8, 14), rgb(54, 58, 78))
    base[(X % 48) < 2] = rgb(90, 96, 120)
    return base


def chitin():
    n = noise(8, 5, 53)
    base = colorize(n, rgb(14, 8, 18), rgb(66, 38, 70))
    hour = (np.abs(U) < .25 * (1 - np.abs(V) * .9)) * (np.abs(V) < .55)
    base[hour] = rgb(200, 20, 30)
    return base


def icon_heal():
    return _icon(_seg(0, -.6, 0, .6, .16) + _seg(-.6, 0, .6, 0, .16))


TEX = {
    'floor_stone': floor_stone, 'wall_brick': wall_brick, 'lava_rock': lava_rock, 'wood': wood,
    'shoji': shoji, 'lacquer': lacquer, 'metal': metal, 'cloth': cloth, 'skin_dark': skin_dark,
    'skin_red': skin_red, 'skin_bone': skin_bone, 'horn': horn, 'membrane': membrane, 'gold': gold,
    'glow': glow, 'shadow': shadow, 'vignette': vignette, 'decal_ring': decal_ring,
    'moss': moss, 'bamboo': bamboo, 'snow': snow, 'ice': ice, 'obsidian': obsidian, 'quilt': quilt,
    'paper': paper, 'silk': silk,
    'icon_sword': icon_sword, 'icon_moon': icon_moon, 'icon_wave': icon_wave, 'icon_dash': icon_dash,
    'icon_heavy': icon_heavy, 'icon_swirl': icon_swirl, 'icon_fan': icon_fan, 'icon_feather': icon_feather,
    'icon_cross': icon_cross,
    'fur': fur, 'feather': feather, 'chitin': chitin, 'icon_heal': icon_heal, 'eyeball': eyeball,
}


def ensure(folder):
    os.makedirs(folder, exist_ok=True)
    missing = [k for k in TEX if not os.path.exists(os.path.join(folder, k + '.png'))]
    if not missing:
        return
    print('Генерирую текстуры…')
    for k in missing:
        save_png(os.path.join(folder, k + '.png'), TEX[k]())


if __name__ == '__main__':
    ensure(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'textures'))
    print('готово')
