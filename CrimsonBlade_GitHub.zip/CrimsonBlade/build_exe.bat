@echo off
chcp 65001 >nul
cd /d "%~dp0"
title Crimson Blade - build .exe

set PY=
where py >nul 2>nul && set PY=py
if not defined PY (
  python -c "import sys" >nul 2>nul && set PY=python
)
if not defined PY (
  echo [!] Python not found. Install it from python.org and tick "Add python.exe to PATH"
  pause
  exit /b 1
)

echo [1/4] Installing ursina, numpy, pyinstaller...
%PY% -m pip install -r requirements.txt pyinstaller
if errorlevel 1 goto fail

echo [2/4] Generating music and textures...
%PY% music.py
%PY% textures.py

echo [3/4] Building CrimsonBlade.exe (1-3 minutes)...
%PY% -m PyInstaller --noconfirm --clean --windowed --name CrimsonBlade --icon icon.ico ^
  --collect-all ursina --collect-all panda3d ^
  launcher.py
if errorlevel 1 goto fail

echo [4/4] Copying game files...
copy /y game.py dist\CrimsonBlade\ >nul
copy /y music.py dist\CrimsonBlade\ >nul
copy /y textures.py dist\CrimsonBlade\ >nul
copy /y anime_models.py dist\CrimsonBlade\ >nul
copy /y README.md dist\CrimsonBlade\ >nul
xcopy /e /i /y /q sounds dist\CrimsonBlade\sounds >nul
xcopy /e /i /y /q textures dist\CrimsonBlade\textures >nul
powershell -NoProfile -Command "Compress-Archive -Force -Path 'dist\CrimsonBlade' -DestinationPath 'dist\CrimsonBlade.zip'"
powershell -NoProfile -Command "$d=[Environment]::GetFolderPath('Desktop'); $s=(New-Object -ComObject WScript.Shell).CreateShortcut((Join-Path $d 'Crimson Blade.lnk')); $s.TargetPath=(Resolve-Path 'dist\CrimsonBlade\CrimsonBlade.exe').Path; $s.WorkingDirectory=(Resolve-Path 'dist\CrimsonBlade').Path; $s.Save()"
start "" "dist\CrimsonBlade\CrimsonBlade.exe"

echo.
echo ==========================================================
echo  DONE!  Desktop shortcut "Crimson Blade" created
echo  Next updates: just replace dist\CrimsonBlade\game.py
echo ==========================================================
pause
exit /b 0

:fail
echo.
echo [!] Build failed. Send a screenshot of this window.
pause
exit /b 1
