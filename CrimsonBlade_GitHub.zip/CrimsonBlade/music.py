"""Процедурный саундтрек и звуки для «Клинка Багровой Луны».

Всё синтезируется numpy-ем в японском ладу мияко-буси (D Eb G A Bb):
тайко, кото, сякухати, гул и ветер. Файлы .wav пишутся в папку sounds/.
"""
import os
import wave
import numpy as np

SR = 22050
rng = np.random.default_rng(7)


def _t(d):
    return np.arange(int(SR * d)) / SR


def lowpass(x, k):
    if k <= 1:
        return x
    return np.convolve(x, np.ones(k) / k, mode="same")


def bandnoise(n, lo, hi):
    x = rng.standard_normal(n)
    return lowpass(x, lo) - lowpass(x, hi)


def place(buf, snd, t0, gain=1.0, wrap=True):
    """Кладёт звук в буфер; хвост за концом переносится в начало (бесшовная петля)"""
    i = int(t0 * SR) % len(buf)
    n = len(snd)
    end = min(len(buf), i + n)
    buf[i:end] += snd[: end - i] * gain
    rest = n - (end - i)
    if wrap and rest > 0:
        buf[:rest] += snd[end - i:] * gain


# ---------- инструменты ----------

def taiko(big=True):
    d = 1.3 if big else 0.35
    t = _t(d)
    f0, f1 = (100, 46) if big else (250, 175)
    freq = f1 + (f0 - f1) * np.exp(-t * 16)
    body = np.sin(2 * np.pi * np.cumsum(freq) / SR) * np.exp(-t * (4.0 if big else 14))
    hit = lowpass(rng.standard_normal(len(t)), 6 if big else 3) * np.exp(-t * (35 if big else 60))
    return body + hit * (0.6 if big else 0.4)


def koto(f, d=1.8):
    t = _t(d)
    s = np.zeros_like(t)
    for k in range(1, 8):
        s += np.sin(2 * np.pi * f * k * (1 + 0.0007 * k * k) * t) / k ** 1.1 * np.exp(-t * (2.0 + k * 1.4))
    s *= np.minimum(1, t / 0.004)
    click = rng.standard_normal(len(t)) * np.exp(-t * 300) * 0.12
    return s * 0.5 + click


def shakuhachi(f, d):
    t = _t(d)
    bend = 1 - 0.03 * np.exp(-t * 7)  # мери: заход снизу
    vib = 1 + 0.007 * np.sin(2 * np.pi * 5.0 * t) * np.minimum(1, t / 0.7)
    ph = 2 * np.pi * np.cumsum(f * bend * vib) / SR
    tone = np.sin(ph) + 0.22 * np.sin(2 * ph) + 0.07 * np.sin(3 * ph)
    breath = lowpass(rng.standard_normal(len(t)), 4) * (0.35 * np.exp(-t * 3) + 0.12)
    env = np.clip(np.minimum(t / 0.2, (d - t) / 0.3), 0, 1)
    return (tone * 0.6 + breath) * env


def swish(d=0.18, lo=2, hi=10, f0=1100, f1=250):
    t = _t(d)
    env = np.sin(np.pi * np.clip(t / d, 0, 1)) ** 2 * np.exp(-t * 4)
    n = bandnoise(len(t), lo, hi)
    freq = f1 + (f0 - f1) * np.exp(-t * 18)
    tone = np.sin(2 * np.pi * np.cumsum(freq) / SR) * 0.25
    return (n * 1.4 + tone) * env


def mix(*xs):
    out = np.zeros(max(len(x) for x in xs))
    for x in xs:
        out[:len(x)] += x
    return out


def norm(x, peak=0.9):
    x = x / (np.max(np.abs(x)) + 1e-9)
    x = np.tanh(x * 1.4) / np.tanh(1.4)
    return x * peak


def write(path, x):
    data = (np.clip(x, -1, 1) * 32767).astype(np.int16)
    with wave.open(path, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(SR)
        w.writeframes(data.tobytes())


# ---------- саундтрек ----------

D4 = 293.66


def note(s):
    return D4 * 2 ** (s / 12)


def make_bgm():
    bpm = 92
    B = 60 / bpm
    bars = 16
    L = bars * 4 * B
    n = int(L * SR)
    buf = np.zeros(n)
    t = np.arange(n) / SR

    # гул: частоты подогнаны под длину петли, чтобы не было щелчка на стыке
    def fit(f):
        return round(f * L) / L
    swell = 0.6 + 0.4 * np.sin(2 * np.pi * t * fit(1 / (L / 4)))
    drone = (np.sin(2 * np.pi * fit(73.42) * t) * 0.5
             + np.sin(2 * np.pi * fit(110.0) * t) * 0.25
             + np.sin(2 * np.pi * fit(146.83) * t) * 0.12) * swell
    buf += drone * 0.35

    # ночной ветер, затухает к краям петли
    wind = lowpass(rng.standard_normal(n), 60) * 6
    buf += wind * np.sin(np.pi * t / L) ** 2 * 0.25

    big, small = taiko(True), taiko(False)
    pat_a = [0, 7, 12, 7, 8, 7, 5, 1]
    pat_b = [0, 7, 13, 12, 8, 7, 5, 7]
    for bar in range(bars):
        b0 = bar * 4 * B
        calm = bar < 2
        # тайко
        if calm:
            place(buf, big, b0, 0.55)
        else:
            for bt in (0, 2):
                place(buf, big, b0 + bt * B, 0.9)
            for bt in (1, 1.5, 3, 3.5):
                place(buf, small, b0 + bt * B, 0.45)
            if bar % 4 == 3:
                for bt in (3, 3.25, 3.5, 3.75):
                    place(buf, small, b0 + bt * B, 0.6)
        # кото: остинато восьмыми + бас на сильную долю
        pat = pat_a if bar % 2 == 0 else pat_b
        for i, s in enumerate(pat):
            place(buf, koto(note(s - 12)), b0 + i * B / 2, 0.3 if calm else 0.38)
        place(buf, koto(note(-24), 2.5), b0, 0.45)

    # сякухати с 5-го такта
    mel = [(16, 3, 7), (19, 1, 8), (20, 4, 7), (24, 2, 5), (26, 2, 1), (28, 4, 0),
           (32, 3, 12), (35, 1, 13), (36, 4, 12), (40, 2, 8), (42, 2, 7), (44, 4, 5),
           (48, 3, 7), (51, 1, 8), (52, 2, 12), (54, 2, 13), (56, 4, 12), (60, 2, 8), (62, 2, 7)]
    for st, ln, s in mel:
        place(buf, shakuhachi(note(s), ln * B + 0.25), st * B, 0.42)

    return norm(buf, 0.85)


def make_ult():
    """2.9 с, синхронно с анимацией: разгон 0–1.1, звон 1.15, взмахи 1.45–1.8, удар 1.95"""
    L = 3.4
    n = int(L * SR)
    buf = np.zeros(n)
    t = _t(1.15)
    # нарастающий вихрь
    raw = rng.standard_normal(len(t))
    k = t / 1.15
    whoosh = lowpass(raw, 40) * (1 - k) * 4 + lowpass(raw, 3) * k
    rise = np.sin(2 * np.pi * np.cumsum(180 + 700 * k ** 2) / SR) * 0.3
    place(buf, (whoosh * 0.6 + rise) * k ** 1.5, 0.0, 1.0, wrap=False)
    place(buf, shakuhachi(note(12), 1.1), 0.05, 0.5, wrap=False)
    # металлический звон клинка
    tt = _t(1.2)
    shing = sum(np.sin(2 * np.pi * f * tt) * a for f, a in ((1830, 1), (2710, .7), (3950, .5), (5230, .3)))
    place(buf, shing * np.exp(-tt * 5) * np.minimum(1, tt / 0.003), 1.15, 0.45, wrap=False)
    # серия разрезов
    for i, ts in enumerate((1.45, 1.55, 1.65, 1.78)):
        place(buf, swish(0.16, 2, 9, 1400 - i * 150, 300), ts, 0.8, wrap=False)
    # удар об землю
    tb = _t(1.4)
    freq = 30 + 60 * np.exp(-tb * 9)
    boom = np.sin(2 * np.pi * np.cumsum(freq) / SR) * np.exp(-tb * 2.6)
    crack = lowpass(rng.standard_normal(len(tb)), 5) * np.exp(-tb * 10)
    place(buf, boom * 1.3 + crack * 0.8, 1.95, 1.0, wrap=False)
    for s in (-24, -17, -12, -9):
        place(buf, koto(note(s), 1.4), 1.95, 0.35, wrap=False)
    return norm(buf, 0.95)


def make_boss():
    bpm = 128
    B = 60 / bpm
    bars = 16
    L = bars * 4 * B
    n = int(L * SR)
    buf = np.zeros(n)
    t = np.arange(n) / SR
    def fit(f):
        return round(f * L) / L
    buf += (np.sin(2 * np.pi * fit(55.0) * t) * .5 + np.sin(2 * np.pi * fit(58.27) * t) * .3) * .35
    big, small = taiko(True), taiko(False)
    riff = [0, 0, 1, 0, 7, 8, 7, 5, 0, 0, 1, 0, 13, 12, 8, 7]
    for bar in range(bars):
        b0 = bar * 4 * B
        for bt in (0, 1.5, 2, 3):
            place(buf, big, b0 + bt * B, .95)
        for k in range(8):
            place(buf, small, b0 + k * B / 2 + B / 4, .3)
        if bar % 2 == 1:
            for k in range(4):
                place(buf, small, b0 + 3 * B + k * B / 4, .55)
        for i in range(8):
            s = riff[(bar % 2) * 8 + i]
            place(buf, koto(note(s - 12), 1.0), b0 + i * B / 2, .42)
        place(buf, koto(note(-24), 2.0), b0, .55)
    mel = [(8, 4, 12), (12, 2, 13), (14, 2, 12), (16, 6, 8), (22, 2, 7), (24, 8, 5),
           (40, 4, 13), (44, 2, 12), (46, 2, 8), (48, 6, 7), (54, 2, 5), (56, 8, 0)]
    for st, ln, sm in mel:
        place(buf, shakuhachi(note(sm), ln * B + .2), st * B, .45)
    return norm(buf, .9)


def roar(d=1.0, f0=70):
    t = _t(d)
    env = np.minimum(1, t / .08) * np.exp(-t * 2.2)
    f = f0 * (1 + .3 * np.sin(2 * np.pi * 7 * t)) * (1.2 - .4 * t / d)
    ph = 2 * np.pi * np.cumsum(f) / SR
    saw = (ph / np.pi % 2) - 1
    grit = bandnoise(len(t), 2, 12) * 1.2
    return (saw * .6 + grit * np.abs(np.sin(ph * .5))) * env


def make_sfx():
    out = {}
    out["slash"] = norm(swish(0.18), 0.7)
    tt = _t(0.18)
    out["hit"] = norm(np.sin(2 * np.pi * np.cumsum(60 + 90 * np.exp(-tt * 25)) / SR) * np.exp(-tt * 22)
                      + lowpass(rng.standard_normal(len(tt)), 3) * np.exp(-tt * 45) * 0.8, 0.75)
    w = swish(0.5, 3, 14, 600, 140)
    out["wave"] = norm(w, 0.75)
    th = _t(0.4)
    out["hurt"] = norm((np.sign(np.sin(2 * np.pi * 90 * th)) * 0.3 + np.sin(2 * np.pi * 96 * th))
                       * np.exp(-th * 8), 0.6)
    out["orb"] = norm(mix(koto(note(19), 0.5), koto(note(24), 0.5) * 0.5), 0.35)
    out["dash"] = norm(swish(0.15, 2, 6, 900, 600), 0.5)
    out["drum"] = norm(mix(taiko(True), np.concatenate([np.zeros(int(.2 * SR)), taiko(True) * .7])), 0.85)
    out["kill"] = norm(mix(koto(note(-12), 0.6) * 0.6, swish(0.12, 2, 5, 2000, 900)), 0.55)
    out["roar"] = norm(roar(1.1, 62), 0.8)
    out["shriek"] = norm(roar(.6, 180), 0.6)
    tf = _t(.7)
    out["fireball"] = norm(swish(.7, 4, 20, 300, 90) + lowpass(rng.standard_normal(len(tf)), 2) * np.exp(-tf * 3) * .4, 0.55)
    tb = _t(1.6)
    out["door"] = norm(lowpass(rng.standard_normal(len(tb)), 30) * 5 * np.exp(-tb * 1.5)
                       + np.sin(2 * np.pi * np.cumsum(40 + 10 * np.sin(tb * 3)) / SR) * .6 * np.exp(-tb * 1.2), 0.7)
    out["flap"] = norm(swish(.25, 6, 30, 200, 80), 0.5)
    out["combo"] = norm(mix(*[np.concatenate([np.zeros(int(i * .07 * SR)), koto(note(s), .9)]) for i, s in enumerate((0, 7, 12, 19))]), 0.5)
    vic = np.zeros(int(3.5 * SR))
    for i, s in enumerate((0, 5, 7, 12)):
        place(vic, koto(note(s), 2.0), i * .28, .6, wrap=False)
    for tt in (0, .28, .56, .84, 1.4):
        place(vic, taiko(True), tt, .8, wrap=False)
    place(vic, shakuhachi(note(12), 2.0), 1.4, .5, wrap=False)
    out["victory"] = norm(vic, 0.85)
    tc = _t(.3)
    out["clang"] = norm(sum(np.sin(2 * np.pi * f * tc) for f in (1200, 1870, 2950)) * np.exp(-tc * 14), 0.5)
    return out


FILES = ["bgm", "boss", "ult", "slash", "hit", "wave", "hurt", "orb", "dash", "drum", "kill",
         "roar", "shriek", "fireball", "door", "flap", "combo", "victory", "clang"]


def ensure(folder):
    os.makedirs(folder, exist_ok=True)
    if all(os.path.exists(os.path.join(folder, f + ".wav")) for f in FILES):
        return
    print("Генерирую саундтрек… (один раз, пара секунд)")
    write(os.path.join(folder, "bgm.wav"), make_bgm())
    write(os.path.join(folder, "boss.wav"), make_boss())
    write(os.path.join(folder, "ult.wav"), make_ult())
    for name, x in make_sfx().items():
        write(os.path.join(folder, name + ".wav"), x)


if __name__ == "__main__":
    ensure(os.path.join(os.path.dirname(os.path.abspath(__file__)), "sounds"))
    print("готово")
